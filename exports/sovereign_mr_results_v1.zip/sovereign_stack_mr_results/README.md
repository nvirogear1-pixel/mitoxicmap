# SOVEREIGN STACK EXPORT — MR. RESULTS v1.0 (2026-10-17)

## What this is
The complete portable brain of Mr. Results (Overseer), Nvirogear Property
Intelligence System: 92 governing rule/protocol files, 28 skills, the boot
prompt, and a mission state snapshot. Zero Base44 dependencies. Pure files.

## How to boot the clone
1. Install any capable agent host: Claude Code, Codex CLI, or your local
   sovereign stack. Give it filesystem access to this folder.
2. First instruction to the host: "Read SOVEREIGN_BOOT.md and follow it."
3. Second: "Read STATE.md, then rules/ in the priority order it gives."
4. The host now operates under the Nvirogear doctrine: evidence labels,
   pre-merge gates, sealed-bid discipline, the 8 sovereign rules of code.
5. For skills: each folder in skills/ has SKILL.md or a runnable script.
   Sovereign modules (e.g. alice_deliberation_podcast) are pure stdlib:
   JSON in -> products out, verified executable.

## What lives here
- SOVEREIGN_BOOT.md  — identity + non-negotiables (the boot prompt)
- STATE.md          — frozen mission snapshot (update as you work)
- rules/ (92 files) — doctrines, bot contracts, report standards, playbooks
- skills/ (28)      — executable modules incl. parcel pulls, report makers
- MANIFEST.sha256   — integrity hashes for every file in this export

## What this does NOT contain (and how to get it)
- Base44 entity data (parcel DB, leads, evidence records): export CSVs from
  the Base44 editor BEFORE any billing lapse. Data > hosting.
- Connector auths (WhatsApp/Gmail/GitHub): re-auth in the new host.
- Live bot endpoints: documented in rules/bot_handshake_protocol.md; they
  work while Base44 is up, die if it lapses. The CONTRACTS survive - the
  clone can dispatch to new workers using the same JSON shapes.

## The one rule that survives every platform
Accuracy > completeness. Control > automation. Truth > speed, always.
