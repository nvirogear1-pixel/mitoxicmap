#!/usr/bin/env python3
"""
Michigan Tax Foreclosure & Delinquent Tax Scraper
Nvirogear LLC — Mr. Results Fleet
Version: 1.0 | 2026-05-19

PURPOSE:
  Pull publicly available delinquent/forfeited/foreclosed parcel lists from
  Michigan county treasurer sites and cross-reference against existing
  ParcelRecord and ParcelReference data in the Nvirogear system.

DATA SOURCES (all public record):
  1. tax-sale.info — Michigan Public Land Auction (current auction lots)
  2. County treasurer BSA Online portals (delinquent tax search)
  3. County treasurer direct HTML/PDF lists where published
  4. midlandcountymi.gov style direct posting pages

COUNTIES TARGETED (in priority order — matches our existing parcel data):
  1. Mason County     — LIAA connector live, 15+ parcels in system
  2. Muskegon County  — 42K+ parcels in Supabase
  3. Genesee County   — 5 parcels in system
  4. Ottawa County    — Apple Dr / GIS verified parcels
  5. Newaygo County   — 37K+ parcels in Supabase
  6. Lake County      — 26K+ parcels in Supabase

LEGAL BASIS:
  Michigan PA 123 of 1999 — county treasurers must publish delinquent/
  forfeiture/foreclosure lists. All data is public record by Michigan law.
  MCL 211.78 et seq.

USAGE:
  python3 michigan_tax_foreclosure_scraper.py [--county mason] [--mode all]
  
  --county: mason | muskegon | genesee | ottawa | newaygo | lake | all
  --mode: taxsale | bsa | direct | all
"""

import sys
import json
import time
import re
import os
import argparse
from datetime import datetime
from urllib.request import urlopen, Request
from urllib.parse import urlencode, quote_plus
from urllib.error import URLError, HTTPError
import html

# ─── CONFIG ───────────────────────────────────────────────────────────────
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (compatible; NvirogearPropertyBot/1.0; +https://nvirogear.com/bot)',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
}
DELAY_SEC = 2.5   # respectful crawl delay
TIMEOUT   = 15

COUNTY_CONFIG = {
    "mason": {
        "name": "Mason",
        "state": "MI",
        "treasurer_url": "https://www.masoncounty.net/departments/treasurer/foreclosed_property_sales.php",
        "foreclosure_page": "https://www.masoncounty.net/departments/treasurer/property_tax_foreclosure.php",
        "taxsale_catalog_id": "1331",  # tax-sale.info catalog for Mason
        "bsa_municipality": "Mason County",
        "liaa_base": "https://maps.liaa.org/masonparcels/cc/dbviewer/",
        "gis_arcgis": None,   # LIAA only
        "notes": "LIAA connector live. August auction. Judicial foreclosure Feb 2025."
    },
    "muskegon": {
        "name": "Muskegon",
        "state": "MI",
        "treasurer_url": "https://co.muskegon.mi.us/886/Treasurer",
        "bsa_url": "https://bsaonline.com/",
        "bsa_municipality": "Muskegon County",
        "taxsale_catalog_id": None,
        "gis_arcgis": "https://gis.co.muskegon.mi.us/arcgis/rest/services",
        "notes": "42K+ parcels in Supabase. BSA Online for delinquent search."
    },
    "genesee": {
        "name": "Genesee",
        "state": "MI",
        "treasurer_url": "https://www.geneseecountymi.gov/departments/treasurer/index.php",
        "bsa_url": "https://bsaonline.com/",
        "bsa_municipality": "Genesee County",
        "taxsale_catalog_id": None,
        "notes": "Genesee/Flint area. High foreclosure volume historically."
    },
    "ottawa": {
        "name": "Ottawa",
        "state": "MI",
        "treasurer_url": "https://miottawa.org/treasurer/delinquent/",
        "bsa_url": "https://bsaonline.com/",
        "bsa_municipality": "Ottawa County",
        "taxsale_catalog_id": None,
        "gis_arcgis": "https://gis-ottawacountymi.hub.arcgis.com",
        "notes": "Apple Dr parcels here. Ottawa forecloses end of March annually."
    },
    "newaygo": {
        "name": "Newaygo",
        "state": "MI",
        "treasurer_url": "https://www.newaygocountymi.gov/departments/treasurer/",
        "bsa_municipality": "Newaygo County",
        "taxsale_catalog_id": None,
        "notes": "37K+ parcels in Supabase."
    },
    "lake": {
        "name": "Lake",
        "state": "MI",
        "treasurer_url": "https://www.lakecountymi.gov/",
        "bsa_municipality": "Lake County",
        "taxsale_catalog_id": None,
        "notes": "26K+ parcels in Supabase. Rural western MI."
    }
}

TAXSALE_BASE = "https://www.tax-sale.info"

# ─── UTILITIES ────────────────────────────────────────────────────────────

def fetch(url, retries=2):
    """Polite fetch with retry."""
    for attempt in range(retries + 1):
        try:
            req = Request(url, headers=HEADERS)
            with urlopen(req, timeout=TIMEOUT) as resp:
                content = resp.read()
                charset = resp.headers.get_content_charset() or 'utf-8'
                return content.decode(charset, errors='replace')
        except HTTPError as e:
            print(f"  HTTP {e.code} on {url}")
            if e.code in (403, 429) and attempt < retries:
                time.sleep(DELAY_SEC * 3)
            elif e.code == 404:
                return None
        except URLError as e:
            print(f"  URLError: {e.reason} on {url}")
            if attempt < retries:
                time.sleep(DELAY_SEC * 2)
        except Exception as e:
            print(f"  Error: {e} on {url}")
        time.sleep(DELAY_SEC)
    return None


def clean(text):
    """Strip HTML entities and extra whitespace."""
    if not text:
        return ""
    text = html.unescape(text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def extract_dollar(text):
    """Extract first dollar amount from text."""
    m = re.search(r'\$[\d,]+(?:\.\d{2})?', text)
    if m:
        return float(m.group(0).replace('$','').replace(',',''))
    return None


def now_iso():
    return datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')


# ─── SCRAPER 1: tax-sale.info ─────────────────────────────────────────────

def scrape_taxsale_catalog(catalog_id, county_name, state="MI"):
    """
    Pull current auction lots from tax-sale.info for a given catalog.
    Returns list of TaxForeclosureTarget-ready dicts.
    """
    url = f"{TAXSALE_BASE}/listings/catalog/{catalog_id}"
    print(f"  [tax-sale.info] Fetching catalog {catalog_id} for {county_name} County...")
    html_content = fetch(url)
    if not html_content:
        return []

    results = []

    # Extract lot blocks — each lot has class "lot-item" or similar
    # tax-sale.info uses lot number + address + min bid pattern
    lot_pattern = re.findall(
        r'lot[_\s/-]?(\d+)[^<]*?</?\w[^>]*?>([^<]+?(?:Rd|St|Ave|Dr|Ln|Blvd|Hwy|M-\d+|County)[^<]*?)<.*?Minimum Bid[:\s]*\$?([\d,]+)',
        html_content, re.IGNORECASE | re.DOTALL
    )

    # Simpler pattern: look for lot rows
    rows = re.findall(
        r'Lot\s+(\d+)[^\n]*?\n([^\n]+?(?:Parcel|Lot|Vacant|Home|Building|Acres?)[^\n]*?)\n.*?(?:Minimum Bid|Min(?:imum)?)[:\s]*\$?([\d,\.]+)',
        html_content, re.IGNORECASE | re.DOTALL
    )

    # Try parsing all <a> links that look like lot detail pages
    lot_links = re.findall(r'href="(/lot/\d+[^"]*)"', html_content)
    lot_links = list(set(lot_links))[:50]  # cap at 50 per catalog

    print(f"  Found {len(lot_links)} lot detail links")

    for link in lot_links[:20]:  # limit for polite crawl
        lot_url = TAXSALE_BASE + link
        lot_html = fetch(lot_url)
        if not lot_html:
            continue

        record = parse_taxsale_lot(lot_html, lot_url, county_name, state)
        if record:
            results.append(record)
            print(f"    ✓ Lot: {record.get('situs_address','unknown')} | Min Bid: ${record.get('auction_min_bid','?')}")

        time.sleep(DELAY_SEC)

    return results


def parse_taxsale_lot(html_content, lot_url, county_name, state):
    """Parse a single tax-sale.info lot detail page."""
    record = {
        "county": county_name,
        "state": state,
        "source_name": "tax-sale.info",
        "source_url": lot_url,
        "source_confidence": "PUBLIC REFERENCE",
        "forfeiture_status": "auction_scheduled",
        "status": "raw",
        "last_scraped_at": now_iso(),
        "parcel_record_matched": False,
        "gis_bot_run": False,
        "historian_bot_run": False,
    }

    # Parcel ID
    pid = re.search(r'Parcel\s+(?:ID|Number|#)[:\s]+([A-Z0-9\-]+)', html_content, re.IGNORECASE)
    if pid:
        record['parcel_id'] = clean(pid.group(1))

    # Address
    addr = re.search(r'(?:Address|Location)[:\s]+([^\n<]+)', html_content, re.IGNORECASE)
    if addr:
        record['situs_address'] = clean(addr.group(1))

    # Acreage
    acres = re.search(r'([\d.]+)\s+[Aa]cres?', html_content)
    if acres:
        record['acreage'] = float(acres.group(1))

    # Min bid
    min_bid = re.search(r'[Mm]inimum\s+[Bb]id[:\s]*\$?([\d,]+(?:\.\d{2})?)', html_content)
    if min_bid:
        record['auction_min_bid'] = float(min_bid.group(1).replace(',',''))

    # Auction date
    adate = re.search(r'(?:Auction|Sale)\s+Date[:\s]+([A-Za-z]+\s+\d{1,2},?\s+\d{4})', html_content)
    if adate:
        record['auction_date'] = clean(adate.group(1))

    # Owner
    owner = re.search(r'(?:Owner|Grantor)[:\s]+([^\n<]{4,60})', html_content, re.IGNORECASE)
    if owner:
        record['owner_name'] = clean(owner.group(1))

    record['auction_url'] = lot_url

    # Need at least address or parcel ID to be useful
    if not record.get('parcel_id') and not record.get('situs_address'):
        return None

    return record


# ─── SCRAPER 2: County Treasurer Direct Page ──────────────────────────────

def scrape_treasurer_page(county_key):
    """
    Pull delinquent/foreclosure information from county treasurer pages.
    Returns structured data + links to any downloadable lists.
    """
    config = COUNTY_CONFIG[county_key]
    url = config['treasurer_url']
    print(f"  [Treasurer] Fetching {config['name']} County treasurer page...")

    html_content = fetch(url)
    if not html_content:
        return {"county": config['name'], "error": "Could not fetch page", "links": []}

    result = {
        "county": config['name'],
        "state": config['state'],
        "source_url": url,
        "scraped_at": now_iso(),
        "downloadable_lists": [],
        "auction_info": {},
        "raw_parcels": []
    }

    # Look for downloadable files (CSV, XLS, XLSX, PDF with parcel data)
    file_links = re.findall(
        r'href="([^"]+\.(?:csv|xlsx?|pdf)[^"]*)"[^>]*>[^<]*(?:delinquent|foreclos|forfeiture|parcel|list|auction)',
        html_content, re.IGNORECASE
    )
    file_links += re.findall(
        r'href="([^"]+)"[^>]*>[^<]*(?:delinquent|foreclos|forfeiture|parcel|list|auction)[^<]*\.(?:csv|xlsx?|pdf)',
        html_content, re.IGNORECASE
    )

    for link in set(file_links):
        if not link.startswith('http'):
            base = re.match(r'(https?://[^/]+)', url).group(1)
            link = base + '/' + link.lstrip('/')
        result['downloadable_lists'].append(link)
        print(f"    📄 Found downloadable list: {link}")

    # Auction date extraction
    auction_matches = re.findall(
        r'(?:auction|sale|hearing)[^\n]*?(?:scheduled|set for|held)[^\n]*?([A-Za-z]+\s+\d{1,2},?\s+\d{4})',
        html_content, re.IGNORECASE
    )
    if auction_matches:
        result['auction_info']['dates_found'] = [clean(d) for d in auction_matches[:5]]

    # Phone number
    phone = re.search(r'(\d{3}[-.\s]\d{3}[-.\s]\d{4})', html_content)
    if phone:
        result['auction_info']['treasurer_phone'] = phone.group(1)

    # Look for embedded parcel tables
    tables = re.findall(r'<table[^>]*>(.*?)</table>', html_content, re.DOTALL | re.IGNORECASE)
    for table in tables:
        rows = re.findall(r'<tr[^>]*>(.*?)</tr>', table, re.DOTALL | re.IGNORECASE)
        if len(rows) > 2:
            cells_per_row = [re.findall(r'<t[dh][^>]*>(.*?)</t[dh]>', row, re.DOTALL | re.IGNORECASE) for row in rows]
            for row_cells in cells_per_row:
                cleaned = [re.sub(r'<[^>]+>', '', c).strip() for c in row_cells]
                # Look for rows that might have parcel-like data
                row_text = ' '.join(cleaned)
                if re.search(r'\d{3}-\d{3}-\d{3}', row_text) or '$' in row_text:
                    result['raw_parcels'].append(cleaned)

    return result


# ─── SCRAPER 3: BSA Online Delinquent Search ──────────────────────────────

def build_bsa_delinquent_url(municipality_name):
    """Build BSA Online URL for delinquent tax search."""
    # BSA Online delinquent tax search — county-level
    encoded = quote_plus(municipality_name)
    return f"https://bsaonline.com/SiteSearch/SiteSearchIndex?SearchCategory=TaxRoll&TaxYear=2024&SearchText=&Locality={encoded}"


def note_bsa_limitation():
    """BSA Online requires JavaScript — note this as a manual verification item."""
    return {
        "source": "BSA Online",
        "note": "BSA Online requires JavaScript rendering. Cannot pull directly. Manual step: go to bsaonline.com, search municipality, filter by 'Delinquent' status, export CSV.",
        "manual_url": "https://bsaonline.com/",
        "workaround": "Use michigan_county_parcel_pull.py ArcGIS endpoint for parcel data, then cross-reference against county treasurer page for delinquent status.",
        "status": "MANUAL_VERIFICATION_REQUIRED"
    }


# ─── CROSS-REFERENCE ENGINE ───────────────────────────────────────────────

def cross_reference_parcels(foreclosure_targets, existing_parcels):
    """
    Match TaxForeclosureTarget records against existing ParcelRecord data.
    Matching strategy:
      1. Exact parcel_id match
      2. Normalized address fuzzy match
      3. Coordinate proximity (if both have lat/lng)
    Returns enriched foreclosure_targets with match flags.
    """
    # Build lookup indexes
    by_id = {p.get('parcel_id','').upper(): p for p in existing_parcels if p.get('parcel_id')}
    by_addr = {}
    for p in existing_parcels:
        if p.get('address'):
            norm = re.sub(r'[^A-Z0-9]', '', p['address'].upper())
            by_addr[norm] = p

    matched = 0
    for target in foreclosure_targets:
        pid = (target.get('parcel_id') or '').upper()
        addr = (target.get('situs_address') or '').upper()
        addr_norm = re.sub(r'[^A-Z0-9]', '', addr)

        # Try exact ID match
        if pid and pid in by_id:
            existing = by_id[pid]
            target['parcel_record_matched'] = True
            target['parcel_record_id'] = existing.get('id', '')
            if existing.get('gis_lat'):
                target['centroid_lat'] = existing['gis_lat']
                target['centroid_lng'] = existing['gis_lng']
            if existing.get('gis_polygon'):
                target['polygon_geojson'] = existing['gis_polygon']
                target['has_polygon'] = True
            if existing.get('acreage') and not target.get('acreage'):
                target['acreage'] = existing['acreage']
            matched += 1
            continue

        # Try normalized address match
        if addr_norm and len(addr_norm) > 8:
            for known_addr, existing in by_addr.items():
                if addr_norm in known_addr or known_addr in addr_norm:
                    target['parcel_record_matched'] = True
                    target['parcel_record_id'] = existing.get('id', '')
                    if existing.get('gis_lat'):
                        target['centroid_lat'] = existing['gis_lat']
                        target['centroid_lng'] = existing['gis_lng']
                    matched += 1
                    break

    print(f"  Cross-reference: {matched}/{len(foreclosure_targets)} matched to existing parcel records")
    return foreclosure_targets


def score_target(target):
    """
    Simple deal score for a TaxForeclosureTarget.
    0-100. Higher = better acquisition opportunity.
    """
    score = 50  # base

    # Auction min bid vs assessed value signal
    min_bid = target.get('auction_min_bid', 0) or 0
    assessed = target.get('assessed_value', 0) or 0
    if min_bid and assessed:
        ratio = min_bid / assessed
        if ratio < 0.3:
            score += 20   # deep discount to assessed
        elif ratio < 0.5:
            score += 10
        elif ratio > 1.0:
            score -= 10   # bid above assessed

    # Parcel record match = more data = better signal
    if target.get('parcel_record_matched'):
        score += 10

    # Has geometry = mappable
    if target.get('has_polygon') or (target.get('centroid_lat') and target.get('centroid_lng')):
        score += 5

    # Acreage signal
    acres = target.get('acreage', 0) or 0
    if acres >= 5:
        score += 5
    if acres >= 20:
        score += 5

    # Years delinquent — more years = more motivated/distressed
    years = target.get('years_delinquent', 0) or 0
    if years >= 2:
        score += 5
    if years >= 3:
        score += 5

    # Cap at 100
    score = min(100, max(0, score))
    target['deal_score'] = score
    target['opportunity_signal'] = (
        "high" if score >= 70 else
        "medium" if score >= 50 else
        "low"
    )
    return target


# ─── OUTPUT ───────────────────────────────────────────────────────────────

def print_summary(targets, treasurer_results):
    """Print a clean summary of what was found."""
    print("\n" + "="*70)
    print("NVIROGEAR TAX FORECLOSURE INTELLIGENCE — RUN SUMMARY")
    print("="*70)

    print(f"\n📋 Treasurer Pages Checked: {len(treasurer_results)}")
    for tr in treasurer_results:
        print(f"  {tr.get('county','?')} County:")
        if tr.get('downloadable_lists'):
            for dl in tr['downloadable_lists']:
                print(f"    📄 Download: {dl}")
        if tr.get('auction_info', {}).get('dates_found'):
            for d in tr['auction_info']['dates_found']:
                print(f"    📅 Auction date found: {d}")
        if tr.get('auction_info', {}).get('treasurer_phone'):
            print(f"    📞 Treasurer: {tr['auction_info']['treasurer_phone']}")

    print(f"\n🎯 Foreclosure Targets Scraped: {len(targets)}")
    matched = sum(1 for t in targets if t.get('parcel_record_matched'))
    print(f"  ✅ Matched to existing parcel records: {matched}")
    print(f"  ⏳ New parcels (no match): {len(targets) - matched}")

    high = [t for t in targets if t.get('opportunity_signal') == 'high']
    med = [t for t in targets if t.get('opportunity_signal') == 'medium']
    print(f"\n🔥 High Opportunity: {len(high)}")
    print(f"⚡ Medium Opportunity: {len(med)}")

    if high:
        print("\n── TOP HIGH-OPPORTUNITY TARGETS ──")
        for t in sorted(high, key=lambda x: x.get('deal_score',0), reverse=True)[:10]:
            print(f"  [{t.get('deal_score','?')}/100] {t.get('situs_address','?')} | "
                  f"{t.get('county','?')} Co. | "
                  f"Min Bid: ${t.get('auction_min_bid','?')} | "
                  f"Parcel: {t.get('parcel_id','?')} | "
                  f"Match: {'✅' if t.get('parcel_record_matched') else '⬜'}")

    print("\n── BSA ONLINE NOTE ──")
    bsa = note_bsa_limitation()
    print(f"  {bsa['note']}")
    print(f"  Manual URL: {bsa['manual_url']}")

    print("\n── NEXT ACTIONS ──")
    print("  1. Review downloadable lists above — download CSV/Excel if available")
    print("  2. Dispatch Jet (GIS Bot) on all targets with parcel_id but no geometry")
    print("  3. Dispatch Historian on all high/medium opportunity targets")
    print("  4. Manually check BSA Online for county delinquent rolls")
    print("  5. Load targets into TaxForeclosureTarget entity via pipelineIngest")
    print("="*70)


def save_output(targets, treasurer_results, county_key):
    """Save results to JSON for review and entity loading."""
    output = {
        "run_at": now_iso(),
        "county": county_key,
        "targets": targets,
        "treasurer_pages": treasurer_results,
        "bsa_note": note_bsa_limitation(),
        "total_targets": len(targets),
        "matched_to_existing": sum(1 for t in targets if t.get('parcel_record_matched')),
        "high_opportunity": sum(1 for t in targets if t.get('opportunity_signal') == 'high'),
        "medium_opportunity": sum(1 for t in targets if t.get('opportunity_signal') == 'medium'),
    }
    fname = f"tax_foreclosure_{county_key}_{datetime.utcnow().strftime('%Y%m%d')}.json"
    with open(fname, 'w') as f:
        json.dump(output, f, indent=2)
    print(f"\n✅ Output saved: {fname}")
    return fname


# ─── MAIN ─────────────────────────────────────────────────────────────────

def run(county_key="mason", mode="all", existing_parcels=None):
    """Main run function."""
    existing_parcels = existing_parcels or []

    if county_key == "all":
        counties = list(COUNTY_CONFIG.keys())
    else:
        counties = [county_key]

    all_targets = []
    all_treasurer = []

    for ck in counties:
        config = COUNTY_CONFIG.get(ck)
        if not config:
            print(f"Unknown county: {ck}")
            continue

        print(f"\n{'='*50}")
        print(f"COUNTY: {config['name'].upper()} — {config['state']}")
        print(f"{'='*50}")

        # 1. Treasurer page
        tr = scrape_treasurer_page(ck)
        all_treasurer.append(tr)
        time.sleep(DELAY_SEC)

        # 2. tax-sale.info catalog if available
        targets = []
        if config.get('taxsale_catalog_id') and mode in ('taxsale', 'all'):
            catalog_targets = scrape_taxsale_catalog(
                config['taxsale_catalog_id'],
                config['name'],
                config['state']
            )
            targets.extend(catalog_targets)
            time.sleep(DELAY_SEC)

        # 3. Cross-reference against existing parcel records
        if targets and existing_parcels:
            targets = cross_reference_parcels(targets, existing_parcels)

        # 4. Score each target
        targets = [score_target(t) for t in targets]
        all_targets.extend(targets)

        print(f"  {config['name']}: {len(targets)} targets found")

    # Summary + save
    print_summary(all_targets, all_treasurer)
    output_file = save_output(all_targets, all_treasurer, county_key)

    return {
        "targets": all_targets,
        "treasurer_pages": all_treasurer,
        "output_file": output_file,
        "total": len(all_targets),
        "high_opp": sum(1 for t in all_targets if t.get('opportunity_signal') == 'high')
    }


# ─── ENTRY POINT ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Michigan Tax Foreclosure Scraper')
    parser.add_argument('--county', default='mason',
                        help='County key: mason|muskegon|genesee|ottawa|newaygo|lake|all')
    parser.add_argument('--mode', default='all',
                        help='Scrape mode: taxsale|bsa|direct|all')
    args = parser.parse_args()

    print(f"Nvirogear Tax Foreclosure Scraper v1.0")
    print(f"County: {args.county} | Mode: {args.mode}")
    print(f"Run time: {datetime.utcnow().isoformat()}Z\n")

    result = run(county_key=args.county, mode=args.mode)
    print(f"\nDone. Total targets: {result['total']} | High opp: {result['high_opp']}")
