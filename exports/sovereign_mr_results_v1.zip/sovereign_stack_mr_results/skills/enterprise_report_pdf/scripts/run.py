#!/usr/bin/env python3
"""
Enterprise Property Intelligence Report — PDF Generator
Mr. Results (Overseer) — N-ViroGear Land Intelligence System

Usage:
  python run.py --parcel_id "APN" --report_json "/path/report.json" --output "/path/out.pdf"

The report_json must conform to the compiled report schema (see SKILL.md).
All sections are optional — missing sections render as "Pending Bot Input".
"""

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

# ── ReportLab imports ────────────────────────────────────────────────────────
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib.colors import HexColor, white, black
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, HRFlowable, KeepTogether
)

# ── Palette ──────────────────────────────────────────────────────────────────
NAVY      = HexColor("#1a2332")
DARK_BLUE = HexColor("#2c3e50")
ACCENT    = HexColor("#2980b9")
GREEN     = HexColor("#27ae60")
ORANGE    = HexColor("#e67e22")
RED_C     = HexColor("#c0392b")
LIGHT_BG  = HexColor("#ecf0f1")
LIGHT_ROW = HexColor("#f8f9fa")
GRAY_TXT  = HexColor("#555555")
MID_GRAY  = HexColor("#888888")
RULE_GRAY = HexColor("#aaaaaa")
BORDER    = HexColor("#cccccc")
STRIPE    = HexColor("#f8f9fa")


# ── Style factory ────────────────────────────────────────────────────────────
def make_styles():
    base = getSampleStyleSheet()
    def P(name, parent="Normal", **kw):
        return ParagraphStyle(name, parent=base[parent], **kw)

    return dict(
        report_title = P("rt", "Title",
            fontName="Helvetica-Bold", fontSize=22, textColor=NAVY,
            spaceAfter=4, alignment=TA_LEFT),
        subtitle = P("sub", fontSize=11, textColor=ACCENT, spaceAfter=12),
        section   = P("sec", "Heading2",
            fontName="Helvetica-Bold", fontSize=14, textColor=NAVY,
            spaceBefore=16, spaceAfter=8),
        subsec    = P("ssec", "Heading3",
            fontName="Helvetica-Bold", fontSize=11, textColor=DARK_BLUE,
            spaceBefore=10, spaceAfter=4),
        body      = P("bod", fontSize=9.5, leading=13, spaceAfter=6),
        body_bold = P("bbd", fontSize=9.5, leading=13, fontName="Helvetica-Bold"),
        small     = P("sml", fontSize=8, leading=10, textColor=GRAY_TXT),
        callout   = P("cll", fontSize=10, leading=14, fontName="Helvetica-Bold",
            textColor=NAVY, backColor=LIGHT_BG, borderPadding=8,
            spaceBefore=8, spaceAfter=8),
        green     = P("grn", fontSize=9.5, textColor=GREEN, fontName="Helvetica-Bold"),
        orange    = P("orn", fontSize=9.5, textColor=ORANGE, fontName="Helvetica-Bold"),
        red       = P("red", fontSize=9.5, textColor=RED_C, fontName="Helvetica-Bold"),
        footer    = P("ftr", fontSize=7.5, textColor=MID_GRAY,
            fontName="Helvetica-Oblique", alignment=TA_CENTER),
        pending   = P("pnd", fontSize=9.5, textColor=MID_GRAY,
            fontName="Helvetica-Oblique"),
        conf_high   = P("ch", fontSize=9, textColor=GREEN, fontName="Helvetica-Bold"),
        conf_med    = P("cm", fontSize=9, textColor=ORANGE, fontName="Helvetica-Bold"),
        conf_low    = P("cl", fontSize=9, textColor=RED_C, fontName="Helvetica-Bold"),
        conf_adv    = P("ca", fontSize=9, textColor=ACCENT, fontName="Helvetica-Bold"),
    )


# ── Table helper ─────────────────────────────────────────────────────────────
def tbl(data, col_widths=None, header=True):
    t = Table(data, colWidths=col_widths, hAlign="LEFT")
    cmds = [
        ("FONTNAME",  (0,0), (-1,-1), "Helvetica"),
        ("FONTSIZE",  (0,0), (-1,-1), 9),
        ("VALIGN",    (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING",  (0,0), (-1,-1), 6),
        ("RIGHTPADDING", (0,0), (-1,-1), 6),
        ("TOPPADDING",   (0,0), (-1,-1), 4),
        ("BOTTOMPADDING",(0,0), (-1,-1), 4),
        ("GRID", (0,0), (-1,-1), 0.5, BORDER),
    ]
    if header and len(data) > 0:
        cmds += [
            ("BACKGROUND",  (0,0), (-1,0), NAVY),
            ("TEXTCOLOR",   (0,0), (-1,0), white),
            ("FONTNAME",    (0,0), (-1,0), "Helvetica-Bold"),
        ]
    for i in range(1, len(data)):
        if i % 2 == 0:
            cmds.append(("BACKGROUND", (0,i), (-1,i), STRIPE))
    t.setStyle(TableStyle(cmds))
    return t


def hr(color=ACCENT):
    return HRFlowable(width="100%", thickness=1, color=color,
                      spaceBefore=4, spaceAfter=8)


def pending_block(section_name, styles):
    return Paragraph(
        f"⏳ {section_name} — Pending Bot Input. "
        "Data not yet received from the relevant specialist. "
        "This section will populate on next full consultation cycle.",
        styles["pending"]
    )


def conf_label(label, styles):
    label = (label or "").strip()
    mapping = {
        "verified":            ("✅ Verified",           "conf_high"),
        "likely":              ("🟡 Likely",             "conf_med"),
        "estimated":           ("📊 Estimated",          "conf_med"),
        "conflicting":         ("⚠️ Conflicting",        "conf_low"),
        "pending verification":("🔍 Pending Verification","conf_low"),
        "advisory":            ("💡 Advisory",           "conf_adv"),
        "high":                ("✅ High",               "conf_high"),
        "medium":              ("🟡 Medium",             "conf_med"),
        "low":                 ("🔴 Low",               "conf_low"),
        "medium-high":         ("🟡 Medium-High",        "conf_med"),
        "medium-low":          ("🔴 Medium-Low",         "conf_low"),
    }
    key = label.lower()
    text, style_key = mapping.get(key, (label, "body"))
    return Paragraph(text, styles.get(style_key, styles["body"]))


# ═════════════════════════════════════════════════════════════════════════════
# MAIN BUILDER
# ═════════════════════════════════════════════════════════════════════════════
def build_pdf(report: dict, output_path: str):
    styles = make_styles()
    story  = []

    meta    = report.get("meta", {})
    gis     = report.get("gis", {})
    assessor= report.get("assessor", {})
    market  = report.get("market", {})
    environ = report.get("environmental", {})
    neighbor= report.get("neighborhood", {})
    strategy= report.get("strategy", {})
    extras  = report.get("extras", {})   # improvements, risks, comps override

    address    = meta.get("address", "Address Pending")
    parcel_id  = meta.get("parcel_id", "APN Pending")
    county     = meta.get("county", "County Pending")
    prepared_for = meta.get("prepared_for", "Nvirogear LLC — Confidential")
    report_type  = meta.get("report_type", "Full Intelligence")
    report_date  = meta.get("report_date") or datetime.now().strftime("%B %d, %Y")
    report_id    = meta.get("report_id") or f"NVI-{datetime.now().strftime('%Y%m%d-%H%M')}"

    # ── COVER ────────────────────────────────────────────────────────────────
    story.append(Paragraph("PROPERTY INTELLIGENCE REPORT", styles["report_title"]))
    story.append(Paragraph(address, styles["subtitle"]))
    story.append(hr())

    cover_rows = [
        ["Report Date",   report_date],
        ["Report ID",     report_id],
        ["Report Type",   report_type],
        ["APN / Parcel ID", parcel_id],
        ["County",        county],
        ["Prepared For",  prepared_for],
        ["Prepared By",   "Mr. Results (Overseer) — N-ViroGear Land Intelligence System"],
        ["Powered By",    "Nvirogear LLC"],
    ]
    if meta.get("owner"):
        cover_rows.insert(4, ["Owner of Record", meta["owner"]])
    ct = Table(cover_rows, colWidths=[1.8*inch, 4.7*inch], hAlign="LEFT")
    ct.setStyle(TableStyle([
        ("FONTNAME",  (0,0), (0,-1), "Helvetica-Bold"),
        ("FONTNAME",  (1,0), (1,-1), "Helvetica"),
        ("FONTSIZE",  (0,0), (-1,-1), 9.5),
        ("TEXTCOLOR", (0,0), (0,-1), NAVY),
        ("TOPPADDING",(0,0), (-1,-1), 3),
        ("BOTTOMPADDING",(0,0),(-1,-1), 3),
        ("LINEBELOW", (0,0), (-1,-2), 0.5, HexColor("#dddddd")),
    ]))
    story.append(ct)
    story.append(Spacer(1, 8))

    # Source count + freshness
    sources_used = meta.get("sources_used", [])
    source_count = len(sources_used) if sources_used else "Multiple"
    story.append(Paragraph(
        f"Sources consulted: {source_count}  |  "
        f"Data freshness: {meta.get('data_freshness', 'Current session')}  |  "
        f"Overall confidence: {meta.get('overall_confidence', 'Medium')}",
        styles["small"]
    ))

    # ── SECTION 2: EXECUTIVE DECISION SUMMARY ────────────────────────────────
    story.append(PageBreak())
    story.append(Paragraph("2. EXECUTIVE DECISION SUMMARY", styles["section"]))
    story.append(hr())

    exec_sum = report.get("executive_summary", {})
    if exec_sum:
        val_range = exec_sum.get("value_range", "")
        equity    = exec_sum.get("equity_position", "")
        best_move = exec_sum.get("best_move", "")
        best_why  = exec_sum.get("best_move_reason", "")

        if val_range:
            story.append(Paragraph(f"Estimated Value Range: {val_range}", styles["body_bold"]))
        if equity:
            story.append(Paragraph(f"Equity Position: {equity}", styles["body_bold"]))

        if best_move:
            story.append(Paragraph(f"Best Move: {best_move}", styles["callout"]))
        if best_why:
            story.append(Paragraph(best_why, styles["body"]))

        risks = exec_sum.get("top_risks", [])
        drivers = exec_sum.get("top_value_drivers", [])
        if risks:
            story.append(Paragraph("Top Risks:", styles["body_bold"]))
            for i, r in enumerate(risks[:3], 1):
                story.append(Paragraph(f"{i}. {r}", styles["body"]))
        if drivers:
            story.append(Paragraph("Top Value Drivers:", styles["body_bold"]))
            for i, d in enumerate(drivers[:3], 1):
                story.append(Paragraph(f"{i}. {d}", styles["body"]))
    else:
        story.append(pending_block("Executive Decision Summary", styles))

    # ── SECTION 3: CONFIDENCE DASHBOARD ──────────────────────────────────────
    story.append(Paragraph("3. CONFIDENCE DASHBOARD", styles["section"]))
    story.append(hr())

    conf_dashboard = report.get("confidence_dashboard", {
        "Parcel Identity":    {"status": "Matched" if gis else "Pending", "confidence": "High" if gis else "Pending Verification"},
        "Geometry":           {"status": "Polygon" if gis.get("geometry_type","").lower()=="polygon" else "Centroid Only" if gis else "Pending", "confidence": gis.get("geometry_confidence","Pending Verification") if gis else "Pending Verification"},
        "Tax Record":         {"status": "Available" if assessor else "Pending", "confidence": assessor.get("confidence","Pending Verification") if assessor else "Pending Verification"},
        "Market Value":       {"status": "Estimated" if market else "Pending", "confidence": "Estimated" if market else "Pending Verification"},
        "Environmental":      {"status": "Screened" if environ else "Pending", "confidence": environ.get("confidence","Pending Verification") if environ else "Pending Verification"},
        "Flood / Wetland":    {"status": environ.get("flood_zone","Pending") if environ else "Pending", "confidence": "Verified" if environ.get("flood_zone") else "Pending Verification"},
        "Neighborhood":       {"status": "Available" if neighbor else "Pending", "confidence": neighbor.get("confidence","Pending Verification") if neighbor else "Pending Verification"},
        "Owner Strategy":     {"status": "Advisory" if strategy else "Pending", "confidence": "Advisory"},
    })

    conf_rows = [["Category", "Status", "Confidence"]]
    for cat, vals in conf_dashboard.items():
        conf_rows.append([cat, vals.get("status","—"), vals.get("confidence","—")])
    story.append(tbl(conf_rows, col_widths=[2.0*inch, 2.0*inch, 2.5*inch]))

    # ── SECTION 4: PROPERTY SNAPSHOT ─────────────────────────────────────────
    story.append(Paragraph("4. PROPERTY SNAPSHOT", styles["section"]))
    story.append(hr())

    snap = report.get("property_snapshot", {})
    if snap or assessor or gis or meta:
        rows = [["Field", "Value", "Source", "Confidence"]]
        fields = [
            ("Address",       snap.get("address") or meta.get("address"), "Address Record", "Verified"),
            ("APN",           snap.get("parcel_id") or meta.get("parcel_id"), "County GIS", "Verified"),
            ("Owner of Record",snap.get("owner") or assessor.get("owner") or meta.get("owner"), "County Assessor", "Verified"),
            ("Municipality",  snap.get("municipality") or gis.get("municipality"), "GIS", "Verified"),
            ("Zoning",        snap.get("zoning") or gis.get("zoning"), "Local Zoning", "Verified"),
            ("Property Class",snap.get("property_class") or assessor.get("property_class"), "Assessor", "Verified"),
            ("Year Built",    snap.get("year_built") or assessor.get("year_built"), "Assessor", "Verified"),
            ("Bedrooms/Baths",snap.get("beds_baths"), "Assessor/Listing", "Likely"),
            ("Square Footage",snap.get("sqft") or assessor.get("sqft"), "Assessor", "Likely"),
            ("Basement",      snap.get("basement"), "Assessor", "Likely"),
            ("Garage",        snap.get("garage"), "Assessor", "Likely"),
            ("Utilities",     snap.get("utilities"), "Listing/Assessor", "Likely"),
            ("Lot Size",      snap.get("lot_size") or gis.get("acreage"), "GIS/Assessor", "Verified"),
            ("Legal Description", snap.get("legal_description"), "Assessor", "Verified"),
        ]
        for label, val, src, conf in fields:
            if val:
                rows.append([label, str(val), src, conf])
        story.append(tbl(rows, col_widths=[1.6*inch, 2.5*inch, 1.4*inch, 1.0*inch]))
    else:
        story.append(pending_block("Property Snapshot", styles))

    # ── SECTION 5: PARCEL & GIS INTELLIGENCE ─────────────────────────────────
    story.append(Paragraph("5. PARCEL & GIS INTELLIGENCE", styles["section"]))
    story.append(hr())

    if gis:
        gis_rows = [["Field", "Value"]]
        gis_fields = [
            ("Source",            gis.get("source_name", "County ArcGIS GIS")),
            ("APN / PIN",         gis.get("parcel_id", parcel_id)),
            ("Geometry Type",     gis.get("geometry_type","—")),
            ("Geometry Confidence", gis.get("geometry_confidence","—")),
            ("Centroid",          f"{gis.get('centroid_lat','—')}°N, {gis.get('centroid_lng','—')}°W"),
            ("GIS Acreage",       f"{gis.get('acreage','—')} acres"),
            ("Frontage",          gis.get("frontage","—")),
            ("Municipality Code", gis.get("municipality_code","—")),
            ("Easements",         gis.get("easements","None on record")),
            ("Road Access",       gis.get("road_access","Public road")),
        ]
        for k, v in gis_fields:
            if v and v != "—":
                gis_rows.append([k, str(v)])
        story.append(tbl(gis_rows, col_widths=[2.0*inch, 4.5*inch]))

        if gis.get("notes"):
            for note in gis["notes"]:
                story.append(Paragraph(f"• {note}", styles["small"]))
    else:
        story.append(pending_block("Parcel & GIS Intelligence", styles))

    # ── SECTION 6: OWNERSHIP, TAX & ASSESSMENT ───────────────────────────────
    story.append(PageBreak())
    story.append(Paragraph("6. OWNERSHIP, TAX & ASSESSMENT", styles["section"]))
    story.append(hr())

    if assessor:
        tax_rows = [["Field", "Value"]]
        tax_fields = [
            ("Owner of Record",   assessor.get("owner","—")),
            ("Tax Year",          assessor.get("tax_year","—")),
            ("State Equalized Value (SEV)", assessor.get("sev","—")),
            ("Assessed Value",    assessor.get("assessed_value","—")),
            ("Taxable Value",     assessor.get("taxable_value","—")),
            ("Annual Taxes",      assessor.get("annual_tax","—")),
            ("PRE / Homestead",   assessor.get("pre","—")),
            ("Property Class",    assessor.get("property_class","—")),
            ("Year Built",        assessor.get("year_built","—")),
        ]
        for k, v in tax_fields:
            if v and v != "—":
                tax_rows.append([k, str(v)])
        story.append(tbl(tax_rows, col_widths=[2.5*inch, 4.0*inch]))

        if assessor.get("conflicts"):
            story.append(Paragraph("Conflicts Detected:", styles["orange"]))
            for c in assessor["conflicts"]:
                story.append(Paragraph(f"• {c}", styles["body"]))

        if assessor.get("uncapping_note"):
            story.append(Paragraph(assessor["uncapping_note"], styles["callout"]))
    else:
        story.append(pending_block("Ownership, Tax & Assessment", styles))

    # Sale history
    sale_history = market.get("sale_history") or report.get("sale_history", [])
    if sale_history:
        story.append(Paragraph("Sale History:", styles["subsec"]))
        sale_rows = [["Date", "Event", "Price", "List Price", "DOM", "Notes"]]
        for s in sale_history:
            sale_rows.append([
                s.get("date","—"), s.get("event","Sold"),
                s.get("price","—"), s.get("list_price","—"),
                s.get("dom","—"), s.get("notes","")
            ])
        story.append(tbl(sale_rows, col_widths=[0.9*inch, 0.7*inch, 1.0*inch, 1.0*inch, 0.7*inch, 2.2*inch]))

    # ── SECTION 7: VALUATION & MARKET POSITION ───────────────────────────────
    story.append(Paragraph("7. VALUATION & MARKET POSITION", styles["section"]))
    story.append(hr())

    if market:
        val_rows = [["Source", "Estimate", "Confidence"]]
        for avm in market.get("avm_sources", []):
            val_rows.append([avm.get("source","—"), avm.get("estimate","—"), avm.get("confidence","Estimated")])
        if len(val_rows) > 1:
            story.append(tbl(val_rows, col_widths=[2.5*inch, 2.0*inch, 2.0*inch]))

        mkt_rows = [["Metric", "Value", "Trend"]]
        mkt_fields = [
            ("Estimated Value Range",   market.get("estimated_value_range","—"), "—"),
            ("Price per Sqft",          market.get("price_per_sqft","—"), "—"),
            ("Avg Days on Market",      market.get("avg_days_on_market","—"), "—"),
            ("Sale-to-List Ratio",      market.get("sale_to_list_ratio","—"), "—"),
            ("Market Condition",        market.get("market_condition","—"), "—"),
            ("YoY Appreciation",        market.get("yoy_appreciation","—"), "—"),
            ("Suggested List Range",    market.get("suggested_list_range","—"), "—"),
            ("Conservative Value",      market.get("conservative_value","—"), "—"),
            ("Aggressive Value",        market.get("aggressive_value","—"), "—"),
            ("Liquidation Value",       market.get("liquidation_value","—"), "—"),
        ]
        for label, val, trend in mkt_fields:
            if val and val != "—":
                mkt_rows.append([label, str(val), trend])
        if len(mkt_rows) > 1:
            story.append(tbl(mkt_rows, col_widths=[2.2*inch, 1.8*inch, 2.5*inch]))

        if market.get("notes"):
            for n in market["notes"]:
                story.append(Paragraph(n, styles["body"]))
    else:
        story.append(pending_block("Valuation & Market Position", styles))

    # ── SECTION 8: COMPARABLE SALES ──────────────────────────────────────────
    story.append(Paragraph("8. COMPARABLE SALES", styles["section"]))
    story.append(hr())

    comps = market.get("comps") or extras.get("comps", [])
    if comps:
        comp_rows = [["Address", "Sqft", "Bed/Bath", "Sale Date", "Price", "Relevance"]]
        for c in comps:
            comp_rows.append([
                c.get("address","—"), c.get("sqft","—"),
                c.get("beds_baths","—"), c.get("sale_date","—"),
                c.get("price","—"), c.get("relevance","—")
            ])
        story.append(tbl(comp_rows, col_widths=[1.8*inch, 0.7*inch, 0.8*inch, 0.9*inch, 0.9*inch, 1.4*inch]))

        if market.get("comp_value_range"):
            story.append(Paragraph(
                f"Comp-Supported Value Range: {market['comp_value_range']}",
                styles["callout"]
            ))
    else:
        story.append(pending_block("Comparable Sales", styles))

    # ── CONFLICT TABLE (if any conflicts detected) ────────────────────────────
    conflicts = report.get("conflicts", [])
    if conflicts:
        story.append(Paragraph("⚠️ CONFLICT TABLE", styles["section"]))
        story.append(hr(RED_C))
        cf_rows = [["Field", "Source A", "Source B", "Official Preferred", "Final Value", "Confidence"]]
        for c in conflicts:
            cf_rows.append([
                c.get("field","—"), c.get("source_a","—"), c.get("source_b","—"),
                c.get("official_preferred","—"), c.get("final_value","—"),
                c.get("confidence","Conflicting")
            ])
        story.append(tbl(cf_rows, col_widths=[1.2*inch,1.1*inch,1.1*inch,1.2*inch,1.2*inch,0.9*inch]))

    # ── SECTION 9: ENVIRONMENTAL & HAZARD ────────────────────────────────────
    story.append(PageBreak())
    story.append(Paragraph("9. ENVIRONMENTAL & HAZARD INTELLIGENCE", styles["section"]))
    story.append(hr())

    if environ:
        env_rows = [["Field", "Value"]]
        env_fields = [
            ("FEMA Flood Zone",       environ.get("flood_zone","—")),
            ("FIRM Panel",            environ.get("firm_panel","—")),
            ("SFHA (High Risk Zone?)", "No" if environ.get("in_sfha") == False else environ.get("in_sfha","—")),
            ("Flood Insurance Required?", "No" if environ.get("flood_insurance_required") == False else "Yes"),
            ("Wetlands Nearby",       "Yes" if environ.get("wetlands_nearby") else "No"),
            ("Public Water",          "Yes" if environ.get("public_water") else environ.get("water_source","Unknown")),
        ]
        for k, v in env_fields:
            if v and v != "—":
                env_rows.append([k, str(v)])
        story.append(tbl(env_rows, col_widths=[2.5*inch, 4.0*inch]))

        sites = environ.get("contamination_sites", [])
        if sites:
            story.append(Paragraph("Contamination Sites Within Radius:", styles["subsec"]))
            site_rows = [["Distance", "Site", "Risk Level", "Contaminant"]]
            for s in sites:
                site_rows.append([
                    s.get("distance","—"), s.get("site","—"),
                    s.get("risk_level","—"), s.get("contaminant","—")
                ])
            story.append(tbl(site_rows, col_widths=[0.8*inch, 2.0*inch, 1.8*inch, 1.9*inch]))

        if environ.get("risk_summary"):
            story.append(Paragraph(environ["risk_summary"], styles["body"]))

        if environ.get("public_water_mitigation"):
            story.append(Paragraph(
                "Public Water Mitigation: This property is served by public water — "
                "not a private well. Groundwater contamination risk to drinking water "
                "is mitigated by the municipal water supply.",
                styles["callout"]
            ))

        story.append(Paragraph(
            "Disclaimer: No direct environmental impact was confirmed from available "
            "screening data. This is not a Phase I Environmental Site Assessment. "
            "Professional environmental review is recommended before finalizing "
            "any transaction decision.",
            styles["small"]
        ))
    else:
        story.append(pending_block("Environmental & Hazard Intelligence", styles))

    # ── SECTION 10: IMPROVEMENT ROI ───────────────────────────────────────────
    story.append(Paragraph("10. IMPROVEMENT ROI MODEL", styles["section"]))
    story.append(hr())

    improvements = extras.get("improvements") or strategy.get("improvement_priority", [])
    if improvements:
        imp_rows = [["Improvement", "Est. Cost", "Value Added", "ROI Quality", "Risk"]]
        for imp in improvements:
            if isinstance(imp, dict):
                imp_rows.append([
                    imp.get("name","—"), imp.get("cost","—"),
                    imp.get("value_added","—"), imp.get("roi_quality","—"),
                    imp.get("risk","—")
                ])
            else:
                imp_rows.append([str(imp), "—", "—", "—", "—"])
        story.append(tbl(imp_rows, col_widths=[2.0*inch, 1.2*inch, 1.2*inch, 1.2*inch, 1.9*inch]))
        story.append(Paragraph(
            "Rule: Improvements are ranked by equity efficiency, not emotional appeal. "
            "Over-improvement risk is flagged where applicable.",
            styles["small"]
        ))
    else:
        story.append(pending_block("Improvement ROI Model", styles))

    # ── SECTION 11: OWNER STRATEGY MATRIX ────────────────────────────────────
    story.append(Paragraph("11. OWNER STRATEGY MATRIX", styles["section"]))
    story.append(hr())

    options = strategy.get("owner_options") or extras.get("owner_options", [])
    if options:
        opt_rows = [["Strategy", "Pros", "Cons", "Best For", "Recommendation"]]
        for o in options:
            if isinstance(o, dict):
                opt_rows.append([
                    o.get("strategy","—"), o.get("pros","—"),
                    o.get("cons","—"), o.get("best_for","—"),
                    o.get("recommendation","—")
                ])
        story.append(tbl(opt_rows, col_widths=[0.9*inch, 1.5*inch, 1.5*inch, 1.4*inch, 1.2*inch]))
    else:
        story.append(pending_block("Owner Strategy Matrix", styles))

    # ── SECTION 12: RENT / INCOME POTENTIAL ──────────────────────────────────
    story.append(Paragraph("12. RENT / INCOME POTENTIAL", styles["section"]))
    story.append(hr())

    rent = neighbor.get("rent_estimate") or extras.get("rent_estimate")
    if rent or extras.get("rental_income"):
        ri = extras.get("rental_income", {})
        rent_rows = [["Metric", "Value"]]
        if rent:       rent_rows.append(["Rent Estimate",       str(rent)])
        if ri.get("gross_annual"):  rent_rows.append(["Gross Annual Income", ri["gross_annual"]])
        if ri.get("monthly_payment"): rent_rows.append(["Est. Monthly Payment", ri["monthly_payment"]])
        if ri.get("cash_flow"):    rent_rows.append(["Est. Monthly Cash Flow", ri["cash_flow"]])
        if ri.get("vacancy_note"): rent_rows.append(["Vacancy Note", ri["vacancy_note"]])
        story.append(tbl(rent_rows, col_widths=[2.5*inch, 4.0*inch]))
        story.append(Paragraph(
            "Rule: A house that cash-flows $200/month is not a 'cash cow.' "
            "It is a long-term appreciation hold. Do not oversell rental income.",
            styles["small"]
        ))
    else:
        story.append(pending_block("Rent / Income Potential", styles))

    # ── SECTION 13: BUYER / INVESTOR PROFILE ─────────────────────────────────
    story.append(Paragraph("13. BUYER / INVESTOR PROFILE", styles["section"]))
    story.append(hr())

    buyer_profile = neighbor.get("buyer_profile") or strategy.get("buyer_profile")
    buyer_profiles_list = extras.get("buyer_profiles", [])
    if buyer_profile or buyer_profiles_list:
        if buyer_profile:
            story.append(Paragraph(str(buyer_profile), styles["body"]))
        for bp in buyer_profiles_list:
            story.append(Paragraph(f"• {bp}", styles["body"]))
    else:
        story.append(pending_block("Buyer / Investor Profile", styles))

    # ── SECTION 14: RISK REGISTER ─────────────────────────────────────────────
    story.append(PageBreak())
    story.append(Paragraph("14. RISK REGISTER", styles["section"]))
    story.append(hr())

    risks = strategy.get("risk_flags") or extras.get("risks", [])
    if risks:
        risk_rows = [["Risk", "Severity", "Likelihood", "Mitigation"]]
        for r in risks:
            if isinstance(r, dict):
                risk_rows.append([
                    r.get("risk","—"), r.get("severity","—"),
                    r.get("likelihood","—"), r.get("mitigation","—")
                ])
            else:
                risk_rows.append([str(r), "—", "—", "—"])
        story.append(tbl(risk_rows, col_widths=[2.0*inch, 1.0*inch, 1.0*inch, 2.5*inch]))
    else:
        story.append(pending_block("Risk Register", styles))

    # ── SECTION 15: RECOMMENDED ACTION PLAN ──────────────────────────────────
    story.append(Paragraph("15. RECOMMENDED ACTION PLAN", styles["section"]))
    story.append(hr())

    action_plan = strategy.get("action_plan") or extras.get("action_plan", {})
    if action_plan:
        for phase, items in [
            ("0–30 Days",   action_plan.get("phase_30", [])),
            ("30–90 Days",  action_plan.get("phase_90", [])),
            ("90–180 Days", action_plan.get("phase_180", [])),
            ("12–24 Months",action_plan.get("phase_24m", [])),
        ]:
            if items:
                story.append(Paragraph(phase + ":", styles["subsec"]))
                for i, item in enumerate(items, 1):
                    story.append(Paragraph(f"{i}. {item}", styles["body"]))
    else:
        story.append(pending_block("Recommended Action Plan", styles))

    # ── SECTION 16: SOURCE LEDGER ─────────────────────────────────────────────
    story.append(Paragraph("16. SOURCE LEDGER", styles["section"]))
    story.append(hr())

    if sources_used:
        src_rows = [["Source", "Type", "Used For", "Date Checked", "Confidence"]]
        for s in sources_used:
            src_rows.append([
                s.get("source","—"), s.get("type","—"),
                s.get("used_for","—"), s.get("date_checked","—"),
                s.get("confidence","—")
            ])
        story.append(tbl(src_rows, col_widths=[1.5*inch, 1.0*inch, 1.8*inch, 1.1*inch, 1.1*inch]))
    else:
        story.append(Paragraph(
            "Source ledger will be auto-populated from bot consultation metadata "
            "on the next full consultation cycle.",
            styles["pending"]
        ))

    # ── FINAL DECISION BLOCK ──────────────────────────────────────────────────
    story.append(Paragraph("FINAL DECISION BLOCK", styles["section"]))
    story.append(hr(GREEN))

    final = report.get("final_decision", {}) or strategy
    if final:
        if final.get("best_move"):
            story.append(Paragraph(f"Best Move: {final['best_move']}", styles["callout"]))
        if final.get("why"):
            story.append(Paragraph(f"Why: {final['why']}", styles["body"]))
        if final.get("verify_before_acting"):
            story.append(Paragraph("Verify Before Acting:", styles["body_bold"]))
            items = final["verify_before_acting"]
            if isinstance(items, list):
                for i, item in enumerate(items, 1):
                    story.append(Paragraph(f"{i}. {item}", styles["body"]))
            else:
                story.append(Paragraph(str(items), styles["body"]))

        ap = final.get("action_plan", {})
        if ap:
            for phase, label in [("30d","30 Days"), ("90d","90 Days"), ("180d","180 Days")]:
                if ap.get(phase):
                    story.append(Paragraph(f"{label}: {ap[phase]}", styles["body"]))

        if final.get("confidence"):
            story.append(Paragraph(
                f"Overall Report Confidence: {final['confidence']}",
                styles["body_bold"]
            ))
    else:
        story.append(pending_block("Final Decision Block", styles))

    # ── FOOTER / DISCLAIMER ───────────────────────────────────────────────────
    story.append(Spacer(1, 24))
    story.append(HRFlowable(width="100%", thickness=0.5, color=RULE_GRAY))
    story.append(Spacer(1, 6))
    story.append(Paragraph(
        "DISCLAIMER: This report is generated from publicly available data sources. "
        "It is provided for informational purposes only and does not constitute a formal "
        "appraisal, Phase I Environmental Site Assessment, title search, or legal advice. "
        "Data accuracy depends on source quality and timeliness. The recipient should "
        "independently verify all critical information before making financial decisions. "
        "Environmental proximity data reflects straight-line distance only.",
        styles["small"]
    ))
    story.append(Spacer(1, 8))
    story.append(Paragraph(
        "Generated by Mr. Results (Overseer) — Powered by Nvirogear LLC",
        styles["footer"]
    ))
    story.append(Paragraph(
        "N-ViroGear Land Intelligence System — Confidential",
        styles["footer"]
    ))

    # ── BUILD ─────────────────────────────────────────────────────────────────
    doc = SimpleDocTemplate(
        output_path,
        pagesize=letter,
        topMargin=0.6*inch, bottomMargin=0.7*inch,
        leftMargin=0.75*inch, rightMargin=0.75*inch,
    )
    doc.build(story)
    print(output_path)
    return output_path


# ── CLI entry point ───────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Enterprise Report PDF Generator")
    parser.add_argument("--parcel_id",   required=True)
    parser.add_argument("--report_json", required=True, help="Path to compiled report JSON")
    parser.add_argument("--output",      required=True, help="Output PDF path")
    args = parser.parse_args()

    report_path = Path(args.report_json)
    if not report_path.exists():
        print(f"ERROR: report_json not found: {report_path}", file=sys.stderr)
        sys.exit(1)

    with open(report_path) as f:
        report_data = json.load(f)

    # Ensure parcel_id is in meta
    if "meta" not in report_data:
        report_data["meta"] = {}
    if not report_data["meta"].get("parcel_id"):
        report_data["meta"]["parcel_id"] = args.parcel_id

    build_pdf(report_data, args.output)
