# Skill: enterprise_report_pdf

## Purpose
Generates a full 17-section Results.com-style Property Intelligence Report PDF.
Called by Mr. Results whenever enhanced mode is triggered.

## Usage
```
python scripts/run.py \
  --parcel_id "61-27-547-000-0026-01" \
  --report_json "/path/to/compiled_report.json" \
  --output "/path/to/output.pdf"
```

## Input: compiled_report.json schema
All sections are optional — missing sections render as "Pending Bot Input"

## Output
PDF file at the specified output path.
Also prints the output path to stdout on success.

## Dependencies
reportlab, pillow (pre-installed in sandbox)
