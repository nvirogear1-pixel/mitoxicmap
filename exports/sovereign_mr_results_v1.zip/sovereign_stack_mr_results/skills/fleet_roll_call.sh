#!/bin/bash
# ============================================================
# NVIROGEAR FLEET ROLL CALL — Mr. Results Pre-Flight Check
# Version: 3.0 | Date: 2026-05-18
# MANDATORY before: every report, every project, every dispatch
# ============================================================
# Usage: bash fleet_roll_call.sh [trigger] [context] [address]
#   trigger: session_start | pre_report | pre_project | pre_dispatch | manual
#   context: e.g. "Muskegon Enterprise Report"
#   address: optional — if provided, fires LIVE HANDSHAKE to all bots
# ============================================================

TRIGGER="${1:-manual}"
CONTEXT="${2:-manual check}"
ADDRESS="${3:-}"
TIMESTAMP=$(date -u '+%Y-%m-%dT%H:%M:%SZ')
DISPLAY_TIME=$(date '+%Y-%m-%d %H:%M ET')
BATCH_ID="ROLLCALL-$(date +%s)"

PIPELINE_URL="https://mr-results-8ae25c59.base44.app/functions/pipelineIngest"
ACK_URL="https://mr-results-8ae25c59.base44.app/functions/botAckReceiver"
JET_URL="https://badass-real-estate-grabber-0c18c5f1.base44.app/functions/receiveTaskFromMrResults"
HISTORIAN_URL="https://super-history-bot-2d658b84.base44.app/functions/receiveTask"
OUTREACH_URL="https://outreach-bot-1129e0e7.base44.app/functions/receiveDispatch"
SUPER_REPORT_URL="https://super-report-bot-2225eadc.base44.app/functions/orchestrateOutreach"
SITE_TRACKER_URL="https://badass-site-tracker-5786d5f6.base44.app/functions/receiveTask"
AUCTION_GATE_URL="https://api.base44.com/api/apps/6a09e83291d88c098df788fb/functions/auctionGateEntity"

LIVE=0; WARN=0; DEAD=0; BLOCKED_BOTS=""

# ── ping_bot: fires task, reads response, classifies result ──────────────────
ping_bot() {
  local KEY="$1" LABEL="$2" URL="$3" PAYLOAD="$4" EXPECT="$5" WARN_MSG="$6"
  local T0=$(date +%s%3N)
  local HTTP_CODE
  HTTP_CODE=$(curl -s -o /tmp/rc_${KEY}.txt -w "%{http_code}" \
    -X POST "$URL" -H "Content-Type: application/json" -d "$PAYLOAD" --max-time 12)
  local MS=$(( $(date +%s%3N) - T0 ))
  local BODY; BODY=$(cat /tmp/rc_${KEY}.txt 2>/dev/null | head -c 500)

  local STATUS NOTE ICON
  if echo "$BODY" | grep -qi "private"; then
    STATUS="warn"; ICON="🔒"; NOTE="App is PRIVATE — owner must set to Public"; WARN=$((WARN+1))
  elif echo "$BODY" | grep -qi "not found\|App not found" && [ "$HTTP_CODE" = "404" ]; then
    STATUS="dead"; ICON="❌"; NOTE="Function not deployed / endpoint missing"; DEAD=$((DEAD+1)); BLOCKED_BOTS="${BLOCKED_BOTS}${KEY},"
  elif echo "$BODY" | grep -qi "$EXPECT" && { [ "$HTTP_CODE" = "200" ]||[ "$HTTP_CODE" = "201" ]||[ "$HTTP_CODE" = "400" ]||[ "$HTTP_CODE" = "422" ]; }; then
    STATUS="live"; ICON="✅"; NOTE="${MS}ms"; LIVE=$((LIVE+1))
  elif [ "$HTTP_CODE" = "200" ]||[ "$HTTP_CODE" = "201" ]; then
    STATUS="live"; ICON="✅"; NOTE="${MS}ms"; LIVE=$((LIVE+1))
  elif [ "$HTTP_CODE" = "000" ]; then
    STATUS="dead"; ICON="❌"; NOTE="Timeout — no response"; DEAD=$((DEAD+1)); BLOCKED_BOTS="${BLOCKED_BOTS}${KEY},"
  else
    STATUS="dead"; ICON="❌"; NOTE="HTTP $HTTP_CODE — unreachable"; DEAD=$((DEAD+1)); BLOCKED_BOTS="${BLOCKED_BOTS}${KEY},"
  fi

  printf "  %s  %-22s  HTTP %-3s  %s\n" "$ICON" "$LABEL" "$HTTP_CODE" "$NOTE"
  [ "$STATUS" != "live" ] && printf "      └─ %s\n" "$NOTE"

  eval "${KEY}_STATUS=$STATUS"
  eval "${KEY}_HTTP=$HTTP_CODE"
  eval "${KEY}_MS=$MS"
  eval "${KEY}_BODY=$(echo "$BODY" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('message',d.get('status','')))" 2>/dev/null || echo "$BODY" | head -c 60)"
}

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║   🛰️  NVIROGEAR FLEET ROLL CALL                          ║"
echo "║   Mr. Results — Pre-Flight Verification                  ║"
echo "╠══════════════════════════════════════════════════════════╣"
printf "║   Trigger : %-44s ║\n" "$TRIGGER"
printf "║   Context : %-44s ║\n" "${CONTEXT:0:44}"
printf "║   Time    : %-44s ║\n" "$DISPLAY_TIME"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
echo "  CALLING ROLL..."
echo ""

# ── Phase 1: Endpoint ping (is the bot alive?) ───────────────────────────────
ping_bot "jet" "Jet / GIS Bot" "$JET_URL" \
  "{\"task_id\":\"${BATCH_ID}-PING-JET\",\"task_type\":\"status_report\",\"from\":\"mr_results\",\"caller_id\":\"69ca9ac1baa8ecdb8ae25c59\"}" \
  "queued" "Responded but no confirmation"

ping_bot "historian" "Historian Bot" "$HISTORIAN_URL" \
  "{\"task_id\":\"${BATCH_ID}-PING-HIST\",\"task_type\":\"env_check\",\"from\":\"mr_results\",\"caller_id\":\"69ca9ac1baa8ecdb8ae25c59\",\"county\":\"ROLLCALL\",\"state_code\":\"MI\"}" \
  "accepted" "Responded but not accepted"

ping_bot "outreach" "Outreach Bot" "$OUTREACH_URL" \
  "{\"task_id\":\"${BATCH_ID}-PING-OUT\",\"dispatch_type\":\"get_log_status\",\"caller_id\":\"69ca9ac1baa8ecdb8ae25c59\",\"from\":\"mr_results\"}" \
  "" "Outreach responded"

ping_bot "super_report" "Super Report Bot" "$SUPER_REPORT_URL" \
  "{\"ping\":true,\"from\":\"mr_results\"}" \
  "private" "Responded"

ping_bot "site_tracker" "Site Tracker" "$SITE_TRACKER_URL" \
  "{\"task_id\":\"${BATCH_ID}-PING-ST\",\"task_type\":\"status_report\",\"from\":\"mr_results\",\"caller_id\":\"69ca9ac1baa8ecdb8ae25c59\"}" \
  "accepted" "Responded"

ping_bot "auction_gate" "Auction Gate Bot" "$AUCTION_GATE_URL" \
  "{\"task_id\":\"${BATCH_ID}-PING-AG\",\"from\":\"mr_results\",\"caller_id\":\"69ca9ac1baa8ecdb8ae25c59\"}" \
  "" "Responded"

echo ""

# ── Phase 2: Live Handshake (if address provided and core bots are live) ──────
if [ -n "$ADDRESS" ] && [ "$jet_STATUS" = "live" ] && [ "$historian_STATUS" = "live" ]; then
  DISPATCH_BATCH="DISPATCH-$(date +%s)"
  echo "╠══════════════════════════════════════════════════════════╣"
  echo "║   📡  LIVE HANDSHAKE — DISPATCHING TO FLEET              ║"
  printf "║   Target: %-46s ║\n" "$ADDRESS"
  echo "╚══════════════════════════════════════════════════════════╝"
  echo ""
  echo "  Blasting tasks in parallel..."
  echo ""

  DT0=$(date +%s%3N)

  # Fire Jet + Historian + Outreach simultaneously
  curl -s -o /tmp/dh_jet.txt -X POST "$JET_URL" -H "Content-Type: application/json" \
    -d "{\"task_id\":\"${DISPATCH_BATCH}-JET\",\"task_type\":\"custom\",\"from\":\"mr_results\",\"caller_id\":\"69ca9ac1baa8ecdb8ae25c59\",\"county\":\"Kent\",\"state_code\":\"MI\",\"parameters\":{\"custom_action\":\"fetch_parcel_by_address\",\"address\":\"$ADDRESS\",\"ack_url\":\"$ACK_URL\",\"callback_url\":\"$PIPELINE_URL\",\"require_ack\":true}}" \
    --max-time 10 &

  curl -s -o /tmp/dh_hist.txt -X POST "$HISTORIAN_URL" -H "Content-Type: application/json" \
    -d "{\"task_id\":\"${DISPATCH_BATCH}-HISTORIAN\",\"task_type\":\"env_check\",\"from\":\"mr_results\",\"caller_id\":\"69ca9ac1baa8ecdb8ae25c59\",\"county\":\"Kent\",\"state_code\":\"MI\",\"address\":\"$ADDRESS\",\"parameters\":{\"ack_url\":\"$ACK_URL\",\"callback_url\":\"$PIPELINE_URL\",\"require_ack\":true}}" \
    --max-time 10 &

  curl -s -o /tmp/dh_out.txt -X POST "$OUTREACH_URL" -H "Content-Type: application/json" \
    -d "{\"task_id\":\"${DISPATCH_BATCH}-OUTREACH\",\"dispatch_type\":\"get_log_status\",\"caller_id\":\"69ca9ac1baa8ecdb8ae25c59\",\"from\":\"mr_results\",\"address\":\"$ADDRESS\"}" \
    --max-time 10 &

  wait
  DT1=$(date +%s%3N)
  DISPATCH_MS=$(( DT1 - DT0 ))

  # Parse results
  JET_D=$(cat /tmp/dh_jet.txt 2>/dev/null)
  HIST_D=$(cat /tmp/dh_hist.txt 2>/dev/null)
  OUT_D=$(cat /tmp/dh_out.txt 2>/dev/null)

  JET_ACK_ID=$(echo "$JET_D" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('task_id','N/A'))" 2>/dev/null)
  HIST_ACK_ID=$(echo "$HIST_D" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('inbox_id','N/A'))" 2>/dev/null)
  OUT_STATUS=$(echo "$OUT_D" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('status','N/A'))" 2>/dev/null)

  JET_ACK_OK=$(echo "$JET_D" | grep -q '"queued"\|"accepted"\|"ack_confirmed"' && echo "✅ ACK" || echo "⚠️  CHECK")
  HIST_ACK_OK=$(echo "$HIST_D" | grep -q '"accepted"\|"queued"\|"ack_confirmed"' && echo "✅ ACK" || echo "⚠️  CHECK")
  OUT_ACK_OK=$(echo "$OUT_D" | grep -q '"not_found"\|"dispatched"\|"queued"' && echo "✅ ACK" || echo "⚠️  CHECK")

  echo "  Boss, $ADDRESS order is live. Fleet receipts:"
  echo ""
  printf "  %s  %-14s  ID: %-36s\n" "$JET_ACK_OK"  "jet_bot"   "${JET_ACK_ID:0:36}"
  printf "  %s  %-14s  ID: %-36s\n" "$HIST_ACK_OK" "historian" "${HIST_ACK_ID:0:36}"
  printf "  %s  %-14s  Status: %-30s\n" "$OUT_ACK_OK"  "outreach"  "${OUT_STATUS:0:30}"
  echo ""
  printf "  Round-trip: %sms (parallel fire)\n" "$DISPATCH_MS"
  echo "  The machine is moving. I'll synthesize the complete report once pipeline files ingest."
  echo ""
fi

# ── Summary ───────────────────────────────────────────────────────────────────
echo "╔══════════════════════════════════════════════════════════╗"
if [ $DEAD -eq 0 ] && [ $WARN -le 2 ]; then
  echo "║  🟢 ALL SYSTEMS GO — Core fleet ready                    ║"
elif [ $LIVE -ge 3 ]; then
  echo "║  🟡 PARTIAL READINESS — Core fleet operational           ║"
else
  echo "║  🔴 FLEET DEGRADED — Do not dispatch                     ║"
fi
printf "║  ✅ %-2s LIVE  |  ⚠️  %-2s WARN  |  ❌ %-2s DEAD            ║\n" "$LIVE" "$WARN" "$DEAD"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

[ $DEAD -gt 0 ] && echo "  🚨 BLOCKED: ${BLOCKED_BOTS%,} — DO NOT DISPATCH to these bots" && echo "  Fix guide: .agents/rules/bot_handshake_protocol.md" && echo ""
[ $WARN -gt 0 ] && echo "  ⚠️  $WARN item(s) need owner action — see details above" && echo ""

# ── Log to RollCallLog entity ─────────────────────────────────────────────────
FLEET_READY="true"
[ $DEAD -gt 0 ] && FLEET_READY="false"
BLOCKED_CLEAN="${BLOCKED_BOTS%,}"

curl -s -X POST "$PIPELINE_URL" -H "Content-Type: application/json" -d "{
  \"action\":\"log_roll_call\",\"entity\":\"RollCallLog\",
  \"data\":{
    \"session_trigger\":\"$TRIGGER\",\"triggered_by\":\"$CONTEXT\",
    \"jet_status\":\"${jet_STATUS}\",\"jet_http\":${jet_HTTP:-0},\"jet_response_ms\":${jet_MS:-0},
    \"historian_status\":\"${historian_STATUS}\",\"historian_http\":${historian_HTTP:-0},\"historian_response_ms\":${historian_MS:-0},
    \"outreach_status\":\"${outreach_STATUS}\",\"outreach_http\":${outreach_HTTP:-0},\"outreach_response_ms\":${outreach_MS:-0},
    \"super_report_status\":\"${super_report_STATUS}\",\"super_report_http\":${super_report_HTTP:-0},\"super_report_response_ms\":${super_report_MS:-0},
    \"site_tracker_status\":\"${site_tracker_STATUS}\",\"site_tracker_http\":${site_tracker_HTTP:-0},\"site_tracker_response_ms\":${site_tracker_MS:-0},
    \"auction_gate_status\":\"${auction_gate_STATUS}\",\"auction_gate_http\":${auction_gate_HTTP:-0},\"auction_gate_response_ms\":${auction_gate_MS:-0},
    \"total_live\":$LIVE,\"total_warn\":$WARN,\"total_dead\":$DEAD,
    \"fleet_ready\":$FLEET_READY,\"blocked_bots\":\"$BLOCKED_CLEAN\",
    \"ran_at\":\"$TIMESTAMP\"
  }
}" > /dev/null 2>&1

echo "  📋 Roll call result logged to RollCallLog."
echo ""
