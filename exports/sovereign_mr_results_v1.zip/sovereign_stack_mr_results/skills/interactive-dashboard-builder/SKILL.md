---
name: interactive-dashboard-builder
description: Build self-contained interactive HTML dashboards with Chart.js, dropdown filters, and professional styling. Use when creating dashboards, building interactive reports, or generating shareable HTML files with charts and filters that work without a server.
---

Build interactive HTML dashboards with filters and styling for data presentation.