# Alice Deliberation Podcast — Sovereign Module

## What this is
Reusable sovereign module implementing the T6 Buyer–Advisor Deliberation product of the
ALICE Report Product Family (`.agents/rules/alice_product_family_v1.md`).

**SOVEREIGN SHELL — ZERO PLATFORM DEPENDENCIES.** Pure Python stdlib. No Base44 SDK,
no entities, no connectors, no network calls. JSON in → products out. Runs from a laptop,
a NAS, a CI job, or any sandbox. Nothing in this module locks to any host platform.

## Architecture position
```
Alice evidence package (frozen, hash-chained)
        → [this module] → deliberation.json / script.txt / action_items.md
        → (later: TTS voice render → podcast audio)
```

## Usage
```bash
python3 scripts/run.py --package evidence_package_5695_missys_dr.json --out ./out_5695
```

## Input contract — frozen evidence package (schema)
```json
{
  "package_id": "string",
  "frozen_at": "ISO-8601",
  "ledger_prev_hash": "string (VaultSmith chain link)",
  "parcel":     { "pin": "...", "address": "...", "municipality": "...", "state": "...",
                   "acreage": 0.0, "zoning": "...", "school_district": "..." },
  "metrics":    { "named numeric facts": 0 },
  "claims":     [ { "id": "C1", "text": "...", "label": "VERIFIED|PUBLIC REFERENCE|MODELED|NEEDS VERIFICATION",
                    "source": "...", "accessed": "date" } ],
  "flags":      { "manufactured_home": true, "private_road": true, "env_sites_nearby": true,
                   "well_private_or_unknown": true, "homestead": true },
  "open_questions": [ "..." ]
}
```

## Output contract
| File | Content |
|------|---------|
| `deliberation.json` | Structured turns: speaker, text, cited claim IDs, action items |
| `deliberation_script.txt` | Readable two-voice script (TTS/voiceover-ready) |
| `action_items.md` | Every gap the deliberation exposed — never hallucinated answers |

## Governing rules enforced by this module
1. Advisor voices may cite ONLY claims present in the frozen package (by ID).
2. Every unknown becomes an ACTION ITEM — no invented facts, ever.
3. Buyer role is deliberately skeptical; advisor says "unknown" out loud.
4. Output carries package_id + sha256 of the exact package it was generated from.

*Module: alice_deliberation_podcast v1.0 · Nvirogear LLC · frozen-evidence doctrine per alice_product_family_v1.md*
