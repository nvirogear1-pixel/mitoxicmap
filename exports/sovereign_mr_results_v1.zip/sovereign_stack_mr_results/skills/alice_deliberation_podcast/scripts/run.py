#!/usr/bin/env python3
"""
Alice Deliberation Podcast generator — SOVEREIGN MODULE
Zero platform dependencies. Python stdlib only. JSON in -> products out.
Doctrine: alice_product_family_v1.md (freeze rule, unknown->action item, cite-only-frozen-claims)
v1.1: natural-conversation engine — shorter turns, buyer reactions and interruptions,
      plain-language translation beats. Same frozen-evidence discipline.
"""
import argparse, hashlib, json, os, sys

LABEL_BADGE = {
    "VERIFIED": "[VERIFIED]",
    "PUBLIC REFERENCE": "[PUBLIC REFERENCE]",
    "MODELED": "[MODELED]",
    "NEEDS VERIFICATION": "[NEEDS VERIFICATION]",
}

def sha256_file(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()

def claim_lookup(pkg):
    return {c["id"]: c for c in pkg["claims"]}

def cite(claims, ids):
    parts = []
    for cid in ids:
        c = claims.get(cid)
        if c is None:
            raise ValueError(f"VIOLATION: cited claim {cid} not in frozen package")
        parts.append(f"{LABEL_BADGE.get(c['label'], '[UNLABELED]')} {c['source']}")
    return " [" + "; ".join(dict.fromkeys(parts)) + "]"

def money(n):
    return "${:,.0f}".format(n)

def build_deliberation(pkg):
    """Natural two-voice deliberation from frozen evidence. Buyer pushes back; advisor stays evidence-bound."""
    cl = claim_lookup(pkg)
    p = pkg["parcel"]
    m = pkg.get("metrics", {})
    f = pkg.get("flags", {})
    turns = []
    actions = []

    def buyer(text):
        turns.append({"n": len(turns) + 1, "speaker": "buyer", "text": text, "cites": [], "action_items": []})

    def advisor(text, cites, acts=None):
        for x in (acts or []):
            actions.append(x)
        turns.append({"n": len(turns) + 1, "speaker": "advisor", "text": text + cite(cl, cites),
                      "cites": cites, "action_items": [x["id"] for x in (acts or [])]})

    # --- Opening
    buyer("Thanks for making time. I'm looking at a place on Missy Drive, out in Egelston Township — "
          "and before I fall in love with it, I want the unfiltered version. What am I actually standing on?")
    advisor("Then let's start where it matters. One point six two acres, R1 residential, Oakridge schools, "
            "Sec 28. County-verified boundaries — I've run the polygon myself, it's not a listing description. "
            "It's the county's own record.", ["C1", "C2"])

    # --- Price & value
    buyer("Okay. And the price, honestly… looks suspiciously reasonable for the size. That's usually where I get burned.")
    advisor("Here's the funny part — the math checks out. Last sale was a hundred and thirteen thousand, "
            "January 2019. The county's equalized value implies around two hundred and six thousand today, "
            "and third-party estimates run from two sixteen up to two fifty-five. Two completely independent "
            "methods, same neighborhood of numbers.", ["C10", "C11", "C12"])
    buyer("So it's not a distress price. It's just… a normal price.")
    advisor("A normal price in a market that isn't inflated. When two paths agree, I stop hunting for the "
            "hidden catch in the price — and start hunting for it in the land.", ["C11"])

    # --- Structure
    if f.get("manufactured_home"):
        buyer("Alright, so let's hunt. It's a manufactured home from the nineties — does that spook you?")
        advisor("It spooks lenders more than it spooks me. The real question is titling. If it's titled as real "
                "property, banks treat it like any house. If it's still titled as a mobile home, that's a "
                "different conversation.", ["C5"],
                [{"id": "A1", "text": "Confirm with the township whether the 1996 manufactured home is titled as real property."}])

    # --- Environmental radius
    buyer("Here's my real question. Anything contaminated near this place? Because the price will never tell me that.")
    advisor("On the land itself? Nothing. No contamination site, no buried tanks, no mapped wetland, no flood zone. Clean.", ["C20"])
    buyer("…and within driving distance?")
    advisor("Within two miles there are nine EGLE Part 201 sites. The nearest one's under a mile — a salvage "
            "parcel, and the risks there are already controlled. The ones still requiring action sit farther "
            "out, along the Apple Avenue commercial corridor — not this road.", ["C21", "C23"])
    buyer("Okay — 'corridor risk.' Say it in English. What does that mean for me?")
    advisor("It means nobody's storing drums next door. The thing that could actually reach you is water — "
            "groundwater doesn't care about fences. And this house depends on a well.", ["C23", "C30"])

    # --- Water / well
    buyer("Which brings me to the well. What do we actually know about it?")
    advisor("Honestly? Less than I'd like. Area wells run a shallow water table, six to ten feet. Even the 1882 "
            "county history describes Wolf Lake as spring-fed with no inlet and no outlet — same picture, a "
            "hundred and forty years apart. But this parcel's own well record? Not in my evidence. I won't "
            "pretend it is.", ["C30", "C31"],
            [{"id": "A2", "text": "Order a certified water panel — PFAS, nitrate, lead — before closing."},
             {"id": "A3", "text": "Pull the Wellogic well record for this parcel: depth, casing, static level, yield."}])
    buyer("I appreciate you not pretending. Okay — taxes. Taxes always hide something.")
    advisor("Not this time. Taxable value sixty-four six eighty-two against an assessed one-oh-three-two. That "
            "gap is Proposal A doing exactly what it's supposed to do since the 2019 purchase — and it's "
            "homesteaded, one hundred percent exemption. The uncapping math comes out clean. No funny business.",
            ["C15", "C16", "C17"])

    # --- Access / private road
    if f.get("private_road"):
        buyer("Getting to it. I've been burned by landlocked land before — what's the access story?")
        advisor("Four parcels, one private road, and all four carry recorded easements. You're not landlocked — "
                "but you're also not alone. There's a shared road maintenance agreement on the books.", ["C40", "C41"],
                [{"id": "A4", "text": "Pull the recorded road maintenance agreement (Liber 3167, Pg 965) for exact cost-sharing terms."}])
        buyer("Meaning I split the plowing. Forever.")
        advisor("Meaning you split the plowing forever — and you read that agreement before you sign anything, "
                "because 'shared' can mean a lot of things in a recorded document.", ["C41"])

    # --- Pre-close orders
    buyer("So walk me through it. What would you make me do before I sign anything?")
    advisor("In order: the water panel — PFAS, nitrate, lead. The well record. The road agreement, read with "
            "your own eyes. The titling question with the township. And anything the seller has on septic "
            "or prior testing — in writing.", ["C20", "C30"],
            [{"id": "A5", "text": "Ask the seller for the septic inspection and any prior environmental testing."}])

    # --- Missing records
    buyer("And what do you still not know?")
    oq = pkg.get("open_questions", [])
    acts = [{"id": f"A{6 + i}", "text": q} for i, q in enumerate(oq)]
    advisor("From the frozen package: " + ("; ".join(oq) if oq else "nothing major") +
            ". Those go in your inspection window — not in my imagination.", [], acts)

    # --- Verdicts
    buyer("…I like that. Bottom line — would you buy it?")
    buyer("If the water comes back clean and that road agreement doesn't hide a bomb, this is a quiet homestead "
          "at a fair number. I came in looking for the catch — and so far the catch is just homework.")
    advisor("That's the honest read. Clean parcel, capped taxes, no distress, one shared-road obligation, and "
            "a contamination story that lives a corridor away — not next door. Buy it with conditions, not "
            "with hope. Truth is more valuable than optimism — and that's not a slogan, that's the method.",
            ["C1", "C15", "C20", "C40"])

    return {"package_id": pkg["package_id"], "package_sha256": None,
            "frozen_at": pkg["frozen_at"], "format": "buyer-advisor-deliberation-v1.1",
            "turns": turns, "action_items": actions}

def render_script(d):
    lines = [f"BUYER–ADVISOR DELIBERATION — {d['package_id']}",
             f"Generated from frozen evidence package {d['package_sha256'][:16]}… @ {d['frozen_at']}",
             "=" * 72, ""]
    for t in d["turns"]:
        who = "BUYER" if t["speaker"] == "buyer" else "ADVISOR"
        lines.append(f"[{t['n']:02d}] {who}: {t['text']}\n")
    if d["action_items"]:
        lines.append("ACTION ITEMS (never hallucinated — only what evidence could not answer):")
        for a in d["action_items"]:
            lines.append(f"  - {a['id']}: {a['text']}")
    return "\n".join(lines)

def render_actions(d):
    out = [f"# Action Items — {d['package_id']}", "",
           "Every item below is a gap the deliberation exposed. Unknowns become action items, never invented answers.", ""]
    for a in d["action_items"]:
        out.append(f"- [ ] **{a['id']}** — {a['text']}")
    return "\n".join(out)

def main():
    ap = argparse.ArgumentParser(description="Alice Deliberation Podcast generator (sovereign, zero deps)")
    ap.add_argument("--package", required=True, help="frozen evidence package JSON")
    ap.add_argument("--out", required=True, help="output directory")
    args = ap.parse_args()

    pkg_path = os.path.abspath(args.package)
    with open(pkg_path, "r", encoding="utf-8") as fh:
        pkg = json.load(fh)

    delib = build_deliberation(pkg)
    delib["package_sha256"] = sha256_file(pkg_path)

    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "deliberation.json"), "w", encoding="utf-8") as fh:
        json.dump(delib, fh, indent=2, ensure_ascii=False)
    with open(os.path.join(args.out, "deliberation_script.txt"), "w", encoding="utf-8") as fh:
        fh.write(render_script(delib))
    with open(os.path.join(args.out, "action_items.md"), "w", encoding="utf-8") as fh:
        fh.write(render_actions(delib))

    print(f"SOVEREIGN MODULE RUN — OK")
    print(f"package: {pkg['package_id']}  sha256={delib['package_sha256']}")
    print(f"turns: {len(delib['turns'])}  action items: {len(delib['action_items'])}")
    print(f"outputs -> {args.out}/deliberation.json, deliberation_script.txt, action_items.md")

if __name__ == "__main__":
    sys.exit(main())
