#!/usr/bin/env python3
"""
Alice Deliberation Podcast — AUDIO RENDER STEP (optional host-side adapter)
Requires: edge-tts (network), ffmpeg. The core generator (run.py) stays pure stdlib;
this renderer is the optional TTS adapter that turns the frozen deliberation into audio.

Doctrine: speaks ONLY from the frozen deliberation. Citation tails are stripped for
speech (they remain in the transcript/written report). No invented lines, ever.

Usage:
  python3 render_audio.py --deliberation out_5695/deliberation.json --outdir out_5695/podcast
"""
import argparse, asyncio, json, os, subprocess, sys

try:
    import edge_tts
except ImportError:
    sys.exit("edge-tts not installed: pip install edge-tts")

GAP_S = 0.35          # silence between speakers
BUYER_VOICE = "en-US-ChristopherNeural"
ADVISOR_VOICE = "en-US-JennyNeural"
BUYER_RATE, ADVISOR_RATE = "+8%", "-4%"

def spoken_text(t):
    """Strip the trailing citation tail ([VERIFIED] source...) for speech — citations live in the transcript."""
    txt = t["text"].strip()
    if t["speaker"] == "advisor":
        i = txt.rfind(" [")
        if i > 0:
            txt = txt[:i].strip()
    return txt

async def synth(text, voice, rate, out):
    c = edge_tts.Communicate(text, voice, rate=rate)
    await c.save(out)

def dur_of(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                        "-of", "csv=p=0", path], capture_output=True, text=True)
    return float(r.stdout.strip())

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--deliberation", required=True)
    ap.add_argument("--outdir", required=True)
    a = ap.parse_args()

    with open(a.deliberation, "r", encoding="utf-8") as f:
        d = json.load(f)

    os.makedirs(a.outdir, exist_ok=True)
    tmp = os.path.join(a.outdir, "chunks")
    os.makedirs(tmp, exist_ok=True)

    # --- build segment list: intro, turns, checklist, outro
    segs = []
    segs.append({"id": "intro", "speaker": "advisor",
        "text": ("Nvirogear Property Intelligence. This is a buyer and advisor deliberation for "
                 "5695 Missys Drive, Egelston Township, Michigan. Two voices, one frozen evidence package, "
                 "and no invented answers. Recorded September, 2026.")})
    for t in d["turns"]:
        segs.append({"id": f"turn{t['n']:02d}", "speaker": t["speaker"], "text": spoken_text(t)})
    checklist = "Before you close, the action items. " + " ".join(
        f"{i+1}. {item['text'].rstrip('.')}." for i, item in enumerate(d["action_items"]))
    segs.append({"id": "checklist", "speaker": "advisor", "text": checklist})
    segs.append({"id": "outro", "speaker": "advisor",
        "text": ("That concludes the deliberation. Every unknown became an action item — none of them were "
                 "guessed. Full evidence labels, sources, and the interactive report are in the written package. "
                 "Nvirogear does not find cheap land. Nvirogear finds the reason cheap land is cheap — "
                 "then tells you if there is still a play.")})

    # --- silence gap file
    gap = os.path.join(tmp, "gap.mp3")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i",
                    f"anullsrc=r=24000:cl=mono", "-t", str(GAP_S), "-b:a", "48k", gap], check=True)
    gap_d = dur_of(gap)

    # --- synth every segment
    async def synth_all():
        for s in segs:
            out = os.path.join(tmp, s["id"] + ".mp3")
            if s["speaker"] == "buyer":
                await synth(s["text"], BUYER_VOICE, BUYER_RATE, out)
            else:
                await synth(s["text"], ADVISOR_VOICE, ADVISOR_RATE, out)
            s["dur"] = dur_of(out)
            print(f"  {s['id']:10s} {s['speaker']:8s} {s['dur']:5.1f}s")
    asyncio.run(synth_all())

    # --- concat with gaps, build manifest with start times
    lst = os.path.join(tmp, "list.txt")
    t_cursor = 0.0
    with open(lst, "w") as f:
        for i, s in enumerate(segs):
            if i > 0:
                f.write(f"file 'gap.mp3'\n")
            f.write(f"file '{s['id']}.mp3'\n")
            if i > 0:
                t_cursor += gap_d
            s["start"] = round(t_cursor, 2)
            t_cursor += s["dur"]
    total = round(t_cursor, 2)

    podcast = os.path.join(a.outdir, "podcast.mp3")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0",
                    "-i", lst, "-c", "copy", podcast], check=True)

    manifest = {"package_id": d["package_id"], "package_sha256": d["package_sha256"],
                "audio": "podcast.mp3", "total_seconds": total, "segments": segs}
    with open(os.path.join(a.outdir, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)

    print(f"\nRENDER OK — {podcast}")
    print(f"total: {int(total//60)}m {int(total%60)}s | segments: {len(segs)} | manifest.json written")

if __name__ == "__main__":
    sys.exit(main())
