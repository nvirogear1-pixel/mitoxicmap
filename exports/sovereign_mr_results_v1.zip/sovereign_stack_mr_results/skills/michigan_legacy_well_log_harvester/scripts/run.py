#!/usr/bin/env python3
"""
Nvirogear Legacy Well Log Harvester
Pulls pre-2000 water well record PDFs from EGLE's legacy archive.
URL pattern: https://www.egle.state.mi.us/well-logs-data/{County}/{Town}{Range}{Section} {COUNTY}.pdf

Usage:
  python3 run.py --county Muskegon --output /app/well_logs/muskegon
  python3 run.py --county Ottawa --output /app/well_logs/ottawa
  python3 run.py --county Muskegon --townships "09N-11N" --ranges "14W-18W"
"""

import argparse
import os
import random
import sys
import time
import urllib.request
import urllib.error
import json
from datetime import datetime

BASE_URL = "https://www.egle.state.mi.us/well-logs-data"
REFERER = "https://www.egle.state.mi.us/Well-Logs/"

# Michigan PLSS township/range extents by county (approximate but generous)
# Format: county -> (min_town, max_town, min_range, max_range)
# Town numbers: 01N-10N for southern LP, up to ~50N for UP
# Range numbers: 01E-19E for eastern LP, 01W-20W for western LP
COUNTY_PLSS = {
    "Muskegon":  (9, 11, 14, 18),
    "Ottawa":    (7, 9, 13, 16),
    "Branch":    (5, 8, 3, 7),
    "Genesee":   (5, 9, 5, 9),
    "Mason":     (15, 19, 14, 18),
    "Kent":      (5, 9, 10, 14),
    "Newaygo":   (10, 15, 11, 16),
    "Lake":      (15, 20, 12, 16),
    "Oceana":    (10, 14, 14, 18),
    "Berrien":   (5, 8, 17, 21),
    "Allegan":   (1, 4, 13, 17),
    "Barry":     (1, 5, 7, 11),
    "Calhoun":   (1, 5, 3, 8),
    "Kalamazoo": (1, 4, 9, 13),
    "StJoseph":  (4, 8, 3, 8),
    "Cass":      (5, 8, 10, 15),
    "VanBuren":  (1, 4, 14, 18),
    "Ingham":    (1, 5, 1, 5),
    "Jackson":   (1, 5, 1, 5),
    "Washtenaw": (1, 5, 1, 8),
    "Wayne":     (1, 5, 8, 14),
    "Monroe":    (5, 8, 5, 11),
    "Lapeer":    (5, 10, 8, 14),
    "Macomb":    (1, 5, 12, 16),
    "Oakland":   (1, 5, 7, 12),
    "Livingston":(1, 5, 3, 8),
    "Saginaw":   (9, 13, 1, 6),
    "Bay":       (13, 17, 1, 6),
    "Midland":   (13, 18, 1, 5),
    "Huron":     (13, 20, 1, 10),
    "Tuscola":   (9, 16, 1, 10),
    "Sanilac":   (9, 14, 10, 16),
    "StClair":   (5, 8, 11, 17),
}

PERSONAS = [
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0",
]

REFERRERS = [
    "https://www.google.com/search?q=michigan+water+well+records",
    "https://www.egle.state.mi.us/Well-Logs/",
    "https://www.bing.com/search?q=egle+well+log+search",
    "https://duckduckgo.com/?q=michigan+water+well+records+legacy",
]


def get_headers():
    """Rotate persona + referrer per VaultSmith §2."""
    persona = random.choice(PERSONAS)
    referrer = random.choice(REFERRERS)
    # 10% chance of direct nav (no referrer)
    if random.random() < 0.10:
        referrer = ""
    headers = {"User-Agent": persona}
    if referrer:
        headers["Referer"] = referrer
    return headers


def jitter():
    """VaultSmith §1 — human-like delay."""
    roll = random.random()
    if roll < 0.35:
        time.sleep(random.uniform(1.1, 2.0))   # fast
    elif roll < 0.70:
        time.sleep(random.uniform(2.0, 3.5))   # normal
    elif roll < 0.90:
        time.sleep(random.uniform(3.5, 4.4))   # slow
    else:
        time.sleep(random.uniform(4.4, 6.0))   # very slow


def build_url(county, town_num, range_num, section):
    """Build the well log PDF URL."""
    county_dir = county  # Title case directory
    county_upper = county.upper()
    town = f"{town_num:02d}N"
    rng = f"{range_num:02d}W"
    sect = f"{section:02d}"
    filename = f"{town}{rng}{sect} {county_upper}.pdf"
    return f"{BASE_URL}/{county_dir}/{urllib.parse.quote(filename)}", filename


def harvest_county(county, output_dir, town_min=None, town_max=None, 
                   range_min=None, range_max=None, max_requests=None):
    """Harvest all well log PDFs for a county."""
    
    if county not in COUNTY_PLSS:
        print(f"ERROR: County '{county}' not in PLSS table. Add it or use --townships/--ranges.")
        return None
    
    t_min, t_max, r_min, r_max = COUNTY_PLSS[county]
    if town_min: t_min = town_min
    if town_max: t_max = town_max
    if range_min: r_min = range_min
    if range_max: r_max = range_max
    
    os.makedirs(output_dir, exist_ok=True)
    
    manifest = {
        "county": county,
        "harvested_at": datetime.now().isoformat(),
        "output_dir": output_dir,
        "plss_range": {"town": f"{t_min}N-{t_max}N", "range": f"{r_min}W-{r_max}W"},
        "pdfs_found": 0,
        "pdfs_downloaded": 0,
        "sections_checked": 0,
        "sections_with_data": 0,
        "errors": [],
        "files": []
    }
    
    request_count = 0
    found_count = 0
    
    # Also check for Unverified and Historic records
    special_types = ["", " Unverified", " Historic"]
    
    for town_num in range(t_min, t_max + 1):
        for range_num in range(r_min, r_max + 1):
            for section in range(1, 37):
                for special in special_types:
                    if max_requests and request_count >= max_requests:
                        print(f"\nReached max_requests={max_requests}, stopping.")
                        manifest["errors"].append(f"Stopped at max_requests={max_requests}")
                        return manifest
                    
                    county_upper = county.upper()
                    town = f"{town_num:02d}N"
                    rng = f"{range_num:02d}W"
                    sect = f"{section:02d}"
                    
                    if special:
                        filename = f"{town}{rng}{sect}{special} {county_upper}.pdf"
                    else:
                        filename = f"{town}{rng}{sect} {county_upper}.pdf"
                    
                    url = f"{BASE_URL}/{county}/{urllib.parse.quote(filename)}"
                    local_path = os.path.join(output_dir, filename.replace(" ", "_").replace("%20", "_"))
                    
                    # Skip if already downloaded
                    if os.path.exists(local_path):
                        manifest["sections_checked"] += 1
                        found_count += 1
                        manifest["pdfs_found"] += 1
                        manifest["files"].append({"filename": filename, "path": local_path, "status": "already_exists"})
                        continue
                    
                    try:
                        req = urllib.request.Request(url, headers=get_headers())
                        resp = urllib.request.urlopen(req, timeout=30)
                        data = resp.read()
                        
                        if data[:4] == b'%PDF':
                            with open(local_path, 'wb') as f:
                                f.write(data)
                            found_count += 1
                            manifest["pdfs_found"] += 1
                            manifest["pdfs_downloaded"] += 1
                            manifest["sections_with_data"] += 1
                            size_kb = len(data) / 1024
                            manifest["files"].append({
                                "filename": filename,
                                "path": local_path,
                                "url": url,
                                "size_kb": round(size_kb, 1),
                                "status": "downloaded"
                            })
                            print(f"  ✅ {filename} ({size_kb:.0f} KB)")
                        else:
                            manifest["errors"].append(f"Not a PDF: {url}")
                        
                    except urllib.error.HTTPError as e:
                        if e.code == 404:
                            pass  # Normal — no well logs for this section
                        else:
                            manifest["errors"].append(f"HTTP {e.code}: {url}")
                            print(f"  ⚠️ HTTP {e.code}: {filename}")
                    except Exception as e:
                        manifest["errors"].append(f"ERROR: {url} - {str(e)}")
                        print(f"  ❌ ERROR: {filename} - {e}")
                    
                    request_count += 1
                    manifest["sections_checked"] += 1
                    
                    # VaultSmith §1 — full stop after every 11th successful scrape
                    if found_count > 0 and found_count % 11 == 0:
                        print(f"  ⏸️  11-second pause (VaultSmith §1)...")
                        time.sleep(11)
                    else:
                        jitter()
                    
                    # Progress update every 50 requests
                    if request_count % 50 == 0:
                        print(f"  [{request_count} requests | {found_count} found] {town}{rng} section {sect}...")
    
    return manifest


def main():
    parser = argparse.ArgumentParser(description="Harvest EGLE legacy well log PDFs")
    parser.add_argument("--county", required=True, help="Michigan county name (Title Case)")
    parser.add_argument("--output", default=None, help="Output directory (default: /app/well_logs/{county_lower})")
    parser.add_argument("--townships", default=None, help="Township range, e.g. '09N-11N'")
    parser.add_argument("--ranges", default=None, help="Range range, e.g. '14W-18W'")
    parser.add_argument("--max-requests", type=int, default=None, help="Stop after N requests (for testing)")
    args = parser.parse_args()
    
    output_dir = args.output or f"/app/well_logs/{args.county.lower()}"
    
    town_min = town_max = range_min = range_max = None
    if args.townships:
        parts = args.townships.split("-")
        town_min = int(parts[0].replace("N", ""))
        town_max = int(parts[1].replace("N", ""))
    if args.ranges:
        parts = args.ranges.split("-")
        range_min = int(parts[0].replace("W", ""))
        range_max = int(parts[1].replace("W", ""))
    
    print(f"=== Nvirogear Legacy Well Log Harvester ===")
    print(f"County: {args.county}")
    print(f"Output: {output_dir}")
    if town_min:
        print(f"Townships: {town_min}N-{town_max}N")
    if range_min:
        print(f"Ranges: {range_min}W-{range_max}W")
    print()
    
    manifest = harvest_county(
        args.county, output_dir, town_min, town_max,
        range_min, range_max, args.max_requests
    )
    
    if manifest:
        manifest_path = os.path.join(output_dir, "harvest_manifest.json")
        with open(manifest_path, 'w') as f:
            json.dump(manifest, f, indent=2)
        print(f"\n=== HARVEST COMPLETE ===")
        print(f"Sections checked: {manifest['sections_checked']}")
        print(f"PDFs found: {manifest['pdfs_found']}")
        print(f"PDFs downloaded: {manifest['pdfs_downloaded']}")
        print(f"Errors: {len(manifest['errors'])}")
        print(f"Manifest: {manifest_path}")


if __name__ == "__main__":
    import urllib.parse
    main()
