#!/usr/bin/env python3
"""
Michigan County Parcel Pull — Nvirogear GIS Bot / Jet
Pulls parcels from a county ArcGIS FeatureServer REST endpoint.
Usage: python michigan_county_parcel_pull.py --county "Kent" --service_url "https://..." --max_records 50000
"""

import sys
import json
import argparse
import urllib.request
import urllib.parse
import time
import os

def pull_arcgis_parcels(service_url, county, state="MI", max_records=50000, batch_size=1000):
    """Pull all parcels from an ArcGIS FeatureServer layer."""
    
    results = []
    offset = 0
    has_more = True
    errors = []
    
    # Normalize URL — ensure it points to a layer (layer 0 default)
    if not service_url.endswith('/query') and not '/query' in service_url:
        # Try layer 0
        if service_url.endswith('/'):
            service_url = service_url + '0'
        elif not service_url.split('/')[-1].isdigit():
            service_url = service_url + '/0'
    
    query_base = service_url if service_url.endswith('/query') else service_url + '/query'
    
    print(f"[JET] Pulling {county} County parcels from: {query_base}", flush=True)
    
    while has_more and len(results) < max_records:
        params = {
            'where': '1=1',
            'outFields': '*',
            'returnGeometry': 'true',
            'resultOffset': offset,
            'resultRecordCount': batch_size,
            'f': 'geojson',
            'geometryType': 'esriGeometryPolygon',
            'outSR': '4326'  # WGS84
        }
        
        query_url = query_base + '?' + urllib.parse.urlencode(params)
        
        try:
            req = urllib.request.Request(query_url, headers={
                'User-Agent': 'NviroGear-JetBot/1.0 (property intelligence; contact nvirogear1@gmail.com)'
            })
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read().decode('utf-8'))
        except Exception as e:
            errors.append(f"Offset {offset}: {str(e)}")
            print(f"[JET] Error at offset {offset}: {e}", flush=True)
            break
        
        features = data.get('features', [])
        if not features:
            has_more = False
            break
        
        for feat in features:
            props = feat.get('properties', {})
            geom = feat.get('geometry')
            
            # Normalize parcel ID — try common field names
            parcel_id = (
                props.get('PARCELID') or props.get('PIN') or props.get('APN') or
                props.get('PARID') or props.get('PARCEL_ID') or props.get('Parcel_ID') or
                props.get('parcel_id') or props.get('OBJECTID') or str(offset + len(results))
            )
            
            # Normalize address
            address = (
                props.get('ADDRESS') or props.get('SITEADDRESS') or props.get('SITE_ADDRESS') or
                props.get('PROPADDRESS') or props.get('ADDR') or props.get('StreetAddress') or
                props.get('FULL_ADDRESS') or ''
            )
            
            # Normalize owner
            owner = (
                props.get('OWNER') or props.get('OWNER1') or props.get('OWN_NAME') or
                props.get('OWNERNME1') or props.get('GRANTEE') or props.get('TAXPAYER') or ''
            )
            
            # Normalize acreage
            acreage = (
                props.get('ACREAGE') or props.get('ACRES') or props.get('CALCACRES') or
                props.get('GIS_ACRES') or props.get('TOTALACRES') or props.get('AREA_ACRES') or None
            )
            
            # Extract centroid from geometry if polygon
            lat, lng = None, None
            geom_type = 'no_geometry'
            polygon_geojson = None
            
            if geom:
                geom_kind = geom.get('type', '')
                if geom_kind == 'Polygon':
                    polygon_geojson = json.dumps(geom)
                    geom_type = 'polygon'
                    # Centroid approximation from first ring
                    coords = geom.get('coordinates', [[]])[0]
                    if coords:
                        lats = [c[1] for c in coords if len(c) >= 2]
                        lngs = [c[0] for c in coords if len(c) >= 2]
                        if lats and lngs:
                            lat = sum(lats) / len(lats)
                            lng = sum(lngs) / len(lngs)
                elif geom_kind == 'MultiPolygon':
                    polygon_geojson = json.dumps(geom)
                    geom_type = 'polygon'
                    coords = geom.get('coordinates', [[[]]])[0][0]
                    if coords:
                        lats = [c[1] for c in coords if len(c) >= 2]
                        lngs = [c[0] for c in coords if len(c) >= 2]
                        if lats and lngs:
                            lat = sum(lats) / len(lats)
                            lng = sum(lngs) / len(lngs)
                elif geom_kind == 'Point':
                    coords = geom.get('coordinates', [])
                    if len(coords) >= 2:
                        lng, lat = coords[0], coords[1]
                    geom_type = 'centroid'
            
            record = {
                'parcel_id': str(parcel_id).strip(),
                'county': county,
                'state': state,
                'address': address.strip() if address else None,
                'owner_name': owner.strip() if owner else None,
                'acreage': float(acreage) if acreage else None,
                'centroid_lat': round(lat, 6) if lat else None,
                'centroid_lng': round(lng, 6) if lng else None,
                'geometry_type': geom_type,
                'polygon_geojson': polygon_geojson,
                'source_name': 'ArcGIS County Parcel Layer',
                'source_url': service_url,
                'source_confidence': 'high' if geom_type == 'polygon' else 'medium',
                'raw_props': json.dumps({k: v for k, v in list(props.items())[:20]})  # first 20 fields
            }
            results.append(record)
        
        print(f"[JET] {county}: pulled {len(results)} records (offset {offset})", flush=True)
        
        # Check if more records exist
        if len(features) < batch_size:
            has_more = False
        else:
            offset += batch_size
            time.sleep(0.5)  # polite delay
    
    return results, errors


def main():
    parser = argparse.ArgumentParser(description='Michigan County Parcel Pull — Nvirogear Jet')
    parser.add_argument('--county', required=True, help='County name (e.g. Kent)')
    parser.add_argument('--service_url', required=True, help='ArcGIS FeatureServer URL')
    parser.add_argument('--max_records', type=int, default=50000, help='Max records to pull')
    parser.add_argument('--output', default='', help='Output file path (default: stdout)')
    args = parser.parse_args()
    
    records, errors = pull_arcgis_parcels(
        service_url=args.service_url,
        county=args.county,
        max_records=args.max_records
    )
    
    output = {
        'county': args.county,
        'state': 'MI',
        'record_count': len(records),
        'polygon_count': sum(1 for r in records if r['geometry_type'] == 'polygon'),
        'centroid_count': sum(1 for r in records if r['geometry_type'] == 'centroid'),
        'no_geometry_count': sum(1 for r in records if r['geometry_type'] == 'no_geometry'),
        'errors': errors,
        'records': records
    }
    
    if args.output:
        with open(args.output, 'w') as f:
            json.dump(output, f)
        print(f"[JET] Written to {args.output}")
    else:
        print(json.dumps(output, indent=2))
    
    print(f"\n[JET] SUMMARY: {args.county} — {len(records)} records, {output['polygon_count']} polygons, {len(errors)} errors")


if __name__ == '__main__':
    main()
