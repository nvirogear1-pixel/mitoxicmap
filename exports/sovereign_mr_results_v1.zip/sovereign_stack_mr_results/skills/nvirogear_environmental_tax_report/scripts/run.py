#!/usr/bin/env python3
"""
Nvirogear Environmental-Tax Correlation Report generator.
Usage: python3 run.py <data.json> <output.html>
See ../report_data_template.json for the required data schema.
Governed by .agents/rules/nvirogear_environmental_tax_correlation_standard_v1.md
"""
import json, sys, html

CSS = """
:root{
  --bg:#0a0e14; --panel:#111823; --panel2:#161f2c; --border:#1f2c3d;
  --text:#dbe4ee; --muted:#7c8ba1; --gold:#c9a24b; --navy:#1b2a41;
  --green:#3ecf8e; --amber:#e8b13a; --red:#e85c4a; --blue:#4a9de8;
}
*{box-sizing:border-box;}
body{margin:0;background:var(--bg);color:var(--text);font-family:'Segoe UI',Arial,sans-serif;line-height:1.55;}
.wrap{max-width:1000px;margin:0 auto;padding:0 18px;}
header.cover{background:linear-gradient(180deg,var(--navy),var(--bg));border-bottom:3px solid var(--gold);padding:34px 0 26px;}
.brand{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;}
.brand h1{font-size:22px;margin:0;color:#fff;letter-spacing:.5px;}
.brand small{color:var(--gold);font-weight:600;letter-spacing:1px;}
.report-id{font-size:12px;color:var(--muted);text-align:right;}
.title-block{margin-top:22px;}
.title-block h2{font-size:26px;margin:0 0 6px;color:#fff;}
.title-block p{margin:0;color:var(--muted);font-size:14px;}
.pill-row{margin-top:16px;display:flex;gap:10px;flex-wrap:wrap;}
.pill{padding:6px 14px;border-radius:20px;font-size:12px;font-weight:700;letter-spacing:.4px;}
.pill.blocker{background:rgba(232,92,74,.15);color:var(--red);border:1px solid var(--red);}
.pill.gate{background:rgba(232,177,58,.15);color:var(--amber);border:1px solid var(--amber);}
.pill.status{background:rgba(74,157,232,.15);color:var(--blue);border:1px solid var(--blue);}
section{padding:26px 0;border-bottom:1px solid var(--border);}
.sec-head{display:flex;align-items:center;gap:12px;margin-bottom:16px;}
.sec-num{background:var(--gold);color:#12181f;font-weight:800;font-size:13px;padding:4px 10px;border-radius:4px;}
.sec-head h3{margin:0;font-size:18px;color:#fff;}
.card{background:var(--panel);border:1px solid var(--border);border-radius:8px;padding:18px;margin-bottom:14px;}
.card h4{margin:0 0 10px;font-size:14px;color:var(--gold);text-transform:uppercase;letter-spacing:.6px;}
table{width:100%;border-collapse:collapse;font-size:13.5px;}
th,td{padding:8px 10px;border-bottom:1px solid var(--border);text-align:left;vertical-align:top;}
th{color:var(--muted);font-weight:600;font-size:12px;text-transform:uppercase;letter-spacing:.4px;}
.badge{display:inline-block;padding:2px 9px;border-radius:12px;font-size:11px;font-weight:700;letter-spacing:.3px;}
.badge.verified{background:rgba(62,207,142,.15);color:var(--green);border:1px solid var(--green);}
.badge.probable{background:rgba(232,177,58,.15);color:var(--amber);border:1px solid var(--amber);}
.badge.advisory{background:rgba(74,157,232,.15);color:var(--blue);border:1px solid var(--blue);}
.badge.blocker{background:rgba(232,92,74,.15);color:var(--red);border:1px solid var(--red);}
.badge.needs{background:rgba(124,139,161,.2);color:var(--muted);border:1px solid var(--muted);}
#map{height:440px;border-radius:8px;border:1px solid var(--border);margin-top:10px;}
.legend{display:flex;gap:16px;flex-wrap:wrap;font-size:12px;color:var(--muted);margin-top:10px;}
.legend span{display:inline-flex;align-items:center;gap:6px;}
.dot{width:10px;height:10px;border-radius:50%;display:inline-block;}
ul.checklist{list-style:none;padding:0;margin:0;}
ul.checklist li{padding:7px 0;border-bottom:1px dashed var(--border);font-size:13.5px;}
ul.checklist li:before{content:"\\2610  ";color:var(--gold);}
ul.linklist{list-style:none;padding:0;margin:0;}
ul.linklist li{padding:9px 0;border-bottom:1px dashed var(--border);font-size:13.5px;}
ul.linklist li b{color:#fff;}
ul.linklist li .note{color:var(--muted);font-size:12px;display:block;margin-top:2px;}
.fact{border-left:3px solid var(--blue);}
.analysis{border-left:3px solid var(--gold);}
.timeline{border-left:2px solid var(--border);margin-left:8px;padding-left:20px;}
.timeline .tl-item{position:relative;padding-bottom:16px;}
.timeline .tl-item:before{content:"";position:absolute;left:-25px;top:4px;width:10px;height:10px;border-radius:50%;background:var(--gold);}
.timeline .tl-year{font-weight:800;color:#fff;font-size:14px;}
footer{padding:24px 0;text-align:center;font-size:11px;color:var(--muted);}
a{color:var(--blue);}
.provenance{margin-top:10px;font-size:11.5px;color:var(--muted);border-top:1px solid var(--border);padding-top:8px;}
.urgent{background:rgba(232,92,74,.1);border:1px solid var(--red);border-radius:8px;padding:16px;margin-bottom:14px;}
"""

BADGE = lambda label, cls: f'<span class="badge {cls}">{html.escape(label)}</span>'
CONF_CLASS = {"VERIFIED":"verified","PROBABLE":"probable","ADVISORY":"advisory","BLOCKER":"blocker","NEEDS VERIFICATION":"needs"}

def conf_badge(label):
    return BADGE(label, CONF_CLASS.get(label, "needs"))

def render_table(headers, rows):
    th = "".join(f"<th>{html.escape(h)}</th>" for h in headers)
    trs = ""
    for row in rows:
        tds = "".join(f"<td>{c}</td>" for c in row)
        trs += f"<tr>{tds}</tr>"
    return f"<table><tr>{th}</tr>{trs}</table>"

def render_links(links):
    """links: list of {label, url, note}"""
    items = ""
    for l in links:
        note = f'<span class="note">{html.escape(l["note"])}</span>' if l.get("note") else ""
        items += f'<li><b>{html.escape(l["label"])}</b> — <a href="{html.escape(l["url"])}" target="_blank">{html.escape(l["url"])}</a>{note}</li>'
    return f'<ul class="linklist">{items}</ul>'

def build_report(d):
    p = d["property"]
    r = d["reader_context"]
    env_sites = d.get("environmental_sites", [])
    no_hits = d.get("no_hit_checks", [])
    well = d.get("well_testing", [])
    tax = d.get("tax_history", [])
    timeline = d.get("timeline", [])
    lenses = d.get("lenses", {})
    contradictions = d.get("contradictions", [])
    risks = d.get("risk_register", [])
    next_steps = d.get("next_steps", [])
    sources = d.get("source_ledger", [])
    resource_links = d.get("resource_links", [])
    geology = d.get("subsurface_geology", {})
    owner_portfolio = d.get("owner_portfolio", [])
    overpayment = d.get("overpayment_analysis", {})

    env_rows = [[html.escape(s["name"]), html.escape(s["type"]), f'{s["distance_mi"]} mi {s.get("direction","")}',
                 conf_badge(s.get("risk_label","VERIFIED")) + " " + html.escape(s.get("risk_condition",""))]
                for s in env_sites]
    env_table = render_table(["Site","Type","Distance","Risk Condition"], env_rows)

    env_detail_cards = ""
    for s in env_sites:
        rows = [
            ["Site ID / Facility ID", html.escape(str(s.get("site_id","N/A")))],
            ["Risk Condition (EGLE official)", conf_badge(s.get("risk_label","VERIFIED")) + " " + html.escape(s.get("risk_condition",""))],
            ["Contaminants on file", html.escape(s.get("contaminants","N/A"))],
            ["BEA on file", html.escape(s.get("has_bea","N/A"))],
            ["Project Manager", html.escape(s.get("project_manager","N/A"))],
            ["Last Updated", html.escape(s.get("last_updated","N/A"))],
        ]
        env_detail_cards += f'<div class="card fact"><h4>{html.escape(s["name"])} — full record</h4>{render_table(["Field","Value"], rows)}</div>'

    no_hit_rows = [[html.escape(c["check"]), html.escape(c["result"]), conf_badge(c.get("confidence","VERIFIED"))] for c in no_hits]
    no_hit_table = render_table(["Check","Result","Confidence"], no_hit_rows) if no_hit_rows else ""

    well_rows = [[html.escape(w["test"]), html.escape(w["covers"]), html.escape(w["cost"]), html.escape(w["where"])] for w in well]
    well_table = render_table(["Test","Covers","Cost","Where"], well_rows)

    tax_rows = [[html.escape(str(t["year"])), html.escape(str(t["amount"])), html.escape(t.get("note",""))] for t in tax]
    tax_table = render_table(["Year","Property Tax","Note"], tax_rows)

    timeline_html = "".join(
        f'<div class="tl-item"><div class="tl-year">{html.escape(str(t["year"]))}</div>{html.escape(t["event"])}</div>'
        for t in timeline
    )

    lens_cards = "".join(
        f'<div class="card"><h4>{html.escape(name)}</h4><p>{html.escape(text)}</p></div>'
        for name, text in lenses.items()
    )

    contra_rows = [[html.escape(c["claim"]), html.escape(c["reality"]), conf_badge(c.get("status","NEEDS VERIFICATION")), conf_badge(c.get("confidence","NEEDS VERIFICATION"))] for c in contradictions]
    contra_table = render_table(["Claim","Verified Reality","Status","Confidence"], contra_rows) if contra_rows else "<p>No contradictions identified.</p>"

    risk_rows = [[html.escape(rk["risk"]), html.escape(rk["severity"]), conf_badge(rk.get("confidence","NEEDS VERIFICATION")), html.escape(rk.get("status",""))] for rk in risks]
    risk_table = render_table(["Risk","Severity","Confidence","Status"], risk_rows)

    next_steps_html = "".join(f"<li>{html.escape(s)}</li>" for s in next_steps)

    source_rows = [[str(i+1), html.escape(s["source"]), conf_badge(s.get("confidence","ADVISORY"))] for i, s in enumerate(sources)]
    source_table = render_table(["#","Source","Confidence"], source_rows)

    links_html = render_links(resource_links) if resource_links else ""

    portfolio_html = ""
    if owner_portfolio:
        port_rows = [[html.escape(p["parcel_id"]), html.escape(p.get("address","(no address on file)")), html.escape(p.get("city","")), str(p["acreage"])+" ac", "${:,.0f}".format(p.get("sev",0)), "${:,.0f}".format(p.get("tv",0)), html.escape(p.get("class",""))] for p in owner_portfolio]
        port_table = render_table(["Parcel ID","Address","City","Acreage","SEV","Taxable Value","Class"], port_rows)
        total_ac = sum(p["acreage"] for p in owner_portfolio)
        total_sev = sum(p.get("sev",0) for p in owner_portfolio)
        total_tv = sum(p.get("tv",0) for p in owner_portfolio)
        portfolio_html = (
            '<section><div class="sec-head"><span class="sec-num">S2.5</span><h3>Owner Portfolio -- Related Parcels</h3></div>'
            + '<div class="card fact">' + port_table
            + '<p style="margin-top:12px;font-size:13.5px;color:#fff;"><b>Totals: ' + str(round(total_ac,2)) + ' acres | SEV ${:,.0f}'.format(total_sev) + ' | Taxable Value ${:,.0f}</b></p>'.format(total_tv)
            + '<p style="margin-top:6px;font-size:12px;color:var(--muted);">Pulled live from the county parcel GIS by matching owner name -- confirms the full extent of this owner\'s holdings in the immediate area, not just the subject parcel.</p></div></section>'
        )
    geology_html = ""

    if geology:
        wells = geology.get("oil_gas_wells", [])
        well_rows2 = [[html.escape(w["well_name"]), html.escape(w["api_num"]), html.escape(w["status"]),
                       html.escape(str(w.get("depth_ft","N/A"))), html.escape(w.get("logs_available","N/A")),
                       str(w["distance_mi"]) + " mi"] for w in wells]
        wells_table = render_table(["Well Name","API Number","Status","Depth (ft)","Logs Available","Distance"], well_rows2) if well_rows2 else "<p>None found within search radius.</p>"
        note1 = 'Old plugged wells can act as cross-aquifer conduits if not sealed properly. Actual drilling logs are public record where marked &quot;YES&quot; -- request directly from EGLE OGMD using the API number; the OGMD Data Explorer web app is not reliably automatable (same category as MISS DIG\'s map widget).'
        note2 = "Regional geologic context only -- does not establish groundwater flow direction or confirm an exposure pathway to this specific well. Not a substitute for a site-specific hydrogeological study."
        geo_rows = [
            ["Surficial (Quaternary) Geology", html.escape(geology.get("quaternary", "NEEDS VERIFICATION"))],
            ["Bedrock Geology", html.escape(geology.get("bedrock", "NEEDS VERIFICATION"))],
            ["Dominant Soil (USDA SSURGO)", html.escape(geology.get("soil_dominant", "NEEDS VERIFICATION"))],
            ["Soil Association Notes", html.escape(geology.get("soil_notes", ""))],
        ]
        geo_table = render_table(["Layer","Finding"], geo_rows)
        geology_html = (
            '<section><div class="sec-head"><span class="sec-num">S6.5</span><h3>Subsurface &amp; Geologic Correlation</h3></div>'
            + '<div class="card fact"><h4>Oil, Gas &amp; Mineral Wells (EGLE GrmdOpenData)</h4>' + wells_table
            + '<p style="margin-top:10px;font-size:13px;color:var(--muted);">' + note1 + '</p></div>'
            + '<div class="card fact">' + geo_table
            + '<p style="margin-top:10px;font-size:13px;color:var(--muted);">' + note2 + '</p></div></section>'
        )

    map_markers = ""
    for s in env_sites:
        color = "#e85c4a" if s.get("risk_label") in ("BLOCKER","VERIFIED") and "Risk" in s.get("risk_condition","") else "#3ecf8e"
        popup = f'{s["name"]}<br>{s.get("risk_condition","")}<br>Distance: {s["distance_mi"]} mi {s.get("direction","")}'
        map_markers += f"""
        L.marker([{s['lat']}, {s['lng']}], {{icon: L.divIcon({{className:'', html:'<div style="width:14px;height:14px;border-radius:50%;background:{color};border:2px solid #fff;box-shadow:0 0 8px {color};"></div>'}})}}).addTo(map)
          .bindPopup({json.dumps(popup)});
        """

    polygon = p.get("polygon")
    if polygon:
        polygon_js = f"""
        L.polygon({json.dumps(polygon)}, {{color:'#4a9de8', weight:2, fillColor:'#4a9de8', fillOpacity:0.12}}).addTo(map)
          .bindPopup({json.dumps(p['address'] + ' — verified parcel boundary (county GIS)')});
        """
        subject_marker_js = ""  # polygon replaces point marker
    else:
        polygon_js = ""
        subject_marker_js = f"""
        L.marker([{p['lat']}, {p['lng']}], {{icon: L.divIcon({{className:'', html:'<div style="width:16px;height:16px;border-radius:50%;background:#4a9de8;border:2px solid #fff;box-shadow:0 0 8px #4a9de8;"></div>'}})}}).addTo(map)
          .bindPopup({json.dumps(p['address'] + ' — Subject Parcel')});
        """

    urgent_html = f'<div class="urgent"><strong style="color:var(--red)">Time-sensitive:</strong> {html.escape(d.get("urgent_note",""))}</div>' if d.get("urgent_note") else ""

    links_section = f"""
<section>
  <div class="sec-head"><span class="sec-num">S13</span><h3>Source Data, Testing Equipment &amp; Lab Contacts</h3></div>
  <div class="card">{links_html}</div>
</section>
""" if resource_links else ""

    html_out = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Nvirogear Environmental-Tax Correlation Report — {html.escape(p['address'])}</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>{CSS}</style>
</head>
<body>
<header class="cover">
  <div class="wrap">
    <div class="brand">
      <h1>NVIROGEAR <small>| ENVIRONMENTAL-TAX CORRELATION REPORT</small></h1>
      <div class="report-id">Report ID: {html.escape(d['report_id'])}<br>Generated: {html.escape(d['generated_date'])}</div>
    </div>
    <div class="title-block">
      <h2>{html.escape(p['address'])}</h2>
      <p>{html.escape(p['municipality'])}, {html.escape(p['county'])} County, {html.escape(p.get('state','MI'))} &nbsp;|&nbsp; Parcel ID {html.escape(p['parcel_id'])} &nbsp;|&nbsp; {p['acreage']} acres</p>
    </div>
    <div class="pill-row">
      <span class="pill gate">Prepared for: {html.escape(r['reader_name'])} ({html.escape(r['relationship'])})</span>
      <span class="pill status">Property Status: {html.escape(r['property_status'])}</span>
    </div>
  </div>
</header>
<div class="wrap">

<section>
  <div class="sec-head"><span class="sec-num">S1</span><h3>Executive Summary</h3></div>
  {urgent_html}
  <div class="card"><p>{html.escape(d.get('executive_summary',''))}</p></div>
</section>

<section>
  <div class="sec-head"><span class="sec-num">S2</span><h3>Parcel &amp; Ownership Profile</h3></div>
  <div class="card fact">
    {render_table(["Field","Value"], [
      ["Owner of Record", html.escape(p.get('owner_name','N/A'))],
      ["Zoning", html.escape(p.get('zoning','N/A'))],
      ["Coordinates", f"{p['lat']}, {p['lng']}"],
      ["Listing Status", html.escape(r.get('listing_status_note',''))],
    ])}
  </div>
</section>

{portfolio_html}

<section>
  <div class="sec-head"><span class="sec-num">S3</span><h3>Environmental Profile — Full-Field EGLE Pull</h3></div>
  <div class="card">{env_table}</div>
  {env_detail_cards}
  {'<div class="card">' + no_hit_table + '</div>' if no_hit_table else ''}
</section>

<section>
  <div class="sec-head"><span class="sec-num">S4</span><h3>Well Water Testing — Real Options and Costs</h3></div>
  <div class="card">{well_table}</div>
</section>

<section>
  <div class="sec-head"><span class="sec-num">S5</span><h3>Tax &amp; Assessment History</h3></div>
  <div class="card fact">{tax_table}</div>
</section>

<section>
  <div class="sec-head"><span class="sec-num">S6</span><h3>Assessment-Environment Timeline</h3></div>
  <div class="card"><div class="timeline">{timeline_html}</div></div>
</section>

<section>
  <div class="sec-head"><span class="sec-num">S7</span><h3>Interactive Evidence Map</h3></div>
  <div class="card"><div id="map"></div></div>
</section>

{geology_html}

<section>
  <div class="sec-head"><span class="sec-num">S8</span><h3>Multi-Lens Analysis</h3></div>
  {lens_cards}
</section>

<section>
  <div class="sec-head"><span class="sec-num">S9</span><h3>Contradiction Engine</h3></div>
  <div class="card">{contra_table}</div>
</section>

<section>
  <div class="sec-head"><span class="sec-num">S10</span><h3>Risk Register</h3></div>
  <div class="card">{risk_table}</div>
</section>

<section>
  <div class="sec-head"><span class="sec-num">S10.5</span><h3>Financial Exposure -- What Can and Cannot Be Calculated</h3></div>
  <div class="card">
    <p><strong style="color:var(--gold)">What we can show you, verified:</strong> {html.escape(overpayment.get("verified_facts",""))}</p>
    <p style="margin-top:10px;"><strong style="color:var(--red)">What we cannot calculate from public data alone:</strong> {html.escape(overpayment.get("cannot_calculate",""))}</p>
    <p style="margin-top:10px;"><strong style="color:var(--muted)">What it would take to get a real number:</strong> {html.escape(overpayment.get("what_it_would_take",""))}</p>
  </div>
</section>

<section>
  <div class="sec-head"><span class="sec-num">S11</span><h3>The Appeal Pathway</h3></div>
  <div class="card"><p>{html.escape(d.get('appeal_pathway_note',''))}</p></div>
</section>

<section>
  <div class="sec-head"><span class="sec-num">S12</span><h3>Recommended Next Steps</h3></div>
  <div class="card"><ul class="checklist">{next_steps_html}</ul></div>
</section>

{links_section}

<section>
  <div class="sec-head"><span class="sec-num">S14</span><h3>Source Ledger</h3></div>
  <div class="card">{source_table}</div>
</section>

<section>
  <div class="sec-head"><span class="sec-num">S15</span><h3>Report Limitations</h3></div>
  <div class="card"><p>{html.escape(d.get('limitations',''))}</p></div>
</section>

</div>
<footer>
  NviroGear LLC &bull; Environmental-Tax Correlation Report Standard v1.0 &nbsp;|&nbsp; {html.escape(d['generated_date'])} &nbsp;|&nbsp; Report ID: {html.escape(d['report_id'])}<br>
  "Nvirogear does not find cheap land. Nvirogear finds the reason cheap land is cheap — then tells you if there is still a play."
</footer>
<script>
  var map = L.map('map').setView([{p['lat']}, {p['lng']}], 15);
  L.tileLayer('https://{{s}}.basemaps.cartocdn.com/dark_all/{{z}}/{{x}}/{{y}}{{r}}.png', {{
    attribution: '&copy; OpenStreetMap &copy; CARTO', maxZoom: 19
  }}).addTo(map);
  {subject_marker_js}
  {polygon_js}
  L.circle([{p['lat']}, {p['lng']}], {{radius: 1609, color:'#c9a24b', weight:1, dashArray:'6,6', fillOpacity:0.02}}).addTo(map);
  {map_markers}
</script>
</body>
</html>
"""
    return html_out

def main():
    if len(sys.argv) != 3:
        print("Usage: python3 run.py <data.json> <output.html>")
        sys.exit(1)
    with open(sys.argv[1]) as f:
        data = json.load(f)
    out = build_report(data)
    with open(sys.argv[2], "w") as f:
        f.write(out)
    print(f"Wrote {sys.argv[2]} ({len(out)} bytes)")

if __name__ == "__main__":
    main()
