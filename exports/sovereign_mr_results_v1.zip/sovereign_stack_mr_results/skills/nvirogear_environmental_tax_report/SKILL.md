# Nvirogear Environmental-Tax Correlation Report — Skill

## Purpose
Generates a full Nvirogear-branded HTML report (dark command-center aesthetic, interactive Leaflet
map, multi-lens analysis) that correlates a parcel's environmental risk profile with its tax
assessment history, and gives the reader (buyer, owner, or agent) a legally correct, defensible
next-steps path. Governed by `.agents/rules/nvirogear_environmental_tax_correlation_standard_v1.md`
— read that file before generating a report if any doubt exists about legal language or structure.

## When to use this skill
- User asks for a "full report" / "enterprise report" on a specific Michigan property
- User wants environmental risk correlated with tax assessment behavior
- User wants a due-diligence report for someone considering buying a property
- User wants a homeowner report on well water safety near a known contamination site

## Required inputs (gather BEFORE running — never fabricate)
1. Parcel identity: address, county, parcel ID, acreage, zoning, coordinates — from county
   ArcGIS FeatureServer (search "<County> GIS parcel viewer ArcGIS REST" if unknown)
2. Ownership + sale history: county GIS owner field + Redfin/Zillow public-records extract
3. Full-field EGLE environmental pulls — MANDATORY full fields, not summary only:
   - Part 201 Sites: `https://gisagoegle.state.mi.us/arcgis/rest/services/EGLE/RRDOpenData/MapServer/0/query`
   - UST Facilities: same MapServer, layer `/1`
   - Brownfields: layer `/3`
   - PFAS: `https://gisagoegle.state.mi.us/arcgis/rest/services/EGLE/PfasOpenData/MapServer`
   - Query with `outFields=*` (never just SiteName/Address/City) to get RiskCondition,
     Contaminants, ReleaseStatus, HasBEA, LastUpdated, ProjectManager
4. Well records (if relevant): EGLE DwOpenData MapServer, layer `/1` = Type I (private) wells,
   layer `/2` = Type II (public) wells. Often sparse/no data for rural counties — report as a real
   gap (NEEDS VERIFICATION), never invent groundwater flow direction or well depth.
5. Tax history: public-records extract (Redfin) gives at least one year; full multi-year SEV/TV
   requires direct BS&A Online session (JavaScript-rendered, cannot be queried via curl)
6. FEMA flood zone / NWI wetlands: attempt live query; if service unreachable, mark
   NEEDS VERIFICATION — do not substitute a AVM-provided climate score as if it were FEMA data
   without labeling it PUBLIC REFERENCE / ADVISORY.

## MANDATORY legal framework (do not deviate — verified against Michigan Legislature site)
- Appeal venue: March Board of Review (mandatory) → Michigan Tax Tribunal petition by July 31
  (residential/agricultural) or May 31 (commercial/industrial/developmental) of the tax year.
- Contamination valuation statute: **MCL 211.34d** (NOT 211.27a — that's the ownership-transfer/
  uncapping statute).
- Qualified Error correction (MCL 211.53b) is narrow — clerical/mutual-mistake-of-fact only, NOT
  a route for contamination valuation disputes or reopening past tax years.
- NEVER claim a general right to recover back taxes because "the state knew" about contamination.
- NEVER say "take this to court" — say "petition the March Board of Review, then the Michigan Tax
  Tribunal."
- If today's date is past March of the current year, explicitly flag that the current tax year's
  Board of Review has likely already passed and the live window is the following year.

## Report framing — check BEFORE writing
Determine who the reader is and what stage the property is at:
- Reader is a **prospective buyer**, property **not currently listed** → WATCHLIST CANDIDATE,
  Type 1 (Pre-Acquisition) framing, owner-of-record = seller (expected, not a blocker)
- Reader is a **prospective buyer**, property **actively listed/auction** → LIVE OPPORTUNITY
- Reader **already owns** the property → Type 2 (Post-Acquisition) framing, owner-of-record
  mismatch with reader IS a real flag worth raising (title question)
- Never assume the reader owns the property just because they asked about "an address" —
  confirm relationship (buyer, owner, agent, curious neighbor) from conversation context first.

## Output structure (12 sections — see rules file for full detail)
S1 Executive Summary · S2 Parcel/Ownership Profile · S3 Environmental Profile (full-field) ·
S4 Well Water Testing (real costs/labs) · S5 Tax & Assessment History · S6 Assessment-Environment
Timeline · S7 Interactive Evidence Map · S8 Multi-Lens Analysis (Investor/Homeowner minimum) ·
S9 Contradiction Engine · S10 The Appeal Pathway · S11 Recommended Next Steps ·
S12 Source Ledger + Report Limitations

## How to run
1. Gather all real data per "Required inputs" above using bash/curl + web_search tools.
2. Build a JSON data file matching the schema in `scripts/report_data_template.json`.
3. Run: `python3 scripts/run.py <data.json> <output.html>`
4. Validate output (balanced tags, uploads cleanly) before sending to the user.
5. Upload with `upload_file` and share the link.

## Style requirements (standing user instructions — always apply)
- Dark command-center aesthetic (see CSS in scripts/run.py — reuse, don't redesign)
- Confidence badges (VERIFIED / PROBABLE / ADVISORY / NEEDS VERIFICATION / BLOCKER) on every claim
- Contradiction Engine table mandatory
- Never invent data to fill a gap — label it NEEDS VERIFICATION and explain why
