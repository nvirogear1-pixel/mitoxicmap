#!/usr/bin/env python3
"""
VaultSmith 11:11x4 — Ghost Pipe Scraping Base Class
Nvirogear LLC · N-ViroGear Land Intelligence System

Protocol: GhostPipe / VaultSmith 11:11x4
Objective: Scrape high-value land data with zero digital footprint.

Layers implemented:
  §1  Human jitter         — random.uniform(1.1, 4.4) + 11s full stop every 11 reqs
  §2  Header rotation      — 4 resident personas, referrer spoofing
  §3  s_sig watermark      — 11-char hash(parcel_id + timestamp) injected before DB write
  §4  Proxy cycling        — rotate on 429 or after 11 hits from same IP in 4 min window
  §5  VS_CANARY provenance — internal _vs block on every record (stripped before export)

All bots inherit VaultSmithScraper. Never rewrite this logic locally.
"""

import hashlib
import os
import random
import time
import json
import string
from datetime import datetime, timezone
from typing import Optional

# ── VaultSmith Constants — LOCKED ─────────────────────────────────────────────
VS_CANARY   = "VS11_HES_2026_04_A9f3c"
VS_SYSTEM   = "VaultSmith_11_11"
VS_PRODUCT  = "Homestead_Estates_MI"
VS_PIPELINE = "Base44_to_Supabase_to_Emergent"

# ── §2: 4 Resident Personas (mobile / desktop mac / windows pc / linux) ───────
PERSONAS = [
    {
        # Persona A — Mobile (iPhone Safari)
        "User-Agent":      "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept":          "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection":      "keep-alive",
    },
    {
        # Persona B — Desktop Mac (Chrome on macOS)
        "User-Agent":      "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept":          "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection":      "keep-alive",
    },
    {
        # Persona C — Windows PC (Firefox)
        "User-Agent":      "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept":          "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection":      "keep-alive",
    },
    {
        # Persona D — Linux (Chrome on Ubuntu)
        "User-Agent":      "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9,de;q=0.3",
        "Accept":          "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection":      "keep-alive",
    },
]

assert len(PERSONAS) == 4, "Must have exactly 4 personas — VaultSmith 11:11x4 protocol"

# ── §2: Referrer pool — looks like organic search or county navigation ─────────
REFERRER_POOL = [
    "https://www.google.com/search?q=michigan+county+parcel+lookup",
    "https://www.bing.com/search?q=mason+county+gis+parcel+map",
    "https://www.google.com/search?q=site:liaa.org+parcel+search",
    "https://duckduckgo.com/?q=michigan+land+records+gis",
    "https://www.google.com/search?q=muskegon+county+property+records",
    None,  # Occasionally no referrer (direct navigation) — human behavior
    None,
]

# ── §4: Proxy mesh — load from environment, rotate on 429 or IP limit ─────────
# Set PROXY_LIST in .env as comma-separated: http://user:pass@host:port,...
# If empty, runs without proxy (dev mode only — not for production county scraping)
def _load_proxy_pool() -> list:
    raw = os.environ.get("PROXY_LIST", "")
    if not raw.strip():
        return []
    return [p.strip() for p in raw.split(",") if p.strip()]


class VaultSmithScraper:
    """
    Base class for all N-ViroGear GhostPipe scrapers.

    Usage:
        class MasonConnector(VaultSmithScraper):
            def run(self):
                for url in self.targets:
                    resp = self.fetch(url)
                    record = self.parse(resp)
                    record = self.watermark(record)
                    self.stage(record)

    Key methods:
        self.fetch(url)         → GET with jitter, persona, proxy, 429 handling
        self.watermark(record)  → inject s_sig + _vs block
        self.jitter()           → call manually if not using self.fetch()
        self.get_headers(url)   → current persona headers + spoofed referrer
    """

    def __init__(self, bot_name: str, county: str, state: str = "MI"):
        self.bot_name       = bot_name
        self.county         = county
        self.state          = state
        self.request_count  = 0
        self.session_start  = datetime.now(timezone.utc).isoformat()
        self._persona_idx   = random.randint(0, 3)
        self._proxy_pool    = _load_proxy_pool()
        self._proxy_idx     = 0
        self._ip_hit_window : list[float] = []   # timestamps of requests from current IP
        self._staged        : list[dict]  = []

    # ── §2: Header rotation ────────────────────────────────────────────────────
    def get_headers(self, url: str = "") -> dict:
        """Return headers for current persona + spoofed referrer."""
        headers = PERSONAS[self._persona_idx].copy()

        # Referrer: use county's own domain if we know it, else search engine
        referrer = random.choice(REFERRER_POOL)
        if referrer:
            headers["Referer"] = referrer

        return headers

    def _rotate_persona(self):
        """Cycle to next persona (called every 4th request per 11:11x4 rule)."""
        self._persona_idx = (self._persona_idx + 1) % 4

    # ── §4: Proxy management ───────────────────────────────────────────────────
    def _current_proxy(self) -> Optional[dict]:
        if not self._proxy_pool:
            return None
        proxy_url = self._proxy_pool[self._proxy_idx % len(self._proxy_pool)]
        return {"http": proxy_url, "https": proxy_url}

    def _rotate_proxy(self, reason: str = "manual"):
        if not self._proxy_pool:
            return
        old_idx = self._proxy_idx
        self._proxy_idx = (self._proxy_idx + 1) % len(self._proxy_pool)
        self._ip_hit_window = []  # Reset window after rotation
        print(f"  [VS11:PROXY] Rotating proxy {old_idx} → {self._proxy_idx} (reason: {reason})")

    def _check_ip_window(self):
        """Rotate proxy if 11+ hits from this IP in last 4 minutes."""
        now = time.time()
        window_start = now - 240  # 4 minutes
        self._ip_hit_window = [t for t in self._ip_hit_window if t > window_start]
        self._ip_hit_window.append(now)
        if len(self._ip_hit_window) > 11:
            self._rotate_proxy(reason="ip_window_11_in_4min")

    # ── §1: Human jitter ──────────────────────────────────────────────────────
    def jitter(self):
        """
        §1 — Non-linear scraping cadence.
        Base: random.uniform(1.1, 4.4) between every request.
        Full stop: 11 seconds after every 11th successful scrape.
        """
        self.request_count += 1

        # Rotate persona every 4 requests (11:11x4 rule)
        if self.request_count % 4 == 0:
            self._rotate_persona()

        # Base jitter: 1.1–4.4s weighted toward human-natural timing
        weights = [0.35, 0.35, 0.20, 0.10]
        ranges  = [(1.1, 1.8), (1.8, 2.8), (2.8, 3.6), (3.6, 4.4)]
        chosen  = random.choices(ranges, weights=weights)[0]
        delay   = random.uniform(*chosen)
        time.sleep(delay)

        # Full stop every 11 requests — clears session tracking on target server
        if self.request_count % 11 == 0:
            print(f"  [VS11:11] Full stop at req {self.request_count} — sleeping 11s to clear session tracking")
            time.sleep(11.0)

    # ── §4: Fetch with full ghost pipe logic ──────────────────────────────────
    def fetch(self, url: str, retries: int = 3) -> Optional[object]:
        """
        GET url with:
        - Current persona headers + spoofed referrer
        - Active proxy
        - Jitter delay
        - 429 → immediate proxy rotation + retry
        - IP window check
        Returns response object or None on failure.
        """
        try:
            import requests as req_lib
        except ImportError:
            raise RuntimeError("requests library required: pip install requests")

        self._check_ip_window()

        for attempt in range(retries):
            headers = self.get_headers(url)
            proxy   = self._current_proxy()

            try:
                resp = req_lib.get(
                    url,
                    headers=headers,
                    proxies=proxy,
                    timeout=30,
                    allow_redirects=True
                )

                if resp.status_code == 429:
                    # Too Many Requests — rotate proxy immediately, then retry
                    print(f"  [VS11:429] Detected on attempt {attempt+1} — rotating proxy")
                    self._rotate_proxy(reason="429_too_many_requests")
                    time.sleep(random.uniform(3.0, 7.0))
                    continue

                if resp.status_code == 200:
                    self.jitter()
                    return resp

                print(f"  [VS11:WARN] Status {resp.status_code} on {url}")
                self.jitter()
                return resp

            except Exception as e:
                print(f"  [VS11:ERR] Request failed attempt {attempt+1}: {e}")
                time.sleep(random.uniform(2.0, 5.0))

        print(f"  [VS11:FAIL] All {retries} attempts failed for {url}")
        return None

    # ── §3: s_sig watermark + _vs provenance block ────────────────────────────
    def watermark(self, record: dict) -> dict:
        """
        §3 — Inject watermark before any DB write.

        s_sig: 11-char hash(parcel_id + timestamp)
               — if this data ever walks out of the vault, we know exactly
                 when it was pulled and by whom.

        _vs:   Full internal provenance block (NEVER exposed in public API).
               Mr. Results strips this before Supabase export.
        """
        parcel_id   = (
            record.get("parcel_id") or
            record.get("PIN") or
            record.get("id") or
            "UNKNOWN"
        )
        ingested_at = datetime.now(timezone.utc).isoformat()

        # s_sig: the public-facing watermark field (goes into DB record)
        s_sig_raw = f"{parcel_id}|{ingested_at}|{VS_CANARY}"
        s_sig     = hashlib.sha256(s_sig_raw.encode()).hexdigest()[:11]

        # Internal checksum (Supabase trigger validates this)
        cs_raw = f"{parcel_id}|{s_sig}|{VS_CANARY}|{self.bot_name}"
        cs     = hashlib.sha256(cs_raw.encode()).hexdigest()[:11]

        # Inject s_sig directly into the record (top-level — goes to DB)
        record["s_sig"] = s_sig

        # Full provenance block — internal only, stripped before export
        record["_vs"] = {
            "wm":          s_sig,
            "cs":          cs,
            "system":      VS_SYSTEM,
            "product":     VS_PRODUCT,
            "canary":      VS_CANARY,
            "pipeline":    VS_PIPELINE,
            "bot":         self.bot_name,
            "county":      self.county,
            "state":       self.state,
            "persona":     self._persona_idx,
            "ingested_at": ingested_at,
            "req_count":   self.request_count,
        }

        return record

    # ── Staging ───────────────────────────────────────────────────────────────
    def stage(self, record: dict):
        """Buffer a watermarked record. Flush with self.flush()."""
        self._staged.append(record)

    def flush(self, output_path: Optional[str] = None) -> list:
        """
        Return all staged records (watermarked).
        Optionally write to a JSON file for Mr. Results to pick up.
        """
        batch = self._staged.copy()
        self._staged = []

        if output_path:
            with open(output_path, "w") as f:
                json.dump({
                    "meta": {
                        "bot_name":      self.bot_name,
                        "county":        self.county,
                        "state":         self.state,
                        "session_start": self.session_start,
                        "record_count":  len(batch),
                        "vs_protocol":   "VaultSmith_11_11x4_GhostPipe",
                        "exported_at":   datetime.now(timezone.utc).isoformat(),
                    },
                    "records": batch
                }, f, indent=2, default=str)
            print(f"[VS11] Flushed {len(batch)} records → {output_path}")

        return batch

    # ── Status ────────────────────────────────────────────────────────────────
    def status(self) -> dict:
        return {
            "bot_name":      self.bot_name,
            "county":        self.county,
            "request_count": self.request_count,
            "persona":       self._persona_idx,
            "proxy_idx":     self._proxy_idx,
            "proxy_pool_sz": len(self._proxy_pool),
            "staged":        len(self._staged),
            "ip_hits_4min":  len(self._ip_hit_window),
        }


# ── Standalone watermark utility ──────────────────────────────────────────────
def vs_watermark(record: dict, bot_name: str, county: str) -> dict:
    """One-off watermark without a full scraper instance."""
    s = VaultSmithScraper(bot_name=bot_name, county=county)
    return s.watermark(record)


# ── Self-test ─────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("VaultSmith 11:11x4 — GhostPipe self-test")
    print("=" * 50)

    scraper = VaultSmithScraper(bot_name="liaa_connector", county="Mason")

    for i in range(13):
        record = {
            "parcel_id": f"051-200-071-{i:02d}",
            "address":   "612 N James St, Ludington MI",
            "acreage":   1.2,
        }
        watermarked = scraper.watermark(record)
        scraper.stage(watermarked)

        # Simulate jitter (without actual sleep in test)
        scraper.request_count += 1
        if scraper.request_count % 4 == 0:
            scraper._rotate_persona()

        if i < 3 or i == 10 or i == 11:
            h = watermarked.get("get_headers", scraper.get_headers())
            print(f"  req {i+1:02d} | s_sig={watermarked['s_sig']} | persona={scraper._persona_idx} | ua={PERSONAS[scraper._persona_idx]['User-Agent'][:45]}...")

    batch = scraper.flush()
    print(f"\nFlushed {len(batch)} records")
    print(f"Status: {scraper.status()}")
    print(f"\nSample _vs block:")
    print(json.dumps(batch[0]["_vs"], indent=2))
