#!/usr/bin/env python3
"""
Michigan Parcel Polygon Pull — Nvirogear GIS Bot (Jet)
=======================================================
Pulls polygon geometry for Michigan parcels from two sources:
1. Michigan DNR state layer (gis-michigan.opendata.arcgis.com)
2. County-level ArcGIS REST endpoints (Berrien, Lapeer, Mason, Kent, etc.)

Usage:
  python3 michigan_parcel_polygon_pull.py --county berrien --parid 5857
  python3 michigan_parcel_polygon_pull.py --county lapeer --parid 68881
  python3 michigan_parcel_polygon_pull.py --county all --output parcels_out.geojson
  python3 michigan_parcel_polygon_pull.py --egle-contamination --counties berrien,lapeer,mason

Returns GeoJSON to stdout or writes to --output file.
"""

import sys
import json
import argparse
import urllib.request
import urllib.parse

# ─── STATE DNR LAYER ────────────────────────────────────────────────────────
DNR_BASE = "https://services3.arcgis.com/Jdnp1TjADvSDxMAX/arcgis/rest/services/DNRLOTSParcelsOPENDATA/FeatureServer/0/query"

# ─── EGLE LAYERS ────────────────────────────────────────────────────────────
EGLE_PART201 = "https://gisagoegle.state.mi.us/arcgis/rest/services/EGLE/RRDOpenData/MapServer/0/query"
EGLE_BROWNFIELDS = "https://gisagoegle.state.mi.us/arcgis/rest/services/EGLE/RRDOpenData/MapServer/3/query"

# ─── COUNTY REST ENDPOINTS ──────────────────────────────────────────────────
# Format: county_slug -> (base_url, parcel_id_field, layer_index)
COUNTY_ENDPOINTS = {
    "kent": (
        "https://gisservices.accesskent.com/arcgis/rest/services/Property/PropertyInformation/MapServer/0/query",
        "PIN", 0
    ),
    # Berrien, Lapeer, Oscoda, Allegan, Mason → use DNR state layer
    # These will fall back to DNR layer automatically
}

def fetch_url(url, params):
    """Simple HTTP GET with URL params."""
    query = urllib.parse.urlencode(params)
    full_url = f"{url}?{query}"
    try:
        with urllib.request.urlopen(full_url, timeout=30) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"error": str(e), "features": []}

def pull_dnr_by_county(county_name, parid=None, max_records=2000):
    """Pull DNR parcel polygons for a county, optionally filtered by ParID."""
    county_cap = county_name.capitalize()
    where = f"County = '{county_cap}'"
    if parid:
        where += f" AND ParID = {parid}"
    
    params = {
        "where": where,
        "outFields": "ParID,County,LegalDescription,ParcelTypeCode,ParcelType,ParcelStatus,Acreage",
        "returnGeometry": "true",
        "outSR": "4326",
        "f": "geojson",
        "resultRecordCount": max_records,
    }
    return fetch_url(DNR_BASE, params)

def pull_egle_contamination(counties, max_records=500):
    """Pull EGLE Part 201 contamination sites for given counties."""
    county_list = ",".join(f"'{c.capitalize()}'" for c in counties)
    params = {
        "where": f"County IN ({county_list})",
        "outFields": "SiteName,Address,City,County,Latitude,Longitude",
        "returnGeometry": "true",
        "outSR": "4326",
        "f": "geojson",
        "resultRecordCount": max_records,
    }
    return fetch_url(EGLE_PART201, params)

def pull_egle_brownfields(counties, max_records=500):
    """Pull EGLE Brownfield sites for given counties."""
    county_list = ",".join(f"'{c.upper()}'" for c in counties)
    params = {
        "where": f"COUNTY_NAME IN ({county_list})",
        "outFields": "*",
        "returnGeometry": "true",
        "outSR": "4326",
        "f": "geojson",
        "resultRecordCount": max_records,
    }
    return fetch_url(EGLE_BROWNFIELDS, params)

def pull_county_parcel(county, parcel_id):
    """Pull individual parcel from county REST endpoint (fallback: DNR)."""
    county_lower = county.lower()
    
    # Check if we have a direct county endpoint
    if county_lower in COUNTY_ENDPOINTS:
        base_url, id_field, _ = COUNTY_ENDPOINTS[county_lower]
        params = {
            "where": f"{id_field} = '{parcel_id}'",
            "outFields": "*",
            "returnGeometry": "true",
            "outSR": "4326",
            "f": "geojson",
        }
        result = fetch_url(base_url, params)
        if result.get("features"):
            return result
    
    # Fallback: DNR state layer by ParID
    print(f"[INFO] No direct county endpoint for {county}, trying DNR layer...", file=sys.stderr)
    return pull_dnr_by_county(county, parid=parcel_id)

def geojson_summary(geojson):
    """Print a quick summary of a GeoJSON feature collection."""
    features = geojson.get("features", [])
    with_geom = sum(1 for f in features if f.get("geometry") and f["geometry"].get("coordinates"))
    print(f"  Features: {len(features)} | With geometry: {with_geom}", file=sys.stderr)
    for feat in features[:3]:
        props = feat.get("properties", {})
        geom = feat.get("geometry", {})
        coords = geom.get("coordinates", [[]])
        ring = coords[0] if coords else []
        pt_count = len(ring) if isinstance(ring, list) else 0
        print(f"    → ParID:{props.get('ParID','?')} | {props.get('Acreage','?')}ac | pts:{pt_count} | first:{ring[0] if ring else 'none'}", file=sys.stderr)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Michigan Parcel Polygon Pull")
    parser.add_argument("--county", help="County name (berrien, lapeer, etc.) or 'all'")
    parser.add_argument("--parid", help="Specific ParID to pull")
    parser.add_argument("--egle-contamination", action="store_true", help="Pull EGLE contamination sites")
    parser.add_argument("--egle-brownfields", action="store_true", help="Pull EGLE brownfield sites")
    parser.add_argument("--counties", help="Comma-separated county list for EGLE pulls")
    parser.add_argument("--output", help="Output file path (default: stdout)")
    parser.add_argument("--max-records", type=int, default=1000, help="Max records per query")
    args = parser.parse_args()

    result = None

    if args.egle_contamination:
        counties = args.counties.split(",") if args.counties else ["Berrien","Lapeer","Oscoda","Allegan","Mason","Muskegon","Monroe","Jackson"]
        print(f"[INFO] Pulling EGLE Part 201 contamination for: {counties}", file=sys.stderr)
        result = pull_egle_contamination(counties, args.max_records)
        geojson_summary(result)

    elif args.egle_brownfields:
        counties = args.counties.split(",") if args.counties else ["Berrien","Lapeer","Oscoda","Allegan","Mason","Muskegon"]
        print(f"[INFO] Pulling EGLE Brownfields for: {counties}", file=sys.stderr)
        result = pull_egle_brownfields(counties, args.max_records)
        geojson_summary(result)

    elif args.county:
        if args.county.lower() == "all":
            # Pull all active auction counties
            all_features = []
            for county in ["Berrien","Lapeer","Oscoda","Allegan","Mason"]:
                print(f"[INFO] Pulling {county}...", file=sys.stderr)
                data = pull_dnr_by_county(county, max_records=args.max_records)
                features = data.get("features", [])
                # Tag with county
                for f in features:
                    f["properties"]["source_county"] = county
                    f["properties"]["source"] = "MI_DNR_State_Layer"
                all_features.extend(features)
                print(f"  {county}: {len(features)} polygons", file=sys.stderr)
            result = {"type": "FeatureCollection", "features": all_features}
            print(f"[INFO] Total: {len(all_features)} polygons", file=sys.stderr)
        else:
            print(f"[INFO] Pulling {args.county} (parid={args.parid})...", file=sys.stderr)
            if args.parid:
                result = pull_county_parcel(args.county, args.parid)
            else:
                result = pull_dnr_by_county(args.county, max_records=args.max_records)
            geojson_summary(result)
    else:
        parser.print_help()
        sys.exit(1)

    if result:
        output_str = json.dumps(result, indent=2)
        if args.output:
            with open(args.output, "w") as f:
                f.write(output_str)
            print(f"[INFO] Written to {args.output}", file=sys.stderr)
        else:
            print(output_str)
