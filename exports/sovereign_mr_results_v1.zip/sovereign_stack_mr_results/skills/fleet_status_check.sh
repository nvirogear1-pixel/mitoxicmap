#!/bin/bash
# Fleet Status Check — Mr. Results Startup Self-Test
# Runs at session start to verify all bot endpoints are live
# Version: 1.0 | Date: 2026-05-18

echo "================================================"
echo "  MR. RESULTS — FLEET STATUS CHECK"
echo "  $(date '+%Y-%m-%d %H:%M ET')"
echo "================================================"
echo ""

PASS=0
WARN=0
FAIL=0

check_bot() {
  local NAME="$1"
  local URL="$2"
  local PAYLOAD="$3"
  local EXPECTED="$4"

  RESPONSE=$(curl -s -o /tmp/fleet_check_response.txt -w "%{http_code}" \
    -X POST "$URL" \
    -H "Content-Type: application/json" \
    -d "$PAYLOAD" \
    --max-time 10)

  BODY=$(cat /tmp/fleet_check_response.txt | head -c 200)

  if echo "$BODY" | grep -q "$EXPECTED"; then
    echo "✅ $NAME — LIVE (HTTP $RESPONSE)"
    PASS=$((PASS + 1))
  elif [ "$RESPONSE" = "200" ] || [ "$RESPONSE" = "201" ] || [ "$RESPONSE" = "422" ]; then
    echo "⚠️  $NAME — RESPONDING but unexpected body (HTTP $RESPONSE)"
    echo "   Body: $BODY"
    WARN=$((WARN + 1))
  else
    echo "❌ $NAME — DEAD or BLOCKED (HTTP $RESPONSE)"
    echo "   Body: $BODY"
    FAIL=$((FAIL + 1))
  fi
}

echo "--- LIVE BOT PINGS ---"
echo ""

# Jet / GIS Bot
check_bot \
  "Jet (GIS Bot)" \
  "https://badass-real-estate-grabber-0c18c5f1.base44.app/functions/receiveTaskFromMrResults" \
  '{"task_id":"STARTUP-CHECK","task_type":"status_report","from":"mr_results","caller_id":"69ca9ac1baa8ecdb8ae25c59"}' \
  "queued"

# Historian Bot
check_bot \
  "Historian Bot" \
  "https://super-history-bot-2d658b84.base44.app/functions/receiveTask" \
  '{"task_id":"STARTUP-CHECK","task_type":"env_check","from":"mr_results","caller_id":"69ca9ac1baa8ecdb8ae25c59","county":"TEST","state_code":"MI"}' \
  "accepted"

# Outreach Bot
check_bot \
  "Outreach Bot" \
  "https://outreach-bot-1129e0e7.base44.app/functions/receiveDispatch" \
  '{"task_id":"STARTUP-CHECK","dispatch_type":"get_log_status","caller_id":"69ca9ac1baa8ecdb8ae25c59","from":"mr_results"}' \
  ""

# Mr. Results pipelineIngest (self-check)
check_bot \
  "Mr. Results — pipelineIngest (self)" \
  "https://mr-results-8ae25c59.base44.app/functions/pipelineIngest" \
  '{"action":"status_check","from":"self"}' \
  ""

# Super Report Bot (expect auth wall but confirm functions exist)
RESPONSE=$(curl -s -o /tmp/srb_check.txt -w "%{http_code}" \
  -X POST "https://super-report-bot-2225eadc.base44.app/functions/orchestrateOutreach" \
  -H "Content-Type: application/json" \
  -d '{"ping":true}' --max-time 10)
BODY=$(cat /tmp/srb_check.txt | head -c 150)
if echo "$BODY" | grep -q "private"; then
  echo "🔒 Super Report Bot — DEPLOYED but PRIVATE (needs app set to Public)"
  WARN=$((WARN + 1))
elif [ "$RESPONSE" = "200" ] || [ "$RESPONSE" = "201" ]; then
  echo "✅ Super Report Bot — LIVE (HTTP $RESPONSE)"
  PASS=$((PASS + 1))
else
  echo "❌ Super Report Bot — UNREACHABLE (HTTP $RESPONSE)"
  FAIL=$((FAIL + 1))
fi

# Site Tracker (expect 404 until deployed)
RESPONSE=$(curl -s -o /tmp/st_check.txt -w "%{http_code}" \
  -X POST "https://badass-site-tracker-5786d5f6.base44.app/functions/receiveTask" \
  -H "Content-Type: application/json" \
  -d '{"ping":true}' --max-time 10)
if [ "$RESPONSE" = "200" ] || [ "$RESPONSE" = "201" ] || [ "$RESPONSE" = "422" ]; then
  echo "✅ Site Tracker — LIVE (HTTP $RESPONSE) — NEWLY DEPLOYED!"
  PASS=$((PASS + 1))
else
  echo "🚧 Site Tracker — NOT YET DEPLOYED (HTTP $RESPONSE) — Deploy receiveTask function"
  WARN=$((WARN + 1))
fi

echo ""
echo "================================================"
echo "  SUMMARY: ✅ $PASS LIVE | ⚠️  $WARN WARN | ❌ $FAIL DEAD"
echo "================================================"
echo ""

if [ $FAIL -gt 0 ]; then
  echo "ACTION REQUIRED: $FAIL bot(s) are completely unreachable."
  echo "Check .agents/rules/bot_handshake_protocol.md for fix instructions."
  echo ""
fi

if [ $WARN -gt 0 ]; then
  echo "OWNER ACTION NEEDED on $WARN item(s) — see details above."
  echo ""
fi

if [ $FAIL -eq 0 ] && [ $WARN -eq 0 ]; then
  echo "🟢 ALL SYSTEMS GO — Fleet fully operational."
  echo ""
fi
