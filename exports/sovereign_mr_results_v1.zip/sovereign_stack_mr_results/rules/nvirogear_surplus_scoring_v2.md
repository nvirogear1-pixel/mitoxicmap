# Nvirogear Surplus Lot Scoring & Deep-Dive Engine — v2.0
# Date: 2026-05-20 | Status: LOCKED DOCTRINE
# Authored by: Joe Joe (owner) | Enforced by: Mr. Results

---

## The Problem with v1.0 (DEPRECATED — DO NOT USE)

The old signal system rewarded cheapness, not investability.
A $1,000 lot with $1,200/year HOA scored "HIGH VALUE" because bid < 15% of SEV.
That is financially dangerous. That system is dead.

---

## Investability Tier System (MANDATORY)

| Tier | Label | Color | Definition |
|---|---|---|---|
| A | Quick Flip — Adjacent Owner Play | #3ddc84 (green) | Road access + regular shape + no/minimal HOA + adjacent developed parcels. Hold 30–90 days. Sell to neighbor. |
| B | Land Bank — Zero Carry | #2dd4bf (teal) | No HOA + taxes <$50/yr + no title clouds. Hold 2–5 years. Bet on regional growth. |
| C | Land Bank — High Carry / Speculative | #f5a623 (amber) | HOA present OR taxes >$100/yr. Stalled subdivision but plausible future. Hold 5–10 yrs. Negative cash flow during hold. |
| D | Toxic — Avoid | #ff5c5c (red) | No road access + no utility proximity + irregular/unbuildable + legal encumbrances + HOA > 10% of purchase price/yr. |
| F | Data Insufficient | #5a6080 (gray) | Missing GIS boundary, no assessor buildability flag, or access unverifiable. Manual review required. |

---

## Investability Score Formula

```
INVESTABILITY_SCORE = (
  (ROAD_ACCESS ? 25 : 0) +
  (UTILITY_PROXIMITY < 0.25mi ? 20 : 0) +
  (NO_HOA ? 20 : HOA_FEE < 50 ? 10 : 0) +
  (ADJACENT_DEVELOPED_PARCELS > 0 ? 15 : 0) +
  (LOT_SHAPE_REGULAR ? 10 : 0) +
  (TAX_BURDEN_ANNUAL < 100 ? 10 : 0)
)
// Max 100

Tier Assignment:
90–100 = A
70–89  = B
50–69  = C
30–49  = D
0–29   = F
```

### Field Defaults (when data is unavailable)

| Field | Default | Impact |
|---|---|---|
| ROAD_ACCESS | false (0 pts) | Assume worst until GIS confirms |
| UTILITY_PROXIMITY | unknown → 0 pts | Cannot assume proximity |
| HOA_FEE | UNKNOWN → 0 pts (but flag C) | Flag as VERIFY WITH HOA |
| ADJACENT_DEVELOPED | false | Assume no adjacency |
| LOT_SHAPE_REGULAR | false | Assume irregular |
| TAX_BURDEN_ANNUAL | unknown → 0 pts | Pull from assessor API |

**If 3 or more fields are unknown → auto-assign Tier F (Data Insufficient).**

---

## Header Stats (Honest — Replace Old Pill System)

OLD (banned):
```
4 EXTREME/NEAR-FREE
16 HIGH VALUE
```

NEW (required):
```
2 QUICK-FLIP CANDIDATES (Tier A)
3 ZERO-CARRY LAND BANKS (Tier B)
8 HIGH-CARRY SPECULATIVE (Tier C)
7 TOXIC / AVOID (Tier D)
0 INSUFFICIENT DATA (Tier F)
```

---

## Deep-Dive Sections (Per Lot)

### Section A: Buildability Audit
| Field | Source | Display |
|---|---|---|
| Road access type | County GIS | Paved / Gravel / Undeveloped / None |
| Utility proximity | GIS overlay | Distance in feet; On lot / Adjacent / Subdivision / None |
| Zoning | County planning | Residential / Agricultural / Commercial / Restricted |
| Buildable area est. | GIS shape analysis | Sq ft; flag if < 5,000 sqft |
| Flood zone | FEMA layer | Yes/No + zone code |
| Wetland indicator | NWI / state layer | Yes/No + acreage |

### Section B: Carry Cost Calculator (Interactive)
User inputs hold period. System outputs:
- Annual taxes (assessor API)
- Annual HOA (registry or "UNKNOWN — VERIFY")
- Special assessment risk flag
- Total carry cost over hold period
- Break-even sale price at exit

Example (Lighthouse Village $1,000 lot):
```
Purchase:        $1,000
Fees:            $50
Annual HOA:      $1,200 [VERIFY WITH HOA]
Annual Taxes:    $60
Hold 5 years:    $6,300 carry
Total invested:  $7,350
Break-even sale: $8,500 (0% discount rate)
```

### Section C: Neighbor Consolidation Map
- Satellite thumbnail with parcel boundary overlay
- Adjacent parcel list: owner name, mailing address, occupancy flag
- "Draft Offer" generator: 1-page letter to adjacent owner
  - Template: "I own the vacant lot adjacent to your property at [ADDRESS]. Would you be interested in expanding your yard? Asking $[PRICE]."

### Section D: Title & Legal Flags
- Foreclosure order date + redemption status
- Known liens (IRS, mechanics, utility)
- Easement records
- HOA covenant summary

---

## Portfolio View Filter (UI Toggle)

| Mode | Filter |
|---|---|
| Conservative | Show Tier A + B only |
| Speculative | Show all tiers, sort by score descending |
| Land Banker | Tier B only, sort by lowest tax burden |

---

## Mandatory User Warning (Modal on Report Open)

Title: "SURPLUS LOTS FAILED AT AUCTION FOR A REASON"

Body:
> These lots are available because buyers with cash, local knowledge, and no time pressure passed on them. Before you buy:
> 1. Verify road access physically or via GIS — not just Google Street View
> 2. Call the HOA: "What are annual fees for vacant lot [ID]?"
> 3. Call the township assessor: "Is this lot buildable as-is?"
> 4. Budget 2× the purchase price for first-year carrying costs
>
> Nvirogear scores investability. We do not guarantee profitability.

---

## Data Source Build Order

| Data | Status | Source |
|---|---|---|
| Parcel boundaries | ❌ Needed | County GIS REST endpoint |
| Adjacent parcel IDs | ❌ Needed | GIS spatial query |
| Owner of record | ❌ Needed | Assessor bulk data |
| HOA registry | ❌ Needed | Manual build + user submission |
| Utility proximity | ❌ Needed | Municipal GIS layers |
| Zoning | ❌ Needed | County planning dept |
| FEMA flood | ❌ Needed | FEMA MSC API |
| Wetlands/NWI | ❌ Needed | USGS NWI layer |
| Satellite imagery | External link → embed | Google Maps Static API |

---

## Phase Build Order

Phase 1 — Backend: `calculate_investability_score()` + TierAssignment enum + HOA_FEE field + UTILITY_PROXIMITY field + AdjacentParcel relation
Phase 2 — Data Pipeline: County GIS integration + HOA registry build + FEMA overlay + NWI flag
Phase 3 — Frontend: Collapsible rows + Deep Dive component + Draft Offer generator + tier header pills + Portfolio View toggle
Phase 4 — Validation: Back-test 50 known lots + A/B test old signal vs. new tier with 10 investors

---

## The Core Mission

The current product is a data pipe with a broken signal.
The goal is a decision engine with honest risk pricing.
The $150K+ valuation depends on proving we can save investors from bad deals — not just surface cheap dirt.
The deep-dive layer is the moat.

*Nvirogear Surplus Scoring v2.0 — Locked by Mr. Results (Overseer) — 2026-05-20*
