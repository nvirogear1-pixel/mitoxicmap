# VIOLET DEMO ARCHITECTURE — TECHNICAL SPINE
## Nvirogear Land Intelligence Platform — Phase 1
### Date: May 18, 2026 | Mr. Results (Overseer)

---

## MISSION

Prove the complete workflow end-to-end for ONE parcel:

```
Search parcel
→ Detail page opens
→ Map renders boundary
→ GIS layers load
→ Report loads
→ Click claim
→ Map zooms to feature
→ Source ledger shows
→ Confidence badge visible
→ Gate status shown
→ Export works
```

**Success means:** Every claim is clickable to map evidence and source proof.

---

## PARCEL IDENTITY

| Field | Value |
|-------|-------|
| Address | 3101 Violet Ave, Muskegon Heights, MI 49444 |
| Parcel ID (canonical) | 61-10-840-000-0027-00 |
| County | Muskegon |
| State | MI |
| Centroid | 43.22498, -86.16679 |
| Geometry | Verified polygon (Muskegon County GIS) |
| Status | PROBABLE geometry confidence |

---

## TECH STACK (PHASE 1)

| Layer | Choice | Reason |
|-------|--------|--------|
| **Map Engine** | Leaflet.js | Fast, lightweight, Geojson-native, proven for demo |
| **Vector Data** | GeoJSON | Works with Leaflet, PostGIS-compatible |
| **Backend** | Base44 Backend Entities + Supabase (optional PostGIS) | Already integrated, auth built, RLS ready |
| **Auth** | Supabase Auth (email/password) | Simple roles: Admin, Reviewer, Client, Viewer |
| **Report Rendering** | HTML/CSS + JavaScript | Client-side, no external PDF needed yet |
| **Data Query** | Base44 Entity API + direct SQL (if Supabase) | Already built, no new dependencies |
| **Interactive Behavior** | Vanilla JS (no React yet) | Faster to iterate, smaller bundle for demo |

**Do NOT use yet:** MapLibre, vector tiles, complex enterprise GIS, heavy frontend frameworks.

---

## DATABASE SCHEMA (PRODUCTION READY)

### Core Tables — LIVE NOW

**GisLayer** (19 records seeded)
```
id, layer_name, category, source_name, authority_level, visibility, confidence_badge,
geometry_type, date_ingested, last_checked, notes
```

**ParcelLayerMatch** (5 records seeded)
```
id, parcel_id, layer_id, intersects, distance_to_feature_m, distance_method,
relation_type, confidence_badge, visibility, recommended_action, last_checked
```

**ReportFlag** (6 records seeded)
```
id, parcel_id, flag_type, severity, confidence_badge, source_layer_id,
recommended_action, visibility, gate_blocking, resolved, created_at
```

**SourceLedgerEntry** (7 records seeded)
```
id, claim_id, parcel_id, source_name, source_type, source_url, date_accessed,
confidence_badge, limitation_text, reviewer_status, visibility, notes
```

**ParcelRecord** (1 record — Violet Ave)
```
id, parcel_id, address, county, state, acreage, centroid_lat, centroid_lng,
geometry, geometry_type, geometry_confidence, source_name, source_url,
gis_lat, gis_lng, gis_polygon, gis_confidence,
env_flags, env_contamination, env_notes, env_flood,
trust_score, confidence_score, actionability_score,
opportunity_status, top_risk_level, export_ready, last_verified_at
```

### New Tables — BUILD PHASE 1

**report_claims** (generated from verified flags + source ledger)
```
id, report_id, parcel_id, claim_text, claim_type, section_name,
confidence_badge, source_ledger_id, map_reference_id, visibility,
review_status, created_at
```

**map_references** (links claims to map interactions)
```
id, parcel_id, layer_id, feature_id, map_action (zoom_to|highlight|toggle_layer),
zoom_level, latitude, longitude, label, visibility
```

**gate_checks** (per-parcel checklist items)
```
id, parcel_id, check_code, check_label, status (PASS|INVESTIGATION_REQUIRED|BLOCKER),
severity, required_action, reviewer_id, reviewed_at, evidence_url, notes
```

**review_events** (audit trail of human decisions)
```
id, parcel_id, user_id, event_type, previous_status, new_status, reason,
evidence_reference, created_at
```

---

## 9-SCREEN DEMO FLOW

### Screen 1: Login
- Email/password form
- 4 roles: Admin (full access) | Reviewer (view + decide) | Client (view only) | Viewer (read-only)
- Session stored in localStorage
- Redirect to Dashboard if authenticated

### Screen 2: Dashboard
- Welcome block
- Recent parcels list (search + shortcut to Violet)
- Unresolved blockers summary
- Export queue
- User role badge

### Screen 3: Parcel Search
- Search by address OR parcel ID
- Autocomplete for known parcels
- Results show: parcel_id, address, county, gate_status
- Click to Parcel Detail

### Screen 4: Parcel Detail Page
**Tabs:**

**Overview Tab**
| Field | Value | Badge |
|-------|-------|-------|
| Address | 3101 Violet Ave | VERIFIED |
| Owner | [Pending Treasurer] | BLOCKER |
| Parcel ID | 61-10-840-000-0027-00 | VERIFIED |
| Geometry | Polygon confirmed | PROBABLE |
| Tax/SEV | $178,500 / $165,000 | INVESTIGATION REQUIRED |
| Water Source | Municipal — Lake Michigan | VERIFIED |
| Superfund Proximity | 0.42 miles to Thomas Solvent EPA site | INVESTIGATION REQUIRED |
| PFAS AOI | 1.8 miles to airport PFAS plume | PROBABLE |
| Gate Status | NOT CLEARED FOR CAPITAL ACTION | BLOCKER |

**Tabs:**
- Overview (shown above)
- GIS Layers (list of matched layers with checkboxes)
- Report History (prior reports, versions)
- Source Ledger (all sources cited)
- Review Log (human decisions, timestamps)

**Action buttons:**
- [Open Interactive Map] → Screen 5
- [Open Report] → Screen 6
- [Open Gate Review] → Screen 8
- [Admin View] (admin role only) → internal fields
- [Export] → Screen 9

### Screen 5: GIS Evidence Map
**Leaflet map, full screen**

**Left Panel — Layer Toggle**
```
ENVIRONMENTAL
  ☑ Parcel Boundary         (PUBLIC_SAFE)
  ☑ EPA Superfund Sites     (PUBLIC_SAFE)
  ☑ PFAS Area of Interest   (PUBLIC_SAFE)
  ☐ Bedrock Geology         (PUBLIC_SAFE)
  ☐ Wetlands / Flood        (PUBLIC_SAFE)

MUNICIPAL
  ☐ Township Ordinances     (CLIENT_REPORT)
  ☐ Water Source Zones      (CLIENT_REPORT)
  ☐ Public Land / DNR       (CLIENT_REPORT)

INTERNAL (ADMIN ONLY)
  🔒 Hydrogen Prospect      (INTERNAL_ONLY)
  🔒 Activity Heatmap       (INTERNAL_ONLY)
```

**Map Features (Violet parcel)**
- Parcel polygon (blue outline, semi-transparent fill)
- Thomas Solvent pin (red, EPA CERCLIS) — 43.211944, -86.141667 — 0.42 mi
- Airport PFAS pin (orange, FAA) — 43.1695, -86.2382 — 1.8 mi
- Distance scale
- Zoom/pan controls

**Right Panel — Feature Details (on click)**
```
[Feature Name]
Confidence: [PROBABLE]
Source: [EPA CERCLIS]
Last Checked: May 18, 2026
Distance: 0.42 miles

Source Ledger Entry:
  URL: https://epa.gov/cerclis/[id]
  Type: Official Federal Registry
  Limitation: Superfund proximity does not establish exposure pathway

[View Full Source Ledger] [Why This Flag?] [Close]
```

**Behavior:**
- Click layer toggle → layer appears/disappears on map
- Click map pin → feature details panel opens on right
- Click feature details → Source Ledger table opens (Screen 7)
- Click "View on Map" from report (Screen 6) → map zooms to this feature

### Screen 6: Report Viewer
**Portfolio Pre-Diligence Risk Screen v1.2 (simplified for demo)**

**Header**
```
PORTFOLIO PRE-DILIGENCE RISK SCREEN
3101 Violet Ave, Muskegon Heights, MI 49444
Gate Status: NOT CLEARED FOR CAPITAL ACTION
Generated: May 18, 2026 | v1.2
```

**Sections (17 total, simplified to 6 for demo)**

**01 — PARCEL IDENTIFICATION**
```
Address:        3101 Violet Ave, Muskegon Heights, MI 49444
Parcel ID:      61-10-840-000-0027-00
County:         Muskegon
Centroid:       43.22498, -86.16679
Geometry:       Verified polygon (PROBABLE confidence)

[View on Map] [Source Ledger]
```

**02 — OWNERSHIP & TAX STATUS**
```
❌ BLOCKER — Owner of record pending Treasurer pull
Current owner name not yet verified.
  Confidence: INVESTIGATION REQUIRED
  Source: [View Ledger]
  Action Required: Treasurer record pull, title review
  [Confirm Blocker] [Resolve] [Evidence Link]

Tax Assessment Details:
  Taxable Value: $165,000
  SEV (State Equalized Value): $178,500
  Delta: +8.3% (within normal range)
  Confidence: PROBABLE
  Source: [View Ledger]
```

**03 — WATER SOURCE & CCR STATUS**
```
✅ VERIFIED — Municipal water supply (Lake Michigan)
Parcel has access to City of Muskegon municipal water system
  Confidence: VERIFIED
  Source: City of Muskegon GIS
  Last Checked: May 18, 2026
  [View on Map] [Source Ledger]
```

**04 — ENVIRONMENTAL PROXIMITY**
```
⚠️  INVESTIGATION REQUIRED — Superfund proximity
EPA CERCLIS Site: Thomas Solvent, Inc. (former facility)
  Distance: 0.42 miles (southwest)
  Confidence: PROBABLE
  Source: EPA CERCLIS Registry
  Parcel-Level Exposure Pathway: Not established. Proximity alone does not confirm direct exposure.
  Next Action: Phase I ESA, site walkover, subsurface investigation if acquisition planned
  [View on Map] [Source Ledger] [Why Flagged?]

⚠️  PROBABLE — PFAS Area of Interest proximity
Michigan PFAS Mapping: State-level PFAS plume boundary
  Distance: 1.8 miles (northeast)
  Confidence: PROBABLE
  Source: EGLE PFAS Mapping
  Advisory: Area-of-interest screening only. Water source verification and well testing required before action.
  [View on Map] [Source Ledger]
```

**05 — GATE BLOCKERS**
```
BLOCKERS (must resolve before capital action):
  1. Owner verification pending
  2. Phase I ESA recommended for Superfund proximity

INVESTIGATION REQUIRED (resolve before public action):
  1. Tax/SEV anomaly investigation (low priority — within range)
  2. PFAS exposure pathway verification
  3. CCR/well/septic status confirmation

CLEARED (no further action):
  ✓ Parcel geometry confirmed
  ✓ Municipal water supply access
```

**06 — NEXT ACTIONS**
```
For Acquisition / Capital Action:
  1. [BLOCKER] Pull owner of record from Treasurer
  2. [BLOCKER] Verify title and legal status
  3. Commission Phase I ESA (Superfund proximity)
  4. Verify PFAS exposure pathway (well test if applicable)
  5. CCR / utilities verification

Status: NOT CLEARED FOR CAPITAL ACTION until blockers resolved

[Export Report] [Print] [Close]
```

**Button behavior:**
- [View on Map] → zooms Screen 5 (GIS map) to feature
- [Source Ledger] → expands inline source ledger table
- [Why Flagged?] → shows confidence logic
- [Confirm/Resolve/Evidence] → opens review modal (Screen 8)
- [Export Report] → generates bundle (Screen 9)

### Screen 7: Source Ledger (Embedded + Expandable)

**In-line in Report (Screen 6)**
```
[Superfund Proximity Claim — click to expand]

Source Ledger:
┌─────────────────────────────────────────────────────────┐
│ Source         │ EPA CERCLIS (Federal Registry)         │
│ Type           │ Official Government Registry            │
│ URL            │ https://epa.gov/cerclis/[site-id]      │
│ Date Accessed  │ May 18, 2026 @ 14:00 ET                │
│ Confidence     │ PROBABLE (proximity only)               │
│ Limitation     │ Superfund proximity does not establish  │
│                │ parcel-level exposure pathway           │
│ Reviewer       │ Not yet reviewed by staff               │
│ Next Action    │ Phase I ESA recommended                 │
└─────────────────────────────────────────────────────────┘

[Close]
```

**Stand-alone Ledger Page (accessible from Parcel Detail)**
```
Full Source Ledger for 61-10-840-000-0027-00

Filters: [All] [VERIFIED] [PROBABLE] [INVESTIGATION_REQUIRED]

┌─────────────────────────────────────────────────────────┐
│ CLAIM          │ SOURCE │ DATE       │ CONFIDENCE │ REV  │
├─────────────────────────────────────────────────────────┤
│ Parcel boundary │ Muskegon County GIS │ 2026-05-18 │ PROB │ ✓   │
│ Geometry polygon │ Public Records │ 2026-05-18 │ PROB │ ✓   │
│ Owner (pending) │ Treasurer Office │ (pending) │ INV  │ -   │
│ Water supply   │ City Muskegon │ 2026-05-18 │ VERI │ ✓   │
│ Superfund prox │ EPA CERCLIS │ 2026-05-18 │ PROB │ -   │
│ PFAS proximity │ EGLE PFAS Map │ 2026-05-18 │ PROB │ -   │
│ Tax value      │ County Assessor │ 2026-05-18 │ PROB │ ✓   │
└─────────────────────────────────────────────────────────┘

Expand any row for full source details, URL, limitation text
```

### Screen 8: Review / Gate Status
**For Reviewer + Admin roles**

```
PARCEL: 3101 Violet Ave
Gate Status: NOT CLEARED FOR CAPITAL ACTION
Last Updated: May 18, 2026

UNRESOLVED ITEMS:

[1] BLOCKER — Owner of record
  Status: PENDING TREASURER PULL
  Assigned to: [Mr. Results]
  Action Options:
    [✓ Confirm Blocker]  [Resolve] [Downgrade to Advisory] [Escalate]
  Evidence / Notes:
    [Attach file or URL]
    [Reviewer notes textarea]
  [Save & Log Review]

[2] INVESTIGATION REQUIRED — Superfund proximity
  Status: PHASE I RECOMMENDED
  Action Options:
    [✓ Confirm Required]  [Resolve] [Escalate]
  Evidence:
    [ESA Report URL — optional]
  Notes: Site walkover completed, no visible soil damage observed
  [Save & Log Review]

[3] ADVISORY — PFAS AOI proximity
  Status: AWAITING WATER SOURCE VERIFICATION
  [Confirm] [Resolve] [Close Advisory]

RECALCULATE GATE:
  Gate will clear when:
    ☐ Owner verified
    ☐ Phase I ESA complete (or waived with evidence)
    ☐ PFAS exposure pathway verified (or documented as N/A)
  
  [Recalculate Gate Status]
```

**Behavior:**
- Each action stamps timestamp + user ID
- Resolving all BLOCKERs + INVESTIGATIONs → gate recalculates
- Review log (Screen 4, tab) shows all decisions

### Screen 9: Export Bundle

**Export Options**
```
SELECT EXPORT FORMAT:

☑ Full Report (HTML)        → nvirogear_3101_violet_full.html
☐ Full Report (PDF)         → nvirogear_3101_violet_full.pdf [LABEL: Beta]
☑ Source Ledger (CSV)       → nvirogear_3101_violet_sources.csv
☑ Risk Register (CSV)       → nvirogear_3101_violet_risks.csv
☐ GIS Evidence (GeoJSON)    → nvirogear_3101_violet_geojson.geojson
☐ Risk Record (JSON)        → nvirogear_3101_violet_record.json [ADMIN only]

VISIBILITY:
  Admin role:     [All options available]
  Reviewer role:  [Public + Client Report options only]
  Client role:    [Public + Client Report options only]
  Viewer role:    [Public options only]

STAMP:
  [✓] Include source ledger
  [✓] Include gate status
  [✓] Include review log (if reviewer role)
  [ ] Include internal notes (admin only)
  [ ] Include internal layers (admin only)

[Download Bundle] [Cancel]

After download:
"✅ Export complete: 3 files downloaded"
```

**Files Generated:**

**nvirogear_3101_violet_full.html** (CLIENT_REPORT visibility)
- Entire report as single-page HTML
- Embedded GeoJSON for map layer
- All claims with source ledger links
- Confidence badges visible
- Gate status shown
- Review log (if reviewer exported)
- No INTERNAL_ONLY content

**nvirogear_3101_violet_sources.csv** (CLIENT_REPORT visibility)
```
claim_id,source_name,source_type,source_url,date_accessed,confidence,reviewer_status,limitation
claim_001,Muskegon County GIS,Official,https://...,2026-05-18,PROBABLE,approved,Boundary confidence based on county records
claim_002,EPA CERCLIS,Federal,https://epa.gov/...,2026-05-18,PROBABLE,pending,Proximity only; no exposure pathway established
...
```

**nvirogear_3101_violet_risks.csv** (CLIENT_REPORT visibility)
```
flag_id,flag_type,severity,confidence,status,next_action
flag_001,BLOCKER,Owner verification,INVESTIGATION_REQUIRED,pending,Treasurer pull
flag_002,Superfund proximity,INVESTIGATION_REQUIRED,PROBABLE,open,Phase I ESA
flag_003,PFAS AOI,PROBABLE,PROBABLE,open,Water source verification
...
```

---

## DATA INTERACTIONS (CLAIM → MAP → SOURCE)

### Interaction Pattern 1: Report Claim Click

**User action:** Click "[View on Map]" button next to Superfund claim

**System behavior:**
1. Read `map_references` table for claim_id
2. Extract: layer_id, feature_id, zoom_level, lat/lng
3. Flip to Screen 5 (GIS map)
4. Animate zoom to coordinates
5. Highlight feature pin
6. Open right-panel with feature details
7. Show linked `SourceLedgerEntry` in panel

### Interaction Pattern 2: Map Feature Click

**User action:** Click Superfund pin on map

**System behavior:**
1. Detect layer_id + feature_id from pin
2. Query `ParcelLayerMatch` for distance, relation
3. Query `ReportFlag` for gate_blocking status
4. Query `SourceLedgerEntry` for source details
5. Display right-panel:
   - Feature name, distance, confidence
   - Full source ledger entry
   - Recommended action
   - "View Full Ledger" button

### Interaction Pattern 3: Source Ledger Expansion

**User action:** Click "[Source Ledger]" in claim or feature panel

**System behavior:**
1. Query all `SourceLedgerEntry` records for claim_id
2. Display table with all sources backing that claim
3. Show: source_name, type, date, confidence, limitation, reviewer_status
4. Allow filter by confidence level
5. Expandable rows → full source URL, artifact ref, reviewer notes

---

## CONFIDENCE BADGE SYSTEM

Every claim must display one of:

| Badge | Meaning | Color | When Used |
|-------|---------|-------|-----------|
| VERIFIED | Primary source confirmed, timestamp current | Green | Parcel geometry, water supply, recent ownership |
| PROBABLE | Secondary source or inferred, needs confirmation | Yellow | Proximity flags, tax estimates, historical data |
| INVESTIGATION REQUIRED | Conflicting records, unresolved anomaly, source mismatch | Orange | Owner pending, SEV delta, title flags |
| BLOCKER | Unresolved — prevents capital action | Red | Missing owner, critical title defect |
| UNKNOWN | No source found or not yet checked | Gray | Future layers, pending data |

**Rules:**
- Every claim shows one badge
- Confidence cannot exceed source authority
- Silence confidence upgrades are forbidden
- Badges are recalculated when source updates or review completes

---

## GATE STATUS RULES

**Gate can only be:**
1. NOT_SCREENED (default)
2. SCREENED (no blockers found)
3. INVESTIGATION_REQUIRED (soft blocker)
4. NOT_CLEARED_FOR_CAPITAL_ACTION (hard blocker present)
5. CLEARED_WITH_CONDITIONS (blockers resolved, conditions noted)
6. CLEARED (all blockers resolved, all sources confirmed)

**Gate calculation logic:**
```
IF any BLOCKER exists → NOT_CLEARED_FOR_CAPITAL_ACTION
ELSE IF any INVESTIGATION_REQUIRED exists → INVESTIGATION_REQUIRED
ELSE IF all claims VERIFIED → CLEARED
ELSE → CLEARED_WITH_CONDITIONS
```

**Gate blocks:**
- Capital action (acquisition, funding, lending)
- Public recommendation
- Export to external parties

**Gate does NOT block:**
- Internal review
- Data collection
- Source verification work

---

## LANGUAGE RULES (LOCKED)

Every claim must use approved language:

| Claim Type | Approved | Not Approved |
|---|---|---|
| Superfund proximity | "Confirmed source within screening radius. Parcel-level exposure pathway not established." | "Parcel is contaminated" |
| PFAS | "PFAS Area of Interest proximity advisory only. Exposure pathway must be verified." | "This parcel has PFAS" |
| Tax anomaly | "Possible SEV/assessment anomaly detected. Not a distress signal without verification." | "Property is distressed" |
| Health context | "Population-level community context included for resident safeguard planning." | "This area causes cancer" |
| Mineral/resource | "Mineral/resource layer present. Ownership, lease status, and rights require title/legal verification." | "Property has valuable minerals" |
| Ordinance | "Ordinance or land-use layer indicates possible restriction. Legal interpretation required." | "Parcel is zoned for..." (without legal review) |

---

## DEMO SUCCESS CRITERIA

Violet demo is ready for 3-parcel validation when ALL are true:

**Functional:**
- ✅ Search finds 3101 Violet Ave
- ✅ Parcel detail page loads all data
- ✅ Map renders boundary + 2+ pins
- ✅ Click claim → map zooms to feature
- ✅ Click pin → feature panel opens with ledger
- ✅ Report loads all 6 sections without error
- ✅ Gate status shows NOT CLEARED with reasons
- ✅ Export HTML works
- ✅ Export CSV works

**Data Quality:**
- ✅ All 7 source ledger entries have URLs
- ✅ All 6 flags have confidence badges
- ✅ No unsupported claims in report
- ✅ No agent names in client view
- ✅ No INTERNAL_ONLY content in exports

**Language:**
- ✅ No "contaminated" language
- ✅ No health causation claims
- ✅ No mineral hype
- ✅ All gate language approved
- ✅ All source limitations shown

---

## BUILD TIMELINE (PHASE 1)

| Week | Task | Status |
|------|------|--------|
| W1 | Architecture + schema (this doc) | In progress |
| W1 | Database tables created | Pending |
| W1 | Login screen + Dashboard | Pending |
| W1-W2 | Parcel Detail + GIS Map | Pending |
| W2 | Report Viewer + Source Ledger | Pending |
| W2 | Gate/Review workflow | Pending |
| W2 | Export (HTML, CSV) | Pending |
| W2-W3 | Testing + sign-off | Pending |
| W3 | 3-parcel validation begins | Pending |

---

## NEXT: BUILD SCREENS

Mr. Results will now build the 9-screen interactive demo as a single-page HTML application.

The app will:
- Load live data from Base44 entity API
- Render Leaflet map with GeoJSON
- Implement all interactive behaviors (click-to-map, ledger expansion)
- Generate export bundles
- Enforce visibility rules per role

This is the technical spine.
Everything else scales from here.

---

*Locked by Mr. Results — Nvirogear Land Intelligence Platform*
*May 18, 2026 — Overseer Authority*
