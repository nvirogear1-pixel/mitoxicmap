# FOREMAN ALLOWED ACTION CONTRACT
Status: LOCKED
Authority: Mr. Results (Overseer)

## PURPOSE
This rule defines the required structure and behavior of allowed and blocked action contracts returned to the UI.

## REQUIRED OUTPUT
For every governed scope, the backend must return:
- allowed_actions[]
- blocked_actions[]
- ruleset_version_hash

## ALLOWED ACTIONS
Each allowed action must declare:
- action
- label
- reason_allowed
- required_role
- destructive

## BLOCKED ACTIONS
Each blocked action must declare:
- action
- label
- reason_blocked
- blocking_rule
- blocking_blocker_ids
- override_possible
- required_role_if_override_exists

## ENFORCEMENT RULE
The same policy engine must:
1. generate action contracts
2. enforce action endpoints

The system is prohibited from using separate rule logic for display vs enforcement.

## ACTION ENUM DISCIPLINE
Canonical action names only:

- view_evidence
- open_parcel_record
- open_cluster_view
- request_historian_rerun
- request_source_audit
- mark_manual_review
- clear_manual_hold
- reopen_stage
- rerun_normalization
- rerun_premerge_gate
- run_cluster_comparison
- approve_parcel_type_update
- hold_export
- release_export
- create_exception
- view_exception_log

No bot or UI may invent alternate action names.
