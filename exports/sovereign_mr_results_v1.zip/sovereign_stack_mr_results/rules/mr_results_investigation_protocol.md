# MR. RESULTS INVESTIGATION PROTOCOL
# Project: MCL 211.34d Environmental Contamination Assessment
# Authority: Joe Smith, Nvirogear LLC
# Version: 1.0 — LOCKED July 5, 2026
# Status: GOVERNING — applies to all evidence collection, analysis, and reporting

---

## OPERATING PRINCIPLE

Every conclusion must have a documented basis.
No conclusions beyond documented evidence.
Every statement gets exactly one evidence label.
Any remaining uncertainty is explicitly labeled, not filled with assumptions.

---

## EVIDENCE LOCKER STRUCTURE

### Locker 001 — Statutory Authority
Collect:
- Michigan Constitution, Article IX, § 3
- MCL 211.27
- MCL 211.27a
- MCL 211.34d
- Cross-referenced environmental statutes
- Legislative history (if available)

For each document record:
- Source
- Date obtained
- Hash
- Version (PA number, effective date)
- Archive location

### Locker 002 — Government Guidance
Collect:
- Michigan Assessors Manual (all volumes)
- State Tax Commission Bulletins
- Treasury memoranda
- Equalization guidance
- Assessor training materials

Record for each:
- Publication date
- Page numbers
- Chapter
- Exact quotation
- Hash

### Locker 003 — Property Record
For every parcel:
- Parcel history
- Assessment history
- Ownership history
- EGLE sampling results
- Wellogic records
- Water testing results
- Restrictions
- Notices
- Environmental reports

Everything gets linked back to the parcel ID.

### Locker 004 — Timeline
Every event becomes one row.

Format:
| Date | Event | Source | Verified |
|------|-------|--------|----------|

No narrative. Only facts. Each row is independently verifiable.

### Locker 005 — Market Evidence
Store separately from legal evidence.
Never mix with Locker 001-004.

Include:
- Sales
- Appraisals
- Disclosures
- Assessor records
- Comparable properties

### Locker 006 — FOIA Ledger
One page for each request.

Track:
- Sent
- Received
- Acknowledged
- Extension
- Response
- Documents
- Appeal
- Closed

---

## EVIDENCE LABELS

Every statement gets exactly one label:

- 📄 Documented Fact — confirmed in a specific record
- 📚 Statutory Requirement — in statute or constitution
- 📑 Government Guidance — in official manual/bulletin
- 📈 Observed Market Evidence — from sales/appraisal data
- 🟨 Inference — reasoned from documented facts (must be marked as inference)
- ❓ Unknown — not yet researched
- 🚫 Not Yet Verified — claimed but not confirmed

---

## LANGUAGE STANDARD (LOCKED)

FORBIDDEN:
- "No assessor has ever used this."
- "The State Tax Commission never issued guidance."
- "Nobody has done this."
- "The statute has never been used."

REQUIRED REPLACEMENTS:
- "No published example has yet been identified."
- "No guidance has yet been identified during current research."
- "Awaiting agency responses."

General rule: describe what has been searched and what was found (or not found).
Do not extrapolate to conclusions about the history of the statute.

---

## INVESTIGATION TRIGGER

When FOIA responses arrive:
1. Compare against current evidence
2. Update ONLY the affected sections
3. If response produces new documents → they become 📄 Documented Facts
4. If response states no responsive records found → that becomes a documented result of that agency's search — NOT a broader conclusion about the history of the statute
5. Re-hash all updated files
6. Update manifest with new composite hash
7. Log the update in the FOIA tracking ledger (Locker 006)

---

## ARCHIVE DIRECTORY

All evidence lockers live in:
/app/evidence_lock/foia_background_record/

Manifest hash (v1.0): b7966af3b8945f2320118809ca143c6c84082478e8fdf8e5a95c4acffbb2b037

Evidence chain:
Manifest 001 → SPRINT_002 → VAULTSMITH_ANCHOR_001 → FOIA_BACKGROUND_RECORD_001

---

*Nvirogear LLC | Mr. Results Investigation Protocol v1.0*
*Locked July 5, 2026 | Authority: Joe Smith*
*Applies to: all evidence collection, analysis, and reporting for MCL 211.34d project*
