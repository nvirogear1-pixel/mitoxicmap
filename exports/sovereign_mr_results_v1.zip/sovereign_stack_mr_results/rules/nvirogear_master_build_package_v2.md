# NVIROGEAR MASTER BUILD PACKAGE v2.0
## Reference Summary — May 18, 2026

This is the final consolidated master directive for all Nvirogear development.

### 12 Core Sections
1. **Platform Architecture** — 8-area operational model, core rules, confidence badges
2. **Database Schema** — Live entities + build-next entities + internal-only tables
3. **GIS Evidence Map Spec** — Leaflet implementation, layer visibility, distance methods, interactive behavior
4. **Report Type Matrix** — 6 report types, audience, tone, language separation, scoring rules
5. **Source Ledger Specification** — Proof layer rules, 8-field standard, confidence enforcement
6. **Data Quality & Gate Logic** — Language rules locked, confidence rules, badge progression
7. **MVP Build Sequence** — Phase 1–6: Violet demo → 3-parcel → 25-parcel → client workspace → FutureMIS → statewide
8. **Violet Ave Demo Plan** — 5-minute walkthrough, search → report → claim click → source ledger → export
9. **3-Parcel Validation Plan** — Different contexts, GIS matching, gate logic, report types, metrics
10. **25-Parcel Pilot Plan** — Batch screening workflow, success criteria, cost-per-parcel baseline
11. **Do-Not-Expose List** — 13 items classified (trade secret, confidential, unverified, internal-only)
12. **MVP Readiness Checklist** — 30 items across data, reports, map, gate, export, language, demo flow

### Key Rules (Locked)
- No claim without source. No source without SourceLedgerEntry. No export without all 30 checklist items.
- Confidence cannot exceed source authority. Silence confidence upgrades are forbidden.
- Agent names are internal only. Client-facing identity: "Nvirogear Property Intelligence System."
- Health language: "population-level context for safeguard planning only" — never diagnostic.
- Environmental proximity: "exposure pathway not established" — never "contaminated."
- Bitcoin/provenance: internal-only, never mention publicly.
- Gate status progression: NOT_SCREENED → SCREENED → INVESTIGATION REQUIRED → NOT CLEARED → CLEARED
- Visibility enforcement: PUBLIC_SAFE always visible; INTERNAL_ONLY never visible to client role.

### Live Now
- 19 GisLayer records ✅
- 5 ParcelLayerMatch records ✅
- 6 ReportFlag records ✅
- 7 SourceLedgerEntry records ✅
- Portfolio Pre-Diligence Risk Screen v1.2 ✅

### Next Steps
1. Phase 1: Parcel Detail page + in-app Report Viewer (this week)
2. Phase 2: 3-parcel validation (next week)
3. Phase 3: 25-parcel pilot batch (weeks 3–4)

Full document: NVIROGEAR_MASTER_BUILD_PACKAGE.md (47K, 835 lines, locked authority)
