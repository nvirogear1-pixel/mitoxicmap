# NVIROGEAR BOT TEAM — ADAPTIVE ACQUISITION DOCTRINE v1
# Issued by: Joe Smith, Nvirogear LLC
# Date: 2026-07-10
# Status: ACTIVE — GOVERNING — applies to all county acquisition work

---

## PRIMARY RULE

Never allow one failed source to stop mission progress.

The objective is acquiring verified public data — not proving one URL works.

---

## ROADBLOCK PROTOCOL

If a source fails:
1. Record the failure
2. Classify the failure
3. Attempt alternate acquisition methods
4. Continue the mission

Do not loop endlessly against the same endpoint.

---

## SEARCH STRATEGY

When a URL or endpoint fails, automatically search for:
- Official county GIS
- Official county assessor
- ArcGIS REST services
- Open Data portals
- County parcel viewers
- Public tax lookup systems
- Download portals
- Alternative official APIs

If one path fails, move to the next.

---

## RETRY POLICY

Maximum retries per endpoint:

| Failure type | Action |
|---|---|
| Temporary timeout | Retry max 2 times, then classify and move on |
| Authentication failure | Log and move on immediately |
| 404 / dead host | Stop immediately, search for replacement |
| Service removed | Locate new official service |

Never spend hours hammering a dead endpoint.

---

## COUNTY COMPLETION RULE

A county is complete when one of the following is true:

✅ CANDIDATE_DATASET_READY — data acquired, dedup run, manifest generated
⚠️ BLOCKED — failure documented with reason, alternate sources exhausted

"Still trying" is not a valid long-term status.

---

## MISSION PRIORITY

Speed comes from momentum.

If County A is blocked → move immediately to County B.
If County B finishes → continue to County C.

Blocked counties go into a REVISIT QUEUE — not the active acquisition queue.

---

## CONTINUOUS LEARNING — SOURCE REGISTRY

Every acquisition attempt must update the Source Registry:

- Working endpoints → record URL, method, record count, last verified date
- Failed endpoints → record URL, failure type, date
- Replacement endpoints → link to original failed URL
- Preferred acquisition method per county

The next bot should NEVER rediscover the same dead link.

SourceRegistry and CountyRegistry entities are the living record.
Every run updates them. No exceptions.

---

## FAILURE CLASSIFICATION CODES

| Code | Meaning | Next Action |
|---|---|---|
| DNS_FAIL | Hostname does not resolve | Search ArcGIS Online, Hub, open data portal |
| HTTP_404 | Endpoint gone | Search for new official URL |
| HTTP_403 | Auth required / blocked | Log, seek public alternative |
| TIMEOUT | Server slow/overloaded | Retry 2x max, then log and move |
| LAYER_NOT_FOUND | ArcGIS service exists but layer index wrong | Try layer 0,1,2,3 — if none, log blocker |
| PAID_DATA | Data requires purchase | Log, mark BLOCKED, move on |
| NO_PUBLIC_SOURCE | Exhausted all search strategies | Mark BLOCKED with full attempt log |

---

## ACQUISITION METHOD PREFERENCE ORDER

Try in this order. Stop at first success.

1. Official county GIS ArcGIS FeatureServer (direct REST pull)
2. ArcGIS Online public hosted service (search by county name)
3. Open Data portal (Socrata, Hub, county data portal)
4. County assessor public parcel viewer (extract API endpoint from network traffic)
5. LIAA bulk parcel data (for counties with LIAA coverage)
6. Michigan statewide open data (MCGI, Michigan.gov datasets)
7. FOIA/data request (last resort — log and mark as long-lead)

---

## PHILOSOPHY

*Be loyal to the mission, not the method.*

A dead endpoint is not a failure. It is a signal to change course and keep moving.

Acquire. Validate. Advance.

Do not become attached to a specific website, endpoint, or scraping method.

The mission is to build Michigan's parcel foundation — not to prove any single data source works.

---

*Locked by Mr. Results (Overseer) — Nvirogear LLC — 2026-07-10*
*Michigan Parcel Completion Directive — Governing Doctrine*
