# Nvirogear Environmental-Tax Correlation Report Standard v1.1
# Authority: Mr. Results (Overseer) — Nvirogear LLC
# Locked: July 1, 2026 (v1.0) | Updated: July 1, 2026 (v1.1 — added Subsurface & Geologic Correlation)
# Status: MANDATORY — governs all reports correlating environmental contamination with tax assessment behavior

---

## PURPOSE

This report type documents where a property's environmental risk profile (contamination proximity,
confirmed release, PFAS/metals/VOC presence) may not be reflected in its current tax assessment,
and gives the owner a factually correct path to investigate and act — without overselling legal
certainty the law does not provide.

---

## THE CORRECT LEGAL FRAMEWORK (VERIFIED — DO NOT DEVIATE)

### Appeal Venue and Process (Michigan)
1. Optional Assessor's Review — February (local, informal, not required)
2. March Board of Review — REQUIRED first step before Tax Tribunal for ALL property classes
3. Michigan Tax Tribunal petition deadlines:
   - Residential / Agricultural property: **July 31** of the tax year involved
   - Commercial / Industrial / Developmental property: **May 31** of the tax year involved
4. There is no "court" in the general sense for property tax valuation disputes — the correct venue
   is the Michigan Tax Tribunal (an administrative body), reached only after the March Board of Review.
   NEVER say "take this to court" — say "petition the March Board of Review, then the Michigan Tax Tribunal."

### Substantive Law — Environmental Contamination Valuation Adjustment
- **Correct citation: MCL 211.34d** — defines "environmental contamination" as a category affecting
  the loss/addition formula used to adjust taxable value. The decrease in taxable value attributable
  to contamination equals the decrease in true cash value attributable to contamination, multiplied
  by a defined fraction.
- **MCL 211.27a is NOT the contamination relief statute** — it governs transfer of ownership and
  taxable value uncapping definitions. Do not cite it for contamination adjustment claims.
- Burden of proof is on the property owner: contamination must be documented, and its effect on
  true cash value must be demonstrated — typically via comparable sales of similarly affected
  properties, an environmental assessment, or a licensed appraisal addressing the contamination.

### Qualified Errors (MCL 211.53b) — narrow, do not oversell
- Qualified Error correction (via July or December Board of Review) fixes **clerical errors and
  mutual mistakes of fact** — not valuation judgment disputes.
- Environmental-contamination-based valuation disagreements are NOT qualified errors. They must go
  through the standard annual Board of Review → Tax Tribunal appeal process, filed on time, for
  each tax year in question.
- **There is no general statutory mechanism to reopen multiple past tax years retroactively because
  the state "knew" about contamination and the assessor didn't act.** This must be stated plainly.
  Overselling a "get your back taxes returned" narrative is a defensible-language violation and
  erodes credibility if challenged. Appeals must be timely filed for the CURRENT tax year;
  historical years are generally closed once the appeal window has passed, absent a qualified error.

### Language Rules for This Report Type (BANNED / REQUIRED)
- BANNED: "get your taxes back from years the state knew" / "you will win your appeal" /
  "guaranteed refund" / "sue the state" / "take this to court"
- REQUIRED: "may provide grounds to petition the March Board of Review" / "the current tax year is
  the year with a live appeal window" / "consult a Michigan property tax attorney to confirm your
  specific deadline and eligibility" / "this identifies a documented pattern — outcome is not guaranteed"

---

## REPORT STRUCTURE (14 sections — v1.1 adds S6.5 Subsurface & Geologic Correlation)

1. Executive Summary — property, contamination status, assessment status, appeal window status
2. Environmental Profile — full-field EGLE/EPA pulls (RiskCondition, Contaminants, ReleaseStatus —
   never just name/address/city). Full record pull is MANDATORY, not summary fields only.
3. Well Water & Water Supply Profile — testing options, real cost, real certified labs, what
   standard free testing does and does NOT cover (PFAS is NOT in Michigan's standard free well
   test package — must be ordered separately)
4. Tax & Assessment History — SEV/TV/tax bill by year, correct legal citations only
5. The Assessment-Environment Timeline — year-by-year overlay of contamination discovery/status
   changes vs. assessment changes (facts only, no speculation presented as fact)
6. Interactive Evidence Map — contamination sites, subject parcel (actual GIS polygon if available,
   not just a centroid point), buffer rings, tax overlay if multi-parcel
6.5. **Subsurface & Geologic Correlation (NEW — MANDATORY v1.1)** — see dedicated section below
7. Contradiction Engine — any claim vs. verified reality conflicts
8. Risk Register
9. The Appeal Pathway — correct venue, correct deadlines, correct statute, explicit disclosure of
   what is NOT guaranteed
10. Recommended Next Steps — testing labs with real pricing, attorney referral, appeal filing steps
11. Source Data, Testing Equipment & Lab Contacts — real clickable links: state GIS mappers, lab
    phone numbers, sample-bottle contacts, statute pages. Never leave this as prose only — link out.
12. Source Ledger — minimum 12 entries, full-field pulls cited explicitly
13. Report Limitations — explicit statement that this is not legal advice, not an appraisal, and
    does not guarantee any tax outcome

---

## SUBSURFACE & GEOLOGIC CORRELATION (NEW SECTION — MANDATORY v1.1)

Every report of this type must attempt to pull and correlate the following, in addition to the
standard contamination-site environmental profile:

1. **Oil, Gas & Mineral Wells** — EGLE GrmdOpenData FeatureServer, layer 10 (Surface Hole
   Locations). Query within at least a 3-mile radius. Report: well name, API number, well status
   (especially "Plugging Approved" vs. unplugged/orphaned), depth, permit date, and whether
   `LogsAvailable = YES`. Old, improperly plugged wells can act as cross-aquifer contamination
   conduits — this is a real risk factor, not decoration. If logs are available, note that they are
   public record and can be requested from EGLE OGMD directly (phone/email) — do NOT attempt to
   scrape them from the EGLE OGMD Data Explorer web app (see Technical Boundary note below).

2. **Surficial (Quaternary) Geology** — EGLE GrmdOpenData layer 8. Query the parcel's exact point.
   Report the glacial deposit label (e.g., "end moraines of coarse-textured till," "outwash sand
   and gravel," etc.) — this describes soil permeability/contaminant transport character at a
   regional level.

3. **Bedrock Geology** — EGLE GrmdOpenData layer 0. Query the parcel's exact point. Report the
   bedrock formation name (e.g., "Coldwater Shale"). Shale bedrock is generally low-permeability;
   sandstone/limestone bedrock can support more significant fracture flow. State this factually,
   without diagnosing what it means for the specific well without a hydrogeologist.

4. **USDA SSURGO Soil Survey** — query via USDA Soil Data Access REST API
   (`sdmdataaccess.sc.egov.usda.gov/Tabular/post.rest`) using
   `SDA_Get_Mukey_from_intersection_with_WktWgs84('POINT (lng lat)')`. Report the dominant soil
   series, drainage class, and hydric rating. A hydric soil component present in the local soil
   association is a real reason to flag wetlands as needing direct confirmation (FEMA/NWI), even
   if those services didn't return usable data — do not treat "service unreachable" as "no wetland
   concern."

5. **What this section is NOT**: it does not establish groundwater flow direction, does not confirm
   an exposure pathway to a specific well, and does not replace a hydrogeologist. Frame findings as
   "regional geologic context" — real, sourced, and relevant to due diligence, but not a substitute
   for a site-specific hydrogeological study.

### Technical Boundary — EGLE OGMD Data Explorer (egle.state.mi.us/dataminer)
This is a legacy JavaScript map/search widget (similar category to MISS DIG's Esri Experience
Builder) that does not reliably respond to automated browser clicks. Do NOT spend extended effort
attempting to automate it. Use the GrmdOpenData ArcGIS REST FeatureServer for well/geology data
instead (works reliably via direct HTTP query). For actual log PDF scans, direct the user to
request them manually from EGLE OGMD using the well's API number — this is a real, fast path that
doesn't require automation.

---

## WELL TESTING — VERIFIED REAL OPTIONS (use these, do not invent costs)

- Standard Michigan free/low-cost well test package (via EGLE/local health dept): bacteria (~$16),
  partial chemistry — nitrate, nitrite, fluoride, chloride, sodium, calcium (~$18). Does NOT include PFAS.
- PFAS testing: EGLE Drinking Water Laboratory 18-analyte PFAS test kit — $290, EPA Method 537.1.
  Call 517-335-8184. EGLE also publishes a list of additional certified private labs.
- Metals/inorganics panel (relevant when the nearby contamination site is metals-based, e.g. an
  old landfill) — confirm exact metals covered with the specific lab before ordering. EGLE Drinking
  Water Lab (517-335-8184) offers a Complete Metals Test.
- Local sample bottle sources vary by county — always check the local Community Health Agency's
  "Local Water Testing Labs" page for the specific municipal water department or wastewater plant
  that provides sampling containers close to the property (often faster turnaround than the state
  lab, 24-48 hrs vs. 3-14 days).

---

## FULL-FIELD EGLE PULL REQUIREMENT (MANDATORY)

Every environmental site referenced in this report type must be queried for ALL available fields,
not just SiteName/Address/City. At minimum pull and report:
- RiskCondition (this is EGLE's own risk rating — do not omit it)
- Contaminants (specific contaminant category, not just "contamination")
- ReleaseStatus / Total_Release / Open_Release / Closed_Release (for UST sites)
- HasBeaOrNom / HasBEA (Baseline Environmental Assessment on file)
- LastUpdated (convert epoch to readable date)
- ProjectManager (EGLE staff assigned — useful for direct inquiry)

A summary-fields-only pull (name/address/city) is NOT sufficient for this report type and must be
upgraded to a full-field pull before the report is finalized.

---

## RESOURCE LINKS SECTION — MANDATORY (v1.1)

Every report must include a dedicated section with real, working links and phone numbers, not just
inline prose citations. At minimum include:
- State GIS mapper for the relevant contamination type (e.g., EGLE RIDE Mapper)
- EGLE Water Well Viewer
- EGLE Drinking Water Laboratory page + phone number
- Local Community Health Agency well-testing page + phone number
- Local municipal water department / wastewater plant (sample bottle source) if identifiable
- County parcel GIS FeatureServer (source of any map polygon used)
- County tax/assessment lookup portal (e.g., BS&A Online)
- Direct links to the cited MCL statute pages
- FEMA Flood Map Service Center and USFWS NWI Wetlands Mapper (even if not yet queried successfully
  this session — give the reader the tool to check directly)

---

*Nvirogear LLC | Mr. Results (Overseer) | Locked July 1, 2026 | Updated v1.1 July 1, 2026*
*Supersedes any prior informal environmental-tax correlation language in this conversation.*
