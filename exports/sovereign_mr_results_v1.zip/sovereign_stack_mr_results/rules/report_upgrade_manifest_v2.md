# Report Upgrade Manifest v2.0 — Phase 1 / Phase 2 Product Clarity
## Date: May 19, 2026 | Source: Technical AI Review + Joe Joe (Owner) Direction
## Status: LOCKED — Applies to all Apple Dr v3 reports and all future enterprise reports
## Authority: Mr. Results — Nvirogear LLC

---

## PRODUCT MODEL — LOCKED

### Phase 1: Nvirogear Pre-Diligence Intelligence Report — $99–$199
Source-ledger-backed report that identifies:
- Parcel truth (identity, ownership, acreage, legal)
- Tax risk (uncapping, millage, forward projection)
- Ownership issues (trust, estate, PRE, lien signals)
- Nearby parcel context (assemblage, comp signals)
- Environmental flags (radar — not sampling)
- Rural due-diligence gaps (what's missing and why)
- Action items (ranked by cost and risk)
- Next steps (who to call, what to get)

### Phase 2: Deep Verification Add-On — $499–$799
Deeper verification:
- EPA ECHO / EGLE pull (not sampling)
- FEMA FIRM zone pull
- NWI wetland data pull + delineation referral (field delineation requires qualified professional)
- NRCS soil review
- Well/septic record request from county health
- ROD deed chain pull
- Building permit history
- Deeper comparable sales (MLS/county sales data)
- Consultant handoff coordination

### CRITICAL DISTINCTIONS (never confuse these)
- "Phase 1 Nvirogear report" = our pre-diligence product tier
- "Phase I ESA" = environmental professional report (ASTM E1527)
- "Phase 2 Nvirogear add-on" = our deeper verification tier
- "Phase II ESA" = environmental professional soil/groundwater sampling report
- Neither Nvirogear Phase 1 nor Phase 2 replaces: legal advice, appraisal, survey, Phase I/II ESA, wetland delineation, engineering review, municipal approval, title commitment, or professional inspection.

---

## 14-PATCH MANIFEST — ALL REPORTS v3+

### PATCH 1 — Move "5 Things Before Any Offer" to Absolute Top
- Position: FIRST element in exec tab, before scorecards, summaries, everything
- Each action item requires: rank / action / why it matters / est. cost / time to complete / who can do it / urgency / risk if skipped / confidence / source ledger ref
- Cost color coding: Green <$500 | Amber $500–$2K | Red $2K+ | Gray unknown
- Who labels: Self-service | County/municipality | Title company | Attorney | Environmental consultant | Surveyor | Septic designer | Well contractor | Lender | Seller | Other professional

### PATCH 2 — Phase 1 / Phase 2 Boundary Table
- Title: "What This Report Covers vs. What Requires Deep Verification"
- Column A: Phase 1 Nvirogear Pre-Diligence
- Column B: Phase 2 Deep Verification Add-On
- Column C: Requires Licensed Professional (neither phase covers)
- Rows: parcel identity, tax analysis, uncapping projection, value context, env screening, EPA ECHO/EGLE, FEMA, NWI, NRCS, well/septic, deed chain, title/trust authority, building permits, comp sales, consultant referrals, field professional reports

### PATCH 3 — Trust/Probate Language Refinement
- Rename: "Closing Authority Blocker Until Verified"
- Language: "Ownership appears to involve a trust or trust-related owner record. Buyer, lender, title company, or attorney should verify trustee authority before proceeding beyond LOI, purchase agreement, financing review, or closing."
- Do NOT state or imply legal conclusion
- Status: ADVISORY / NEEDS VERIFICATION
- Include Ottawa County Probate Court: 616-994-4520
- Include Ottawa County ROD next action
- Source + confidence required

### PATCH 4 — Owner Motivation Signal Safety
- Rename: "Owner Motivation Signal — Advisory Inference"
- Signal strength: LOW / MEDIUM / HIGH
- Confidence: LOW / MEDIUM / HIGH
- Supporting indicators (each labeled as indicator, not fact)
- Counter-scenario REQUIRED ("Alternative: Trust may be a long-term hold structure with no intent to sell.")
- Next action
- Do NOT state owner IS motivated as fact

### PATCH 5 — Assemblage Math Upgrade
- Keep SEV math
- ADD: "Estimated Market Value if Assembled" using SEV multiplier range
  - Low: combined SEV × 1.15
  - Mid: combined SEV × 1.45
  - High: combined SEV × 1.75
- Every multiplier labeled: MODELED ESTIMATE / not appraisal / needs comp verification
- Fields: subject SEV, adj. parcel SEVs, combined SEV, combined acreage, low/mid/high market est., method, confidence, missing verification
- Do NOT invent acquisition costs — if unknown: "Estimated acquisition cost requires owner/listing/market verification."

### PATCH 6 — Comparable Sales Methodology
- Each comp: source / source type / date range / sale date / sale price / acreage / improved/vacant / distance from subject / price per acre / structure size / road frontage note / utility note / zoning note / adjustment notes / confidence
- Add methodology box: search radius / date range / property type / acreage range / adjustment method / limitations / confidence
- Disclaimer: "Comps are public-reference market indicators and are not an appraisal. Values should be verified by licensed appraiser, MLS access, or licensed valuation source before lending or purchase reliance."

### PATCH 7 — Consultant Directory Grouping by Purpose
Groups:
1. Environmental / Phase I / Phase II / BEA / Due Care
2. Wetland Delineation
3. Septic / Perc / County Health
4. PFAS / Water Testing Labs
5. FEMA / Flood / Elevation Certificate / Survey
6. Civil Engineering / Development Feasibility
7. Title / Trust / Ownership Verification
8. Brownfield / Funding / Remediation Support

Each card: company name / category / service match / phone / website / region served / est. turnaround / est. cost range / source / confidence / not-an-endorsement notice
Rule: FOUR verified entries > SEVEN weak entries. No padding.

### PATCH 8 — Photo/Site Evidence Gap = Transaction Risk Checklist
Each missing item: missing visual / why it matters / risk if skipped / est. cost exposure if issue exists / who can capture it / priority / report section affected
Items: well head, pressure tank, septic tank/drainfield, road frontage, driveway/access, interior, basement/foundation, electrical panel, HVAC/mechanicals, outbuildings, low/wet areas, drainage, fence/encroachment, aerial/drone overview, neighboring land-use
Add: "Generate Field Capture Checklist" button (printable/mobile-friendly)
No third-party listing photos stored.

### PATCH 9 — Report Traceability / Watermark
Fields in report header: report_id / parcel_uid / report_type / report_version / generated_date / generated_by / source_ledger_version / data_completeness_score / draft-final status
Pilot reports: "PILOT PROTOTYPE — NOT FOR DISTRIBUTION"
Future: report ID + hash checksum field + generated timestamp + source ledger version

### PATCH 10 — Date Format Standardization
Standard: 2026-05-19 (ISO 8601) throughout all reports
All date_checked fields: ISO format
Existing "May 19, 2026" references: leave in narrative text, use ISO in data fields

### PATCH 11 — Mobile Performance / Lazy Map Load
- Map tab click → initMap() only (already implemented — verify)
- Initial exec tab loads WITHOUT map
- Default map layers on init: subject parcel + top blockers only
- Deeper layers load on toggle click (already implemented — verify)
- Add "Open Interactive Map" button on exec tab that switches to map tab

### PATCH 12 — Print / PDF Export
- exec scorecard: break-inside avoid
- "5 Things Before Any Offer" card: page-break-after to keep on first page
- Maps: stable print height + "Interactive map available in digital version" text for print
- Source ledger appendix: page-break-before
- Consultant directory tables: break-inside avoid
- Footer: report_id + date on every printed page
- Pilot watermark: visible on print

### PATCH 13 — Internal Product Readiness Label (admin-only)
Options:
- PAID PHASE 1 READY
- PAID PHASE 1 READY — Advisory Gaps Present
- PHASE 1 PRE-DILIGENCE ONLY
- PHASE 2 VERIFICATION RECOMMENDED
- INTERNAL REVIEW NEEDED
- NOT READY FOR PAID EXPORT

Scoring: parcel identity confidence + tax completeness + value support + env scan status + FEMA + NWI + well/septic + ROD/sales history + permit history + source ledger completeness
Not shown to clients unless admin enables.

### PATCH 14 — Final Rules
1. Do not remove v2 improvements
2. Action card always at top of exec tab
3. Phase 1/2 boundary table near front
4. Trust flag = advisory, routes to title/legal, no legal conclusion
5. Owner motivation = inference with counter-scenario
6. Assemblage = SEV math + market value range estimate
7. Comps = methodology box + adjustment notes
8. Consultant directory = grouped by purpose, verified only
9. Photo gaps = transaction risk framing
10. Report ID/version on every report
11. Dates standardized ISO 8601
12. Map: lazy-load, exec tab loads fast
13. Print: clean, stable, watermarked
14. Readiness label: admin-only
15. All claims source-ledger-backed
16. All unknowns marked unknown
17. Map = evidence engine
18. Clean and professional always

---

## PHASE 1 → PHASE 2 UPSELL FLOW (LOCKED ARCHITECTURE)

1. User receives Phase 1 report
2. Report clearly shows: known / unknown / potential deal-killers / needs professional verification
3. "5 Things Before Any Offer" card points naturally to Phase 2 for each critical gap
4. Phase 2 offers deeper pulls: EPA/EGLE, FEMA/NWI/NRCS, well/septic records, ROD/deed chain, consultant handoff, deeper comps
5. Phase 2 priced higher because it takes deeper verification effort
6. Neither phase replaces licensed professional diligence

---
*Report Upgrade Manifest v2.0 | Locked May 19, 2026 | Mr. Results — Nvirogear LLC*
