# AGENT RULES — SOVEREIGN AGENT OPERATING PROTOCOL
# Version: 1.0 | Date: 2026-06-26
# Authority: Joe Smith, Nvirogear LLC
# Status: LOCKED — do not modify without explicit owner approval

---

## PURPOSE

These rules govern all autonomous code editing, file modification, and repair actions
performed by any AI agent (including Mr. Results) on any Nvirogear codebase.

They exist because autonomous agents can cause irreversible damage to working systems
if allowed to guess, overwrite, or silently truncate. These rules make the agent
safe to use at speed without sacrificing control.

---

## THE 8 SOVEREIGN RULES

### RULE 1 — No file deletion without explicit approval
The agent may NOT delete any file, directory, component, or database record
without the owner explicitly approving the deletion by name.

This includes:
- Removing imports that appear unused
- Deleting components during refactor
- Clearing test data or log files
- Removing commented-out code blocks

Violation consequence: FULL STOP. Rollback. Report to owner.

---

### RULE 2 — Create a backup before editing
Before modifying any existing file, the agent must:
1. Copy the original to `{filename}.backup.{YYYYMMDD-HHmm}`
2. Confirm the backup exists before proceeding
3. Include the backup path in the patch summary

If a backup cannot be created, the edit does NOT proceed.

---

### RULE 3 — Output a patch summary
Every code edit must produce a human-readable patch summary:

```
PATCH SUMMARY
File: {filename}
Backup: {backup path}
Changes made:
  - [line X] {what changed and why}
  - [line Y] {what changed and why}
Business logic preserved: YES / NO (explain if NO)
Syntax check: PASSED / FAILED
Build check: PASSED / FAILED / NOT RUN
Rollback command: {exact command to restore}
```

No silent edits. Every change is documented.

---

### RULE 4 — Run syntax and build checks
After every edit, the agent must:
1. Run a syntax check appropriate to the file type
   - JSX/TSX: `node --input-type=module` or equivalent linter
   - Python: `python -m py_compile`
   - JSON: `python -m json.tool`
2. Attempt a build if a build system is present (`npm run build`, etc.)
3. Report the result in the patch summary

If syntax check fails: do NOT deliver the file as complete. Flag and stop.

---

### RULE 5 — Preserve existing business logic
The agent must:
- Never remove working features to simplify a fix
- Never rewrite a component from scratch when a targeted patch will do
- Never change data schemas, API calls, or state management without explicit approval
- Flag any change that could affect data flow, user permissions, or output format

If business logic must change to fix the bug: STOP and ask for approval first.

---

### RULE 6 — Never touch secrets, credentials, or production data
The agent is PERMANENTLY PROHIBITED from:
- Reading, writing, or displaying .env files
- Accessing API keys, tokens, or passwords
- Modifying production database records
- Connecting to live Supabase in write mode during a repair session
- Committing to a production branch

Sandbox and staging only during repair sessions.

---

### RULE 7 — Stop if code is truncated — never guess silently
If the agent detects that a file appears truncated (missing closing brackets,
incomplete components, cut-off imports, partial JSX), the agent must:

1. STOP immediately
2. Report the exact location of suspected truncation
3. List what appears to be missing based on handlers, state, and imports
4. Propose a diagnosis — do NOT auto-fill the missing code
5. Wait for owner approval before writing any reconstructed section

Silently guessing at missing code is a critical violation of this protocol.

---

### RULE 8 — Produce a rollback command
Every edit session must end with a clearly stated rollback command or procedure:

```
ROLLBACK: cp {backup path} {original path}
```

Or for multi-file sessions:
```
ROLLBACK SESSION: restore the following files from backup:
  1. cp App.jsx.backup.20260626-1045 App.jsx
  2. cp routes.js.backup.20260626-1045 routes.js
```

The rollback command must be copy-paste executable by a non-technical operator.

---

## OPERATING SEQUENCE (per repair session)

1. READ — Agent reads the file completely. Notes file size and line count.
2. DIAGNOSE — Agent reports what it sees: structure, missing sections, syntax issues.
3. PROPOSE — Agent proposes a specific patch. No code written yet.
4. APPROVE — Owner reviews and approves the patch plan.
5. BACKUP — Agent creates backup file.
6. PATCH — Agent applies targeted changes only.
7. VERIFY — Agent runs syntax/build check. Reports result.
8. SUMMARIZE — Agent outputs full patch summary with rollback command.

This is sovereign but safe. Speed comes from the diagnostic being accurate,
not from skipping steps.

---

## VIOLATION HANDLING

If the agent detects it has violated any rule:
1. STOP all edits immediately
2. Report the violation and what was done
3. Provide the rollback command
4. Do not attempt to self-correct silently

---

*Nvirogear LLC | Sovereign Agent Protocol v1.0 | 2026-06-26*
*Authored by Mr. Results (Overseer) — approved by Joe Smith*
