# Nvirogear Evidence Provenance Protocol v1.0 — LOCKED
**Issued by:** Mr. Results (Overseer) | **Date:** 2026-07-02
**Status:** PERMANENT — applies to every evidence collection run, every report, every FOIA package

---

## THE THREE-LAYER LOCK

Every source used in a Nvirogear report must pass through three layers before it enters the Source Ledger. No exceptions.

### LAYER 1: Download the Real File (Working Evidence)
Download the actual dataset — not a screenshot of it.
- ArcGIS REST query → save as GeoJSON file
- EGLE/EPA web page → save as HTML file
- PDF documents → download the PDF directly
- API responses → save as JSON file
- CSV exports → save as CSV file

This is the file you cite at a Board of Review. This is the file ALICE ingests.
A screenshot is a picture of data. The file IS the data.

### LAYER 2: Wayback the URL (Neutral Witness)
Submit the source URL to https://web.archive.org/save/[URL]
- This creates a third-party capture proving what the server was publishing at that address on that date
- The Wayback capture is better than your own screenshot because a neutral party took it
- Record the Wayback snapshot URL in the provenance ledger

### LAYER 3: Hash + Anchor the File (Tamper Seal)
- Compute SHA-256 hash of every downloaded file
- Record the hash in the provenance ledger
- Blockchain anchor: submit the hash to a tamper-eptent anchoring service (VaultSmith / OriginStamp / chainpoint)
- The anchor proves your copy hasn't changed since the day you pulled it

### LAYER 4 (OPTIONAL): Screenshot as Garnish
Screenshots are acceptable ONLY for:
- Interactive map applications mid-zoom
- Popups showing specific site attributes
- Anything that only renders with JavaScript clicking
If taken: anchor those too, note URL and timestamp in filename.
Screenshots are garnish, not the meal. Never the primary evidence.

---

## THE PROVENANCE LEDGER (MANDATORY)

Each source gets one row:

| Field | Description |
|-------|-------------|
| source_name | Human-readable source name |
| source_url | Original URL where data was retrieved |
| retrieved_date | ISO 8601 timestamp |
| file_path | Local path to downloaded file |
| file_hash | SHA-256 hash of downloaded file |
| file_format | GeoJSON / HTML / PDF / JSON / CSV |
| wayback_url | web.archive.org snapshot URL |
| anchor_ref | Blockchain anchor transaction reference |
| confidence_badge | VERIFIED / PUBLIC REFERENCE / ADVISORY |
| notes | Any limitations or caveats |

One line per source. Any single piece of evidence can be traced through all three layers years from now.

---

## EXECUTION ORDER

Ingest → Wayback → anchor → ledger → THEN the FOIA goes out.

No FOIA package leaves Nvirogear without the evidence pre-flight lock complete.

---

*Mr. Results (Overseer) — Nvirogear LLC — Evidence Provenance Protocol v1.0 — 2026-07-02*
