# REPAIR PLAYBOOK — NVIROGEAR CODEBASE REPAIR LOG
# Version: 1.0 | Date: 2026-06-26
# Authority: Mr. Results (Overseer) — Nvirogear LLC
# Status: LIVE — append new repairs as they are completed

---

## PURPOSE

This playbook is the institutional memory for every codebase repair performed
on any Nvirogear project. Each entry records what was broken, how it was diagnosed,
what was done to fix it, and what the rollback procedure is.

It serves two purposes:
1. Quick reference when a similar issue recurs
2. Training data for the Sovereign Agent (Kimmy/Codex)

---

## HOW TO ADD AN ENTRY

After every repair session, append a new section below using this template:

```
## REPAIR: {filename} — {YYYY-MM-DD}
File: {full path}
Agent: {who performed the repair}
Mission: {one sentence — what was broken}
Root cause: {truncation / syntax error / missing import / logic conflict / other}
Detected by: {build error message / symptom description}
Lines affected: {line range or "full file"}
Reconstructed sections: {list of what was rebuilt}
Business logic altered: YES (describe) / NO
Build result: PASS / FAIL
Patch summary: {key changes in plain English}
Rollback: {exact cp command or procedure}
Lessons learned: {what this teaches for future repairs}
```

---

## COMMON TRUNCATION SIGNATURES

These patterns indicate a file was truncated mid-write:

| Signature | What it means |
|---|---|
| JSX tag opened, never closed | File cut during component render |
| `return (` with no matching `)` | File cut inside a return block |
| Import declared, component never used | Tab/panel was cut before render |
| `case 'tabName':` with no content | Switch/case cut mid-block |
| State variable declared, never rendered | State set up before panel was written |
| `const handle{X} = () => {` never closed | Handler cut mid-definition |
| File ends mid-string or mid-comment | Hard cut, often from token limit |

---

## REPAIR: App.jsx (N-ViroGear v8) — PENDING
File: App.jsx
Agent: Kimmy / Codex (Mr. Results oversight)
Mission: Restore missing OCR tab and any other truncated render panels; fix syntax closure; get app compiling
Status: AWAITING FILE UPLOAD FROM OWNER

Suspected root cause: Token limit truncation during AI-assisted code generation
Detected by: App fails to compile; OCR tab section missing from render

Pre-repair checklist:
- [ ] File received and backed up
- [ ] Truncation scan completed
- [ ] Tab inventory: declared vs. rendered
- [ ] Handler inventory: defined vs. bound
- [ ] Import inventory: imported vs. used
- [ ] Patch proposed and approved by owner
- [ ] Patch applied
- [ ] Syntax check passed
- [ ] Build check passed
- [ ] Patch summary delivered
- [ ] Rollback command delivered

---

## GENERAL REPAIR LESSONS (accumulated)

### Lesson 1 — Token limit truncation is the most common failure mode
When an AI writes a long file in one pass, it often hits its token output limit
and cuts the file mid-component. The symptom is always the same: the last
section of the file is missing its closing brackets, the last tab panel is absent,
and the file compiles to a cryptic JSX parse error.

Fix pattern: Find the last complete component, find what tabs/panels are missing
by cross-referencing the tab array, reconstruct the shells, close all open brackets.

### Lesson 2 — Never rewrite to fix a syntax error
When a file has a syntax error, the instinct is to rewrite the broken section.
The correct move is to find the exact unclosed bracket or tag and close it surgically.
Rewriting risks losing business logic. Surgical closure preserves everything.

### Lesson 3 — The tab array is your map
In any tabbed React app, the array of tab names (e.g., `['Overview', 'OCR', 'Compliance']`)
is the authoritative list of what panels should exist. Cross-reference it against
the switch/case or conditional render blocks to find exactly what's missing.

### Lesson 4 — Imports tell you what was planned
If a component is imported at the top of the file but never rendered, that component
was planned for a section that got cut. It's a reliable signal of truncation location.

---

*Nvirogear LLC | Repair Playbook v1.0 | 2026-06-26*
*Append new entries after each repair. Never delete entries.*
