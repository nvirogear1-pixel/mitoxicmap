# Bot-to-Bot Handshake Protocol
# Version: 3.1 | Date: 2026-05-18
# Status: LIVE — FULLY VERIFIED

## ============================================================
## CONFIRMED WORKING ENDPOINTS (live-tested May 18 2026)
## ============================================================

### Mr. Results (Overseer)
- App ID: 69ca9ac1baa8ecdb8ae25c59
- pipelineIngest:     https://mr-results-8ae25c59.base44.app/functions/pipelineIngest
- getBotRegistry:     https://mr-results-8ae25c59.base44.app/functions/getBotRegistry
- dispatchHistorianTask: https://mr-results-8ae25c59.base44.app/functions/dispatchHistorianTask
- jetResyncBridge:    https://mr-results-8ae25c59.base44.app/functions/jetResyncBridge
- Status: LIVE ✅

---

### Jet / GIS Bot (Badass Real Estate Grabber)
- App ID: 69c8150358e2fbf60c18c5f1
- Intake URL: https://badass-real-estate-grabber-0c18c5f1.base44.app/functions/receiveTaskFromMrResults
- Valid task_types: fetch_county | push_county | status_report | custom
- Callback to Mr. Results: https://mr-results-8ae25c59.base44.app/functions/jetResyncBridge
- Status: LIVE ✅ — queues tasks, must include callback_url in parameters

**Dispatch template:**
```json
{
  "task_id": "MR-GIS-{COUNTY}-{YYYYMMDD}-001",
  "task_type": "fetch_county",
  "from": "mr_results",
  "caller_id": "69ca9ac1baa8ecdb8ae25c59",
  "county": "Muskegon",
  "state_code": "MI",
  "priority": "high",
  "parameters": {
    "callback_url": "https://mr-results-8ae25c59.base44.app/functions/jetResyncBridge",
    "require_geometry": true,
    "geometry_type": "polygon",
    "fallback_centroid": true
  }
}
```

---

### Historian Bot (Super History Bot)
- App ID: 69c85fb48f74ddba2d658b84
- Intake URL: https://super-history-bot-2d658b84.base44.app/functions/receiveTask
- Valid task_types: phase1_sweep | phase1.5_appraisal | parcel_scan | zoning_sweep | env_check
- Callback: writes to TaskInbox, Mr. Results polls or receives via pipelineIngest
- Status: LIVE ✅ — HTTP 201 confirmed

**Dispatch template:**
```json
{
  "task_id": "MR-HIST-{PARCEL_ID}-001",
  "task_type": "env_check",
  "from": "mr_results",
  "caller_id": "69ca9ac1baa8ecdb8ae25c59",
  "county": "Muskegon",
  "state_code": "MI",
  "parcel_id": "61-10-840-000-0027-00",
  "parameters": { "phase": 1, "priority": "high" }
}
```

---

### Outreach Bot
- App ID: 69da0b5e61f699701129e0e7
- Intake URL: https://outreach-bot-1129e0e7.base44.app/functions/receiveDispatch
- Valid dispatch_types: auto_dispatch_intro | classify_reply | trigger_report | get_log_status
- REQUIRED: caller_id = "69ca9ac1baa8ecdb8ae25c59" in EVERY payload or request is BLOCKED
- Status: LIVE ✅ — HTTP 200 confirmed

**Dispatch template:**
```json
{
  "task_id": "MR-OUTREACH-{CONTACT_ID}-001",
  "dispatch_type": "auto_dispatch_intro",
  "caller_id": "69ca9ac1baa8ecdb8ae25c59",
  "from": "mr_results",
  "contact_id": "...",
  "parcel_id": "..."
}
```

---

### Super Report Bot
- App ID: 69da0683bdf5fd812225eadc
- Direct URL: https://super-report-bot-2225eadc.base44.app/functions/{fn}
- Status: FUNCTIONS DEPLOYED ✅ — AUTH WALL ⚠️

**App is set to PRIVATE — all calls return 500 "This app is private"**
**FIX REQUIRED: App owner must set Super Report Bot to PUBLIC in app settings**
**OR: Provide an API key for Mr. Results to include as Bearer token**

Deployed functions (confirmed responding once auth resolved):
- /orchestrateOutreach  → Mode: dispatch_intro | reply_received
- /generateReport       → Direct report generation
- /classifyReply        → Reply classification + draft
- /serveReport          → GET HTML report by report_id

---

### Site Tracker (Badass Site Tracker)
- App ID: 69c85f18dc12a0945786d5f6
- Intake URL: https://badass-site-tracker-5786d5f6.base44.app/functions/receiveTask
- Status: LIVE ✅ — HTTP 200 | ACK confirmed May 18 2026
- Valid task_types: verify_listing | actionability_gate | site_check | catalog_scan | status_report
- Writes back: ACK with record_id, status: pending → agent processes and posts results

**Dispatch template:**
```json
{
  "task_id": "MR-SITE-{PARCEL_ID}-001",
  "task_type": "site_check",
  "from": "mr_results",
  "caller_id": "69ca9ac1baa8ecdb8ae25c59",
  "county": "Muskegon",
  "state_code": "MI",
  "parcel_id": "61-10-840-000-0027-00",
  "address": "3101 Violet Ave, Muskegon Heights MI 49444",
  "priority": "high",
  "parameters": {
    "subject": "...",
    "property_status": { ... },
    "gate_context": { "do_not_contact_owner": true }
  }
}
```

**ACK format:**
```json
{
  "ok": true,
  "ack": "ACK-{task_id}",
  "task_id": "...",
  "status": "pending",
  "message": "Task received. Agent will process and post results back.",
  "received_at": "...",
  "record_id": "..."
}
```

---

### Auction Gate Bot
- App ID: 6a09e83291d88c098df788fb
- Chat URL: https://app.base44.com/superagent/6a09e83291d88c098df788fb
- Status: CHAT REACHABLE ✅ — API ENDPOINT 404 ❌
- FIX REQUIRED: Operator must confirm or redeploy the auctionGateEntity function

## ============================================================
## URL FORMAT RULES
## ============================================================

Base44 standard apps use:
  https://{app-name-slug}-{last8ofAppId}.base44.app/functions/{functionName}

Base44 Superagent chat:
  https://app.base44.com/superagent/{appId}
  (Chat only — not an API endpoint)

DOES NOT WORK from inside platform:
  https://app.base44.com/api/apps/{id}/functions/{fn} → cross-platform restriction
  Use subdomain URLs only: https://{slug}-{id8}.base44.app/functions/{fn}

## ============================================================
## FLEET STATUS MATRIX — v3.1 (May 18 2026)
## ============================================================

| Bot              | Reachable | Auth OK | Writes Back | Fix Needed              |
|------------------|-----------|---------|-------------|-------------------------|
| Mr. Results      | ✅        | ✅      | ✅          | None                    |
| Jet / GIS        | ✅        | ✅      | ⚠️ Partial  | callback_url required   |
| Historian        | ✅        | ✅      | ✅          | None                    |
| Outreach         | ✅        | ✅      | ✅          | caller_id required      |
| Site Tracker     | ✅        | ✅      | ✅          | None — FULLY LIVE       |
| Super Report Bot | ✅        | ❌      | ❌          | Set app to PUBLIC       |
| Auction Gate     | ⚠️ Chat  | ❌      | ❌          | Redeploy auctionGateEntity |
