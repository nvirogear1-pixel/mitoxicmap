# N-ViroGear Underground Intelligence Doctrine
# Locked: 2026-05-25 | Authority: Joe (Nvirogear LLC)
# Source: MR. RESULTS — ADVANCED UI / FUTUREMIS DEEP DIVE DIRECTIVE

---

## THE MISSION

You are NOT building a map app.
You are building THE LAYER BETWEEN MAPS AND REALITY.

The breakthrough is NOT 3D graphics.
The breakthrough IS making invisible infrastructure understandable.

---

## THE CORE INTERACTION (LOCKED)

Page 2 = "Choose the ground."
Page 3 = "Inspect the earth."

The earth slice is the hero. Not the map.
Protect the emotional center. Do not bury it under menus.

---

## WHAT THE PLATFORM MUST FEEL LIKE

- Tactile
- Cinematic
- Layered
- Spatial
- Trustworthy
- Calm

NOT:
- Overloaded
- Engineer-chaos
- Enterprise clutter

---

## CONFIDENCE VISUALIZATION RULES (MANDATORY)

Every visual state communicates confidence. No exceptions.

| Visual State     | Meaning                        |
|------------------|--------------------------------|
| Solid            | Verified — field confirmed      |
| Dashed           | Modeled — inferred from data    |
| Faded/Transparent| Low confidence                  |
| Glow             | Advisory — possible risk        |
| Pulse            | Conflict — contradicted data    |
| Ghosted          | Hypothesis — prediction only    |

**Modeled ≠ verified. Prediction ≠ truth. Overlay ≠ truth.**

---

## GHOST LINE RULE

Predicted/modeled utilities must NEVER look identical to verified ones.
Ghost lines = tentative, translucent, dashed.
Users must immediately know: "This is a hypothesis."

---

## TRUTH BUBBLE RULE

Tap anything → small contextual bubble appears.
NOT a giant modal. NOT a sidebar. NOT a separate page.

Every bubble must contain:
- What it is
- Source
- Confidence
- Why it matters
- What's still missing

The earth explains itself.

---

## PERMISSION LAYER ARCHITECTURE (FUTURE-READY)

Layer visibility must eventually support:
- Public users → surface + environmental only
- Contractors → utility layers, no internal confidence scores
- Operators → full stack + confidence metadata
- Municipalities → full provenance chain + conflict flags
- Environmental consultants → PFAS + boring logs + sampling

Design every layer with permission state in mind now.

---

## FIELD MEMORY SYSTEM (LONG-TERM VISION)

The app becomes infrastructure memory, not just records.
Every verification event strengthens the Truth Layer:
- Operator notes
- Exposed pipe photos
- Locate history
- Old city print overlays
- Changed/replaced infrastructure
- Historical uncertainty events

---

## BOREHOLE / WELL DATA ARCHITECTURE (FUTURE-PROOF NOW)

Even when data is missing, the schema must be ready for:
- Borehole logs
- Drilling reports
- Well logs (Michigan Wellogic)
- Bedrock depth
- Groundwater elevations
- Contamination sampling
- Geotechnical notes

---

## THE PHILOSOPHY

The platform is NOT:
- Fantasy infrastructure
- Fake AI certainty
- Glowing map hype

The platform IS:
Truth-aware infrastructure intelligence.

Always preserve:
- Confidence
- Lineage
- Source
- Timestamp
- Contradiction
- Uncertainty

**Humans understand earth physically. Not as spreadsheets. Not as CAD layers. Not as GIS tables.**

If users can see it, rotate it, isolate it, inspect it, and understand confidence visually —
the platform becomes UNDERSTANDABLE REALITY.

That is the mission.

Build the system one verified layer at a time.

---
*N-ViroGear Underground Intelligence Doctrine — Locked 2026-05-25 — Nvirogear LLC*
