# Nvirogear Land Use, Homestead & Development Feasibility Module
## Specification v1.0 — Locked May 19, 2026

**Module Name:** Land Use, Homestead & Development Feasibility Module
**Activation:** vacant land | agricultural | large acreage | forest | rural residential | recreational | developer target | manual

---

## CORE DOCTRINE

A house report asks: "Is this property safe, financeable, and worth improving?"
A land report asks: **"Can I actually use this land the way I think I can?"**

---

## INVIOLABLE RULES

1. Never invent zoning permissions — if unclear, mark UNKNOWN / VERIFY
2. Never approve land use — use "CANDIDATE," "CONDITIONAL," "NEEDS VERIFICATION"
3. Every septic/well/utility claim must include disclaimer: "verify with county health dept / utility / qualified professional"
4. All map layers are togglable
5. Every flag has a source + next action
6. Supplier pins: no endorsement language — list as public reference only
7. Soil/perc test findings = ADVISORY unless confirmed by licensed soil evaluator
8. Road frontage / access = ADVISORY unless confirmed by survey/title

---

## SCORES (all three required for land parcels)

### 1. Land Use Readiness Score (0–100)
- 85–100: Strong Land Candidate
- 70–84: Buildable / Usable with Conditions
- 55–69: Conditional
- 40–54: High Friction
- 0–39: Not Ready / High Risk
- Unknown: Insufficient Data

### 2. Homestead Feasibility Score (0–100)
Weights:
- Residential buildability: 20%
- Septic/well feasibility: 20%
- Animal/livestock ordinance compatibility: 10%
- Solar/off-grid compatibility: 10%
- Access/road frontage/driveway: 15%
- Soil/topography/wetland/flood: 15%
- Utility availability or self-sufficiency: 10%

Ratings: STRONG_HOMESTEAD | GOOD_WITH_CONDITIONS | POSSIBLE_VERIFY | HIGH_SETUP_BURDEN | POOR_FIT | UNKNOWN

### 3. Developer Land Feasibility Score (0–100)
Weights:
- Zoning compatibility: 20%
- Density/subdivision potential: 15%
- Public water/sewer availability: 20%
- Road frontage/access/ingress-egress: 15%
- Environmental constraints: 15%
- Market/nearby parcel support: 10%
- Permit and ordinance friction: 5%

Ratings: STRONG_DEVELOPMENT | VIABLE_WITH_CONDITIONS | SPECULATIVE | HIGH_ENTITLEMENT_BURDEN | POOR_DEVELOPMENT_FIT | UNKNOWN

### 4. Access Score (0–100)
- 85–100: Strong legal/practical access
- 70–84: Access likely, verify driveway/permits
- 55–69: Conditional access
- 40–54: Access friction
- 0–39: Possible landlocked/access blocker
- Unknown: Insufficient data

### 5. Septic/Well Feasibility Score (0–100)
### 6. Environmental Land Constraint Score (0–100)
### 7. Rural Utility/Off-Grid Score (0–100)
### 8. Supplier Support Score (0–100)
### 9. Overall Land Intelligence Score (0–100)
### 10. Data Completeness Score (0–100)

---

## ZONING ALLOWED USE MATRIX

Status labels (ONLY these four):
- ALLOWED
- CONDITIONAL
- NOT ALLOWED
- UNKNOWN / VERIFY

Uses to evaluate:
single_family_home | manufactured_home | modular_home | tiny_home | adu | accessory_building | barn/pole_barn | livestock | chickens | horses | farming/garden | solar | wind_turbine | short_term_rental | camp/rv_temporary | commercial | subdivision | lot_split

Rule: Never invent permissions. If ordinance is unclear = UNKNOWN / VERIFY

---

## WATER / SEWER / SEPTIC / WELL FEASIBILITY

Track:
- Public water status: AVAILABLE | NEARBY | UNAVAILABLE | UNKNOWN
- Public sewer status: AVAILABLE | NEARBY | UNAVAILABLE | UNKNOWN
- Private well needed: YES | NO | UNKNOWN
- Septic needed: YES | NO | UNKNOWN
- Perc test needed: YES | NO | UNKNOWN
- Soil suitability: GOOD | MODERATE | POOR | UNKNOWN
- Known constraints: wetlands, slopes, setbacks, water table, contamination
- County health dept contact required

**Required warning:**
> "Septic and well feasibility must be verified by the county health department, licensed soil evaluator, well contractor, or qualified professional. This report only identifies public-record indicators, constraints, and next actions."

---

## RURAL UTILITY & OFF-GRID READINESS

Track per parcel:
- Electric service nearby: YES | NO | UNKNOWN
- Nearest visible utility line: distance if known
- Natural gas available: YES | NO | UNKNOWN
- Propane likely needed: YES | NO | UNKNOWN
- Broadband: fiber | cable | fixed_wireless | satellite | unknown
- Solar suitability: GOOD | MODERATE | POOR | UNKNOWN
- Battery/off-grid suitability: GOOD | MODERATE | POOR | UNKNOWN
- Generator suitability: GOOD | MODERATE | UNKNOWN
- Utility easement needed: YES | NO | UNKNOWN

---

## ACCESS & ROAD FRONTAGE REVIEW

Track:
- Public road frontage
- Private road frontage
- Landlocked risk: LOW | MODERATE | HIGH | UNKNOWN
- Driveway permit required: YES | NO | UNKNOWN
- Culvert permit required: YES | NO | UNKNOWN
- Seasonal road risk
- Road maintenance agreement needed
- Fire/EMS access concern
- Address assignment needed
- County road commission contact

---

## LAND DEAL KILLER FLAGS

| Flag | Meaning |
|---|---|
| LAND-ACCESS-001 | Possible landlocked parcel |
| LAND-SEPTIC-001 | Septic feasibility unknown or questionable |
| LAND-WETLAND-001 | Wetlands may limit buildable area |
| LAND-FLOOD-001 | Floodplain may affect buildability |
| LAND-ZONING-001 | Intended use not clearly allowed |
| LAND-UTILITY-001 | Utility service uncertain or expensive |
| LAND-SPLIT-001 | Lot split/subdivision unknown |
| LAND-EASEMENT-001 | Easement/title issue requires review |
| LAND-ORD-001 | Animal/solar/accessory use restricted or unknown |
| LAND-SOIL-001 | Poor soils/slope may raise construction cost |
| LAND-ENV-001 | Environmental concern may require professional review |

---

## SUPPLIER NETWORK PINS (Land Report Only)

Required categories:
lumber yards | hardware/building supply | gravel/sand/topsoil | septic installers | well drillers | excavators | surveyors | soil/perc evaluators | propane suppliers | electric utility contact | solar installers | fencing suppliers | farm supply/feed stores | equipment rental | tree clearing/site prep | driveway/culvert contractors | pole barn builders | modular/manufactured home dealers | dumpster/waste disposal

Per pin: name | category | address | phone/website | distance from parcel | relevance tags | source | confidence | NO ENDORSEMENT LANGUAGE

**Supplier notice (required):**
> "Supplier listings are provided as public-record reference only for planning purposes. Nvirogear does not endorse, recommend, or warranty any listed supplier. Verify licensing, insurance, and availability directly."

---

## DEVELOPMENT PATHWAYS

### Homestead Pathway (9 steps)
1. Verify zoning and allowed residential use
2. Confirm legal access and road frontage
3. Contact county health dept for septic/well
4. Order perc/soil evaluation
5. Confirm electric/gas/propane/internet options
6. Check livestock, solar, accessory building, driveway ordinances
7. Estimate site prep cost
8. Confirm financing/insurance requirements
9. Build budget and permit timeline

### Developer Pathway (10 steps)
1. Verify zoning and future land use map
2. Confirm density, setbacks, min lot size, subdivision rules
3. Confirm water/sewer capacity or extension feasibility
4. Review wetlands/floodplain/environmental constraints
5. Conduct survey and title/easement review
6. Contact planning/zoning for pre-application meeting
7. Estimate entitlement timeline
8. Estimate infrastructure cost
9. Run pro forma with development scenarios
10. Identify deal killers before acquisition

---

## MAP LAYERS (Land Report — additional layers)

20 land-specific layers (in addition to all standard layers):
1. Subject parcel boundary
2. Road frontage
3. Access points
4. Possible driveway route
5. Wetlands (NWI)
6. Floodplain (FEMA)
7. Soil limitations (NRCS Web Soil Survey)
8. Slope/topography
9. Preliminary building envelope (labeled: sketch only)
10. Preliminary septic/drainfield area
11. Public water line proximity
12. Public sewer line proximity
13. Electric service nearby
14. Natural gas/propane indicator
15. Solar exposure area
16. Environmental pins (Part 201/213/PFAS/UST)
17. Ordinance/zoning notes
18. Homestead suitability pins
19. Development constraint pins
20. Supplier network pins

---

## REQUIRED NOTICE (verbatim)

> "The Land Use, Homestead & Development Feasibility Module is designed for vacant, rural, agricultural, recreational, and development-target parcels. It evaluates zoning, allowed uses, access, road frontage, septic/well feasibility, public utility availability, animal and solar rules, environmental constraints, buildable-area limitations, and development friction. The module does not approve land use, guarantee buildability, or replace municipal, engineering, health department, survey, legal, or environmental review. It organizes the key decision indicators so buyers, developers, lenders, and homesteaders know what to verify before purchase or development."

---

*Land Module Spec v1.0 | Locked May 19, 2026 | Mr. Results — Nvirogear LLC*
