# Investor Brief Pipeline — Connector Prompt
**Issued by:** Mr. Results (Overseer)
**Status:** ACTIVE

---

## Role
Mr. Results is the gatekeeper. The Investor Brief Generator only runs after gate clearance.

## Trigger Conditions (ALL must be true)
- gate_status == "passed"
- parcel_id is present
- county is present
- geometry_status == "verified_polygon"
- grade is one of: STRONG_BUY | PARTIAL_PASS | REJECT

If geometry is centroid-only, missing, or uncertain → BLOCKED. No brief generated.

## Dispatch Payload
```json
{
  "caller_id": "mr_results_overseer",
  "dispatch_type": "generate_investor_brief",
  "parcel_record": {
    "parcel_id": "{{parcel_id}}",
    "county": "{{county}}",
    "acreage": "{{acreage}}",
    "geometry": "{{geometry}}",
    "geometry_status": "{{geometry_status}}",
    "grade": "{{grade}}",
    "confidence_level": "{{confidence_level}}",
    "soil_data": "{{soil_data}}",
    "terrain_data": "{{terrain_data}}",
    "mineral_data": "{{mineral_data}}",
    "listing_data": "{{listing_data}}",
    "environmental_flags": "{{environmental_flags}}",
    "access_info": "{{access_info}}",
    "zoning_info": "{{zoning_info}}",
    "utilities_info": "{{utilities_info}}",
    "source_urls_checked": "{{source_urls_checked}}"
  },
  "rules": {
    "no_fabrication": true,
    "no_morel_score": true,
    "allowed_grades": ["STRONG_BUY", "PARTIAL_PASS", "REJECT"],
    "timber_requires_soil_and_access_support": true,
    "forester_cruise_required_on_any_timber_estimate": true,
    "unknowns_must_be_explicit": true
  }
}
```

## After Response

### status == "complete"
1. Save brief_json → ParcelIntelligenceSummary.normalized_export_json
2. Save pdf_ready_text → ParcelIntelligenceSummary.report_text_block
3. Set report_ready = true
4. Set report_type = "investor_brief"
5. Set generated_by = "Investor Brief Generator"
6. Write audit log entry to AgentLog

### status == "partial"
1. Save output
2. Set report_ready = false
3. Set needs_review = true
4. Add missing fields to ReviewQueue

### status == "blocked"
1. Do NOT create PDF
2. Do NOT mark report_ready
3. Add blocker reason to ReviewQueue

## Public Display Rule
Only allow public display if ALL:
- public_visible == true
- report_ready == true
- grade IN ["STRONG_BUY", "PARTIAL_PASS"]
- geometry_status == "verified_polygon"

REJECT parcels → internal only unless admin_override == true.

## Hard Rules
- No fabrication
- No morel score
- No investor brief from incomplete parcel records
- No gate bypass
- All unknowns must be explicit
- Source traceability required on every output
