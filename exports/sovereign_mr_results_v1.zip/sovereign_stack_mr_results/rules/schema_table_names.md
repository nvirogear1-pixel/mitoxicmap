# SCHEMA TABLE NAME REGISTRY
**Issued by:** Mr. Results (Overseer)
**Date:** 2026-03-30
**Purpose:** Prevent silent failures from table name drift

---

## Badass Site Tracker (app: 69c85f18dc12a0945786d5f6)
| Purpose | Correct Table Name |
|---------|-------------------|
| Active listings | `ListingEvent` |
| Sale records | `SaleRecord` |
| Listing history | `ListingHistory` |
| Price changes | `PriceChangeEvent` |
| Parcel candidate links | `ParcelCandidateLink` |
| Auction events | `AuctionEvent` |
| Bot run log | `BotRunLog` |
| County run status | `CountyRunStatus` |

## Badass Real Estate Grabber (app: 69c8150358e2fbf60c18c5f1)
| Purpose | Correct Table Name |
|---------|-------------------|
| Parcel geometry + data | `ParcelAnnex` |
| Confirmed auctions | `ConfirmedAuction` |
| Auction listings | `AuctionListing` |
| Raw archive | `RawArchive` |
| Watchlist | `AdminWatchlist` |

## Super History Bot (app: 69c85fb48f74ddba2d658b84)
| Purpose | Correct Table Name |
|---------|-------------------|
| Historical entries | `HistoricalEntry` |
| Source documents | `SourceDocument` |
| Bot run log | `BotRunLog` |

## Mr. Results / Overseer (app: 69ca9ac1baa8ecdb8ae25c59)
| Purpose | Correct Table Name |
|---------|-------------------|
| Canonical parcel links | `ParcelLink` |
| Confidence assessments | `ConfidenceAssessment` |
| Conflict records | `ConflictRecord` |
| Intelligence summaries | `ParcelIntelligenceSummary` |
| Review queue | `ReviewQueue` |
| Export payloads | `ExportPayload` |
| Bot run log | `BotRunLog` |
| County run status | `CountyRunStatus` |
| Source registry | `SourceRegistry` |
| County source links | `CountySourceLink` |
| **Parcel reference layer** | `ParcelReference` |
| **Parcel match results** | `ParcelMatch` |

---

## CRITICAL RULES
- NEVER write to another bot's tables without Overseer approval
- NEVER use notes fields as a substitute for proper linking tables
- NEVER invent table names — check this registry first
- Parcel resolution results → `ParcelCandidateLink` (Site Tracker) NOT notes fields
- Only Overseer promotes to `ParcelLink` canonical status
- `ParcelReference` is the ground truth layer — NEVER store fake polygons or invented geometry
- `ParcelMatch` must always expose `match_method` and `match_confidence` — no silent matches

## GEOMETRY TRUTH RULES (NON-NEGOTIABLE)
- `geometry_type = polygon` → real GeoJSON polygon exists in `polygon_geojson`
- `geometry_type = centroid` → only a lat/lng point exists, NO polygon
- `geometry_type = unknown` → no reliable geometry at all
- NEVER draw a polygon from a centroid
- NEVER label a centroid as a parcel boundary
- NEVER auto-promote `centroid_only` or `unverified_location` to `verified_parcel`

## MATCH STATUS RULES
| Status | Meaning |
|--------|---------|
| `verified_parcel` | Matched to real polygon via parcel_id or point-in-polygon |
| `probable_parcel` | Strong address or centroid match, acreage aligned |
| `centroid_only` | Only point-level reference available |
| `unverified_location` | No trustworthy parcel match found |
