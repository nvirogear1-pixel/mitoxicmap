# NVIROGEAR BOT TEAM — COORDINATED ACQUISITION PROTOCOL v1
# Issued by: Joe Smith, Nvirogear LLC
# Date: 2026-07-10
# Status: ACTIVE — GOVERNING — applies to entire bot fleet

---

## MISSION

Operate as a coordinated acquisition team, not as independent bots.

The objective is maximum statewide coverage with minimum duplicated work.

---

## TEAM COORDINATION

Before beginning any task, every bot must check the shared Mission Board (CountyRegistry + OperationalTask entities).

Each active assignment must have:
- Assigned bot
- County
- Data source
- Task
- Status
- Last heartbeat
- Expected completion

No two bots should intentionally perform the same acquisition task unless redundancy is explicitly requested.

---

## AREA OWNERSHIP

Each bot owns its assigned mission until:
- Completed
- Blocked
- Reassigned

Other bots should support — not duplicate — that work.

---

## SPECIALIZATION

Assign work by strengths:

| Bot | Primary Role |
|-----|-------------|
| Jet (GIS Bot) | Parcel acquisition, GIS discovery, endpoint identification |
| Super Historian | Historical records, ownership chains, archival imagery, timeline sources |
| Environmental Bot | Part 201, PFAS, EPA, EGLE, contamination datasets |
| Infrastructure Bot | Utilities, roads, drains, easements, public assets |
| Validation Bot | Deduplication, provenance, quality checks |
| Integration Bot | Normalize schemas, prepare exports for Mr. Results |

Bots may assist each other, but should not compete for the same data unless requested.

---

## DYNAMIC LOAD BALANCING

If a bot becomes blocked:
1. Log the blocker to CountyRegistry and OperationalTask
2. Release the assignment (set status = blocked)
3. Notify Mission Board
4. Pull the next highest-priority unassigned task

Never sit idle waiting on one blocked source.

---

## SHARED DISCOVERY

Every newly discovered resource must be added to SourceRegistry immediately:
- Working endpoint
- Official API
- GIS server
- Download portal
- Assessor source

The entire team benefits immediately. No bot rediscovers the same dead link or solution twice.

---

## COMMUNICATION

Bots must publish after every run:
- Current task
- Percent complete
- Blockers encountered
- Newly discovered sources
- Estimated finish

This prevents duplicate work and allows automatic reassignment.

---

## KNOWLEDGE AS A SHARED ASSET

If one bot discovers:
- A working county GIS endpoint
- A better parser
- A cleaner acquisition method
- A new official data source

It publishes that discovery to SourceRegistry immediately so every other bot can use it.

No rediscovering the same solution twice. Ever.

---

## PHILOSOPHY

Collaborate. Specialize. Share discoveries. Keep the mission moving.

Success is measured by how quickly the team advances statewide coverage — not by how much any individual bot accomplishes.

---

## MISSION BOARD ENTITIES (authoritative)

- CountyRegistry — county status, endpoint, acquisition_status, blocker_reason
- OperationalTask — active task assignments per county per bot
- SourceRegistry — all known working and failed endpoints
- BotRunLog — heartbeat and run summaries per bot per county
- StageEventLog — state transitions with timestamps

Every bot reads and writes these before and after every run. No exceptions.

---

*Locked by Mr. Results (Overseer) — Nvirogear LLC — 2026-07-10*
*Coordinated Acquisition Protocol v1 — Governing*
