# GIS / Code / 3D Agent Prep Standard
# Authority: Mr. Results | Date: 2026-05-26 | Status: LOCKED

## THE THREE-LAYER FRAMEWORK

Every code/GIS/3D agent task must be prepped with all three layers before prompting.
Missing any layer → degraded output, hallucinated APIs, wrong geometry.

---

## LAYER 1 — SYSTEM PROMPT (who they are)

Inject as `role: "system"` before ANY user message. Defines expertise and constraints.

### Template for GIS/3D agent:
```
You are a senior GIS and 3D visualization engineer specializing in:
- ArcGIS JavaScript API (4.x) — MapView (2D) vs SceneView (3D) distinction
- Three.js r160 — WebGLRenderer, ShaderMaterial, BufferGeometry
- Spatial data: GeoJSON, GeoPackage, Shapefile, WKT, WKB
- Michigan parcel data structures (SSURGO, WELLOGIC, EGLE)
- USCS soil classification (SM, SP, CL, GW, ROCK)
- Subsurface geology: stratigraphy, water table, plume modeling

You output production-quality code only. No placeholders, no TODOs.
You never hallucinate API methods — if unsure, say so.
You distinguish VERIFIED data from MODELED data in every output.
```

---

## LAYER 2 — CONTEXT INJECTION (what they know)

Paste actual files, schemas, and API excerpts BEFORE the task. On 128K context (Qwen3):
- Entire parcel JSON fits
- Full SubsurfaceLayer schema fits
- ArcGIS API docs excerpt fits
- All three simultaneously fit

### What to inject for Nvirogear 3D tasks:
1. **SubsurfaceLayer records** — real depth data from entity
2. **ParcelRecord** — centroid lat/lng, acreage, polygon GeoJSON
3. **Relevant API excerpt** — paste the specific section, not a link
4. **Existing code block** — paste the current earth engine section

### Esri-specific context required (always inject these):
```
MapView  = 2D flat map (Leaflet equivalent)
SceneView = 3D globe/local scene (what we use for underground)
ExtrudeSymbol3D = extrudes polygon footprints into 3D volumes
ObjectSymbol3D  = places 3D models at point locations
PointSymbol3D   = 3D marker at coordinates
FillSymbol3D    = fills polygon faces in 3D

AMD pattern (CDN):  require(["esri/views/SceneView"], (SceneView) => { ... })
ES module pattern:  import SceneView from "@arcgis/core/views/SceneView.js"
DO NOT MIX these patterns — pick one per file.

Ground layer in SceneView:
  view.ground.layers.add(new ElevationLayer({ url: "..." }))

Subsurface extrusion:
  new ExtrudeSymbol3D({
    symbolLayers: [new ExtrudeSymbol3DLayer({
      material: { color: [r,g,b,a] },
      size: thicknessInMeters
    })]
  })
```

---

## LAYER 3 — MODEL SETTINGS

| Setting | Value | Reason |
|---|---|---|
| `max_tokens` | 4096–8192 | 1024 cuts off mid-function |
| `temperature` | 0.2–0.3 | Less random = fewer hallucinated APIs |
| `top_p` | 0.9 | Keep focused on high-probability tokens |
| `presence_penalty` | 0.0 | Don't penalize repetition in code (loops need it) |

---

## ESRI FAILURE POINTS (pre-empt these)

| Failure | Cause | Fix |
|---|---|---|
| `MapView` when 3D needed | Default assumption | Explicitly say SceneView |
| `ExtrudeSymbol3D` size in wrong units | Assumes pixels | Always specify meters |
| AMD vs ES module mixing | Copy-paste from different docs | Declare loading pattern upfront |
| `require` not available | Using ES module build | Use AMD CDN or full ES build, not mixed |
| Ground elevation conflict | SceneView default ground | Set `ground: "world-elevation"` or `null` for underground |
| Underground Z values | Screen space vs world space | Set `view.camera.position.z` to negative values for below-surface |

---

## THREE.JS FAILURE POINTS (pre-empt these)

| Failure | Cause | Fix |
|---|---|---|
| ShaderMaterial black/invisible | Wrong side | Set `side: THREE.DoubleSide` |
| Clipping plane not working | Not enabled on renderer | `renderer.localClippingEnabled = true` |
| Transparency ordering artifacts | Default depth write | `depthWrite: false` on transparent layers |
| GLSL uniform not updating | Forgot `.value` | `uniform.uTime.value = t` (not `uniform.uTime = t`) |
| Mobile WebGL crash | Too many draw calls | Merge geometries, limit particle count to ≤500 mobile |
| sRGB color mismatch | No encoding set | `renderer.outputEncoding = THREE.sRGBEncoding` |

---

## NVIROGEAR DEPTH SCALE STANDARD

```
Scale: 1 THREE.js unit = 8 ft (compress deep layers for visual clarity)
Total visual depth: 100 ft shown (bedrock compressed)
ftToY(ft) = -(ft * SCALE)    // negative = down
ftToH(ft) = ft * SCALE

Reference depths (Muskegon unconfined aquifer):
  0–1.5 ft   = Topsoil / Fill       (SM)
  1.5–8 ft   = Sandy Loam Subsoil   (SP-SM)
  8–25 ft    = Glacial Sand          (SP)  ← PFAS migration zone
  18–28 ft   = Water Table Zone     (seasonal high)
  25–45 ft   = Clay / Glacial Till  (CL)  ← confining layer
  45–80 ft   = Deep Sand/Gravel Aquifer (GW) ← municipal supply
  ~200 ft    = Bedrock (Carboniferous)
```

---

## WIRE MR. RESULTS INTO THE LOOP

When a 3D/GIS agent produces output:
1. Output goes to Mr. Results for review
2. Mr. Results checks: does it match real entity data? Are depths correct? Is confidence correctly labeled?
3. Mr. Results approves → patch goes into ALICE
4. Mr. Results rejects → flag reason, return to agent with correction

**No 3D geometry reaches ALICE Page 3 without Mr. Results sign-off.**

---

## QUICK-LOAD CHECKLIST

Before every 3D/GIS code task:
- [ ] System prompt injected (role + expertise)
- [ ] SubsurfaceLayer data pasted (real depths)
- [ ] ParcelRecord pasted (lat/lng, acreage, polygon)
- [ ] API pattern declared (AMD or ES module, not both)
- [ ] max_tokens ≥ 4096
- [ ] temperature ≤ 0.3
- [ ] Esri failure points pre-empted in prompt
- [ ] Confidence labels mandatory in output (MODELED / ADVISORY / VERIFIED)

---

*Generated by Mr. Results — Nvirogear Property Intelligence System*
*Powered by Nvirogear LLC*
