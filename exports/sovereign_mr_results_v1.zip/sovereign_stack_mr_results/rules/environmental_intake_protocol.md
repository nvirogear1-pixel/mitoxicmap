# ENVIRONMENTAL INTAKE PROTOCOL (GIS CENTROID MATCH MODE)
**Issued by:** Mr. Results (Overseer)
**Date:** 2026-04-05 (v2 — scope classification tightened)
**Status:** PERMANENT — applies to all environmental site returns from any bot

---

## PURPOSE

Environmental sites are NOT parcels.
They may span multiple parcels, have undefined boundaries, and carry risks that outlive ownership transfers.

This protocol governs how Mr. Results receives, classifies, and routes environmental site data returned by the Historian Bot (or any bot operating with environmental awareness).

**If a site has not cleared this intake, it does not advance. Period.**

---

## CLASSIFICATION REQUIREMENTS (PER SITE — ALL 5 REQUIRED)

Mr. Results MUST assign all five of the following on every environmental intake review:

---

### 1. `site_status`

| Value | Meaning |
|-------|---------|
| `ready_for_phase2` | Site confirmed with valid location anchor — advance to Phase 2 |
| `requires_environmental_boundary_resolution` | Site confirmed but boundary/scope is unclear — hold |
| `blocked_missing_location` | No usable address, parcel_id, OR coordinates — cannot proceed |
| `invalid_or_remove` | Source error, duplicate, or definitively not relevant — remove |

---

### 2. `environmental_site_type` — EVIDENCE-GATED

**This field must reflect what is PROVEN, not what is suspected.**

| Value | Use when |
|-------|---------|
| `single_parcel_site` | Regulatory documents confirm site is confined to one parcel |
| `multi_parcel_environmental_site` | One or more of these is TRUE and sourced: known regulatory subdivision of a multi-lot site; documented plume migration crossing parcel boundaries; source documents explicitly show multi-parcel extent; landfill/Superfund footprint proven broader than one parcel |
| `unknown_scope` | You have a confirmed parcel anchor and active contamination, but NO source document yet proves or disproves multi-parcel extent |

**Default for uncertain sites = `unknown_scope` with `risk_flags: ["boundary_unknown"]`**

Do NOT use `multi_parcel_environmental_site` as a precaution. Use it only when the evidence supports it.

---

### 3. `completeness_status`

| Value | Meaning |
|-------|---------|
| `complete` | All required location anchors and classification fields confirmed |
| `partial` | Some location data present, at least one anchor missing |
| `blocked` | No usable anchors, cannot proceed |

---

### 4. `risk_flags` (array — all applicable must be set)

| Flag | Trigger condition |
|------|---------|
| `post_sale_environmental_risk` | Contaminated site sold — new owner may carry remediation obligations unknowingly |
| `active_contamination` | Regulatory agency confirms active contamination |
| `historical_industrial_use` | Site has documented industrial history |
| `boundary_unknown` | Cannot confirm where contamination begins and ends |
| `data_gap_location` | No coordinates, parcel_id, or usable address |
| `multi_parcel_fragmentation` | Evidence exists that site spans or likely spans multiple parcels |

**`multi_parcel_fragmentation` and `multi_parcel_environmental_site` must be consistent.**
- If `environmental_site_type = unknown_scope`, use `boundary_unknown` — not `multi_parcel_fragmentation` unless evidence supports it.
- If `environmental_site_type = multi_parcel_environmental_site`, `multi_parcel_fragmentation` is required.

---

### 5. `next_action` (REQUIRED — no vague values permitted)

| Value | When to use |
|-------|-------------|
| `send_to_historian_phase2` | Confirmed location anchor → advance for deep investigation |
| `hold_for_boundary_mapping` | Confirmed but boundary unclear → block until scope resolved |
| `manual_gis_resolution_required` | Address known but parcel_id unresolvable without browser/manual lookup |
| `coordinate_recovery_required` | No location anchors at all |
| `remove_from_pipeline` | Invalid, duplicate, or irrelevant |

---

## SCOPE CLASSIFICATION EVIDENCE RULES

### `multi_parcel_environmental_site` — REQUIRES AT LEAST ONE:
1. Regulatory document (ROD, Consent Order, site map) shows footprint across multiple parcels
2. Confirmed off-parcel plume migration in EGLE/EPA record
3. Superfund site with documented multi-lot remediation boundary
4. Landfill with known acreage clearly exceeding confirmed parcel acreage
5. Historian Phase 2 return confirming off-parcel contamination

### `unknown_scope` — USE WHEN:
- Site is EGLE/Superfund/landfill/industrial AND
- You have a confirmed parcel anchor AND
- No source document yet proves or disproves multi-parcel extent

**`unknown_scope` with `boundary_unknown` flag is the honest state for most Phase 1 sites.**
Phase 2 is what upgrades `unknown_scope` to `multi_parcel_environmental_site` or `single_parcel_site`.

### `single_parcel_site` — REQUIRES:
- Regulatory documents explicitly confirm site is confined to one parcel, OR
- EGLE closure record confirms no off-parcel migration

---

## LOCATION VALIDATION LOGIC (HARD RULES)

### BLOCKED condition — ALL THREE must be absent:
- No `parcel_id` AND
- No usable `address` AND
- No `coordinates` (lat/lng)

→ Assign:
- `site_status`: `blocked_missing_location`
- `completeness_status`: `blocked`
- `next_action`: `coordinate_recovery_required`
- Risk flag: `data_gap_location`

### ADDRESS-ONLY WARNING:
An address alone is NOT a valid location anchor for a contaminated site when:
- The site footprint is known to be broader than a single address (Superfund, landfill, 100+ acre sites)
- Multiple parcels exist at the same address prefix
- The address is a road name only (no street number)

In these cases: set `completeness_status: partial`, not `complete`.

---

## POST-SALE RISK LOGIC

If a contaminated site has been sold (deed transfer on record after contamination confirmed):

→ MUST add:
- Risk flag: `post_sale_environmental_risk`
- Field: `requires_phase2_review: true`

---

## ENVIRONMENTAL SCOPE BLOCK (REQUIRED ON ALL SITES)

Every site must carry this block, regardless of scope classification:

```json
"environmental_scope": {
  "site_level": true,
  "parcel_level_confidence": "high | medium | low | unknown",
  "requires_plume_overlay": true | false
}
```

- `site_level: true` = contamination exists at the site
- `parcel_level_confidence` = how confident we are the parcel_id captures the full site
- `requires_plume_overlay: true` = Phase 2 must return boundary data before full gate clearance

---

## REQUIRED OUTPUT FORMAT (STRICT)

```json
{
  "intake_review": [
    {
      "site_key": "",
      "parcel_id": "",
      "site_status": "",
      "environmental_site_type": "",
      "completeness_status": "",
      "environmental_scope": {
        "site_level": false,
        "parcel_level_confidence": "unknown",
        "requires_plume_overlay": false
      },
      "risk_flags": [],
      "next_action": "",
      "requires_phase2_review": false,
      "notes": []
    }
  ],
  "run_summary": {
    "ready_for_phase2": 0,
    "requires_boundary_resolution": 0,
    "blocked_missing_location": 0,
    "invalid_or_remove": 0
  },
  "task_creations": [],
  "gate_decision": {
    "environmental_gate_status": "",
    "parcel_gate_status": "",
    "county_status": "",
    "reason": ""
  }
}
```

---

## GATE INTEGRATION (MANDATORY)

Environmental sub-gate runs BEFORE the parcel sub-gate. County cannot advance if:
- Any site is `blocked_missing_location` without a resolved OperationalTask
- Any `unknown_scope` site has no pending boundary resolution task
- Any `multi_parcel_environmental_site` is missing `environmental_scope` block
- Any site is missing `next_action`

---

## PRIORITY LOGIC

```
PASS FORWARD:   ready_for_phase2 only
HOLD:           requires_environmental_boundary_resolution
BLOCK:          blocked_missing_location
REMOVE:         invalid_or_remove
```

---

## MINDSET

> Contamination does not respect parcel lines.
> A confirmed parcel anchor is the start of investigation, not the end.
> unknown_scope is honest. multi_parcel_environmental_site is a conclusion — earn it.

Bad data forward = system failure.
Blocked data with clear next action = system success.

---

Generated by Mr. Results (Overseer) - Powered by Nvirogear LLC
N-ViroGear Land Intelligence System
