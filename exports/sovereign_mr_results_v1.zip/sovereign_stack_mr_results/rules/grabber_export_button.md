# Grabber Export Button — Exact Injection Guide
# Target: Badass Real Estate Grabber → ParcelMap page

## Data structure confirmed from source analysis:
# - features array state var: `ze` (set by `de(Be)`)
# - selectedCounty state var: look for county selection logic
# - Each feature is GeoJSON:
#     feature.properties.parcel_id  (normalized PIN)
#     feature.properties.owner
#     feature.properties.address
#     feature.properties.city
#     feature.properties.zip
#     feature.properties.acreage
#     feature.properties.county
#     feature.properties._raw      (raw ArcGIS fields)
#     feature.geometry             (GeoJSON polygon)
# - Debug state: `_` (setter), value shows url, count, status

## Button position:
# In the top bar JSX, right after the "debug" button element

## What to ADD to ParcelMap.jsx:

Add after the Layers button and debug button, before the status indicator div:

```jsx
{ze?.length > 0 && (
  <button
    onClick={() => {
      const date = new Date().toISOString().slice(0, 10);
      const countySlug = (selectedCounty || 'unknown').toLowerCase();
      const geojson = {
        type: 'FeatureCollection',
        metadata: {
          county: countySlug,
          state: 'MI',
          source: 'arcgis_grabber',
          exported_at: new Date().toISOString(),
          record_count: ze.length,
        },
        features: ze.map(f => ({
          type: 'Feature',
          geometry: f.geometry || null,
          properties: {
            parcel_id: f.properties?.parcel_id || '',
            owner: f.properties?.owner || null,
            address: f.properties?.address || null,
            city: f.properties?.city || null,
            zip: f.properties?.zip || null,
            acreage: f.properties?.acreage || null,
            county: countySlug,
            state: 'MI',
            source: 'arcgis_grabber',
            exported_at: new Date().toISOString(),
            ...f.properties?._raw,
          }
        }))
      };
      const blob = new Blob([JSON.stringify(geojson, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${countySlug}_MI_parcels_${date}.geojson`;
      a.click();
      URL.revokeObjectURL(url);
    }}
    style={{
      padding: '4px 10px',
      borderRadius: 4,
      border: '1px solid #00ff88',
      cursor: 'pointer',
      fontSize: 11,
      fontWeight: 700,
      background: '#0a1a0a',
      color: '#00ff88',
      whiteSpace: 'nowrap'
    }}
  >
    ⬇ GeoJSON ({ze.length.toLocaleString()})
  </button>
)}
```

## Ingest flow after download:
1. Click button → downloads `muskegon_MI_parcels_2026-04-12.geojson`
2. Upload file to Mr. Results chat
3. Mr. Results runs ingest script → writes to ParcelReference
4. Repeat per county

## receiveParcelBatch endpoint (alternative HTTP path):
POST https://mr-results-8ae25c59.base44.app/functions/receiveParcelBatch
