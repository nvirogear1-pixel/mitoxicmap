# Nvirogear Report Audit — Apple Dr Test Pair
## Source: AI Evaluator (External Review)
## Date: May 19, 2026
## Status: LOCKED — Actionable Findings

---

## VERDICT SUMMARY
**Current state:** Strong pre-diligence intelligence product — better than 90% of what agents or investors can pull themselves in 2 hours.
**Gap to $99–$199/report:** Environmental scan (EPA ECHO, EGLE, NWI, FEMA) + well/septic records must be auto-populated OR clearly sold as an upsell.
**Gap to CoreLogic/First American acquisition:** National coverage, API infrastructure, automated environmental/wetland pulls. 984K parcel database = solid Michigan foundation.

---

## WHAT'S WORKING — DO NOT BREAK

### 1. Parcel Identity Resolution (Best-in-Class)
- Actively cross-references 3 sources, catches AVM errors, resolves to authoritative county GIS
- Differentiator CoreLogic/First American don't offer in consumer-facing products
- PRESERVE THIS APPROACH IN ALL FUTURE REPORTS

### 2. Tax Uncapping Analysis (Critical for Michigan)
- TV/SEV gap (41.9%) with 3-scenario forward projections is sophisticated
- Most buyers and agents don't understand Michigan Headlee Amendment mechanics
- This is a genuine differentiator — deepen it

### 3. Source Confidence Ledger
- 19-entry traceability system with evidence labels = audit-ready, institutionally defensible
- MANDATORY on all future reports — no exceptions

### 4. Interactive Map with Layered Evidence
- Leaflet + toggleable layers + nearby parcel assemblage table = strong investor tool
- Spatial intelligence layer is a technical differentiator

---

## CRITICAL GAPS — MUST FIX BEFORE $99–$199 PRICING

### The Big 4 Environmental Auto-Pulls (MUST be automated, not PENDING)
These cannot be flagged as pending on a paid report for a 24-acre rural parcel.
Buyer paying $150K–$400K for 24 acres won't pay $150 for a report that says "environmental scan pending."

| Item | Priority | Source | Notes |
|---|---|---|---|
| EPA ECHO / EGLE MiEnviro radius scan | CRITICAL | echo.epa.gov + EGLE MiEnviro | PFAS risk in agricultural Ottawa County |
| FEMA flood zone confirmation | CRITICAL | msc.fema.gov | Affects financing/insurance |
| NWI wetlands delineation | CRITICAL | fws.gov NWI Mapper | Could eliminate 30-50% of usable acreage |
| Well/septic permit records | CRITICAL | Ottawa County Health Dept | Lender requirement, $15K-$30K replacement risk |

### Development Timing Projection Improvement
- Add "Confidence Interval" column (best/worst case ranges, not single-point estimates)
- Distinguish clearly: Hard costs (quotable) vs. Soft costs (estimable) vs. Market variables (inherently uncertain)

### Environmental Consultant Directory — Needs Expansion
Add these to the directory (currently thin for 24-acre rural):
- Licensed wetland delineators (Ottawa County / West Michigan)
- PFAS testing labs
- FEMA elevation certificate providers
- Septic designers (Ottawa County Health Dept has referral list)

### Visual History Module
- External link only = legally correct but user-friction-heavy
- Consider: thumbnail preview grid (Google Street View static, county aerials) loaded from public sources
- Add "Photo Gap Analysis" — what's missing (drone, interior, well head, septic field)

---

## SPECIFIC REPORT ADDITIONS (Prioritized)

### Priority 1 — Add Immediately
1. **"Action Items" Executive Summary** — one-page checklist of 5 things buyer must do next, ranked by cost and risk. Currently flags are scattered across tabs. Create a consolidated "Next Steps" card at the top of the Executive tab.

2. **Assemblage Math — Quantified**
   - Current: adjacent parcels table (good)
   - Missing: Combined SEV + Estimated Acquisition Cost column
   - Example: Subject $216K SEV + 013 $44K + 016 $35K = $295K combined SEV → market value if assembled
   - ADD THIS TO INVESTOR TAB

3. **Comparable Sales Section**
   - Pull 3–5 Ottawa County rural residential sales (gis-ottawacountymi.hub.arcgis.com sales dashboard)
   - Strengthens $250K–$380K market range estimate
   - Currently MODELED with no comp backing

4. **Trust/Estate Risk Flag — Deepened**
   - "Ruscett Ronald W-Sylvia P Trust" + Grand Haven apartment mailing = estate/trust administration signal
   - Add explicit "Probate/Estate Risk" flag
   - Recommend pulling trust instrument from Ottawa County ROD
   - This is a common deal-killer — make it prominent

### Priority 2 — Before Launch
5. Auto-pull EPA ECHO radius query for all reports
6. Auto-pull FEMA FIRM zone for all reports
7. Auto-pull FWS NWI for all reports
8. Create "Phase 1" vs "Phase 2" product tiers with environmental modules as upsells

---

## COMMERCIAL PATH — LOCKED FINDINGS

### $99–$199/Report Requirements
- [x] Parcel identity resolution (done)
- [x] Tax uncapping analysis (done)
- [x] Source confidence ledger (done)
- [x] Interactive map (done)
- [ ] Environmental auto-pulls (EPA ECHO, FEMA, NWI) — MUST ADD
- [ ] Well/septic permit records — MUST ADD or be upsell
- [ ] Comparable sales section — MUST ADD
- [ ] Action items executive summary — MUST ADD
- [ ] Assemblage math quantified — MUST ADD

### $5M–$25M Strategic Acquisition Requirements (CoreLogic/First American territory)
1. Coverage expansion — 984K Michigan parcels is strong foundation; national is table stakes
2. API/integration layer — title companies need REST APIs, not PDF reports
3. Environmental automation — EPA ECHO, EGLE, NWI, FEMA auto-pulled, not pending
4. Lender compliance — Fannie Mae/Freddie Mac data standards, ALTA requirements

---

## WHAT THIS MEANS FOR BUILD PRIORITIES

### Immediate (Pre-Launch)
1. Add consolidated "5 Next Steps" card to Executive tab of all reports
2. Add assemblage math with combined SEV + acquisition estimates to Investor tab
3. Add 3–5 comparable sales to Homeowner + Investor tabs
4. Deepen Trust/Estate risk flag with probate language
5. Expand Env Consultant Directory with wetland delineators, PFAS labs, FEMA cert providers

### Short-Term (60 Days)
6. Automate EPA ECHO radius query for all new reports
7. Automate FEMA FIRM zone pull for all new reports
8. Automate FWS NWI query for all rural reports
9. Build "Phase 1 / Phase 2" product tier structure
10. Add Comparable Sales as a module (pull from county sales data)

### Medium-Term (90–180 Days)
11. Build REST API layer for title company / lender integration
12. Map to Fannie Mae/Freddie Mac data standards
13. Begin coverage expansion beyond Michigan
14. Launch paid report ordering (ReportOrder entity + NDA gate already built)

---

*Nvirogear Report Audit v1.0 | Locked May 19, 2026 | Mr. Results — Nvirogear LLC*
