# NVIROGEAR BOT TEAM — MICHIGAN PARCEL COMPLETION DIRECTIVE
# Issued by: Joe Smith, Nvirogear LLC
# Date: 2026-07-10
# Status: ACTIVE — HIGHEST PRIORITY UNTIL COMPLETION

---

## MISSION STATUS: FINAL ACQUISITION PUSH

This becomes the highest priority for Base44 until completion.

The objective is NOT to build every ALICE feature.
The objective is to complete Michigan parcel acquisition so ALICE has a canonical Parcel Registry that every other system can build upon.

---

## PRIMARY DELIVERABLE

Acquire and stage parcel records for all 83 Michigan counties.

For every parcel, deliver at minimum:
- County
- Parcel ID (canonical local key)
- Address (if available)
- Owner (if public)
- Geometry (polygon preferred, centroid acceptable)
- Source information
- Acquisition timestamp
- Provenance metadata

If additional assessor attributes are available, capture them. If not, do not delay acquisition.

---

## SUCCESS CRITERIA

A county is considered COMPLETE when:
1. Public parcel inventory has been acquired
2. Duplicate detection has been performed
3. Provenance has been recorded
4. County manifest has been generated
5. Candidate dataset exported for local validation

Do not wait for AI enrichment, environmental overlays, historical timelines, reports, or advanced analysis.

---

## EXPLICITLY DEFERRED (do not start until statewide acquisition is complete)

- AI enrichment
- Timeline Engine population
- Environmental joins
- Part 201 linking
- PFAS overlays
- Infrastructure joins
- Report generation
- UI enhancements
- Automation beyond acquisition

If a task does not directly help acquire parcel inventories, postpone it.

---

## BLOCKER POLICY

NEVER STOP because one county has an issue.

If a county cannot be completed:
1. Record the blocker
2. Generate a blocker report
3. Continue immediately to the next county

Valid blocker types:
- Dead endpoint
- Paid dataset
- Missing GIS
- Geometry corruption
- Duplicate conflict

Progress across the rest of the state must continue.

---

## REQUIRED OUTPUT (per county)

- Michigan County Registry entry (status updated)
- Candidate Parcel Registry records
- County manifest (source, record count, hash, timestamp)
- Acquisition log entry
- Duplicate report (if duplicates found)
- Provenance manifest
- Blocker report (if blocked)

No canonical promotion required. Validation and promotion occur locally in Mr. Results and ALICE.

---

## COMPLETION CONDITION

The mission is complete when every Michigan county is in one of two states:
- CANDIDATE_DATASET_READY
- BLOCKED (with documented reason)

No county should remain NOT_STARTED.

Once complete, Base44 parcel acquisition mission is considered FINISHED and may be paused pending future assignments.

---

*Locked by Mr. Results (Overseer) — Nvirogear LLC — 2026-07-10*
