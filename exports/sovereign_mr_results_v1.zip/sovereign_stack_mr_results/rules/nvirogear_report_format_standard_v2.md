# NviroGear Property Intelligence Report — Master Template Standard
# Authority: Mr. Results (Overseer) — Nvirogear LLC
# Version: 2.1 — LOCKED June 27, 2026
# Status: GOVERNING — Applies to ALL reports, ALL locations, going forward
# Source: Two rounds of external professional review — June 27, 2026

---

## ORIGIN

Built from two professional reviews of NviroGear report output.
Round 1: Identified seven structural improvements.
Round 2: Elevated the format to a fully reusable product template —
applicable to Cadillac, Muskegon, Spring Lake, Flint, or any Michigan location.

This is not a one-off format. This IS the product.

---

## CORE DOCTRINE — NEVER VIOLATE

1. Facts and analysis are ALWAYS in separate, labeled sections.
2. Reduce certainty — present interpretations as possible explanations, never conclusions.
3. No legal determinations — identify questions, not outcomes.
4. Every parcel gets a confidence score.
5. Every section ends with a sources consulted block.
6. Every classification gets an actionable checklist.
7. Section names are standardized and locked.

---

## EVIDENCE COLOR SYSTEM — MANDATORY IN ALL REPORTS

Every statement in every report must be visually tagged with one of four colors.
A reader flipping through must instantly know what is fact vs. interpretation.

BLUE  — Verified Public Record
        Source: EGLE, EPA, County BS&A, official city/state portals, court records.
        Use for: Any data pulled directly from an official government or public record.

GREEN — NviroGear Findings
        Source: NviroGear fleet data, GIS pulls, parcel matching, scoring output.
        Use for: Data NviroGear has compiled, scored, or confirmed through its own tools.

AMBER — NviroGear Analysis
        Source: Interpretation of public record patterns. Clearly labeled as such.
        Use for: Observations, hypotheses, pattern assessments, comparative intelligence.
        NEVER present Amber content as fact. Always label explicitly.

RED   — Recommended Due Diligence / Risk Items
        Source: NviroGear assessment of what the reader should do next.
        Use for: Action checklists, risk register items, critical flags.

RULE: No statement may appear without a color tag.
      If the source is uncertain — it goes in Amber with a "NEEDS VERIFICATION" note.
      If the source cannot be identified at all — do not include the statement.

---

## EVIDENCE CONFIDENCE METER — EVERY SECTION

Every section header must include an Evidence Confidence label.
This is a signature NviroGear feature. It appears on every page.

FORMAT:
  Evidence Confidence: HIGH / GOOD / MODERATE / LIMITED / MINIMAL
  Last Verified: [date]
  Public Sources Reviewed: [number]
  Additional Verification Recommended: YES / NO

CONFIDENCE DEFINITIONS:
  HIGH     — All primary sources pulled and confirmed. No data gaps in this section.
  GOOD     — Most primary sources confirmed. One or two items are PUBLIC REFERENCE.
  MODERATE — Key sources confirmed. Some gaps noted with NOT PULLED labels.
  LIMITED  — Foundational data present but significant gaps exist.
  MINIMAL  — Preliminary data only. This section requires substantial additional pull.

RULE: Confidence is section-specific, not report-wide.
      S2 may be HIGH while S4 is MODERATE. Show both accurately.
      Do not inflate confidence to appear more complete than you are.

---

## DEFENSIBLE LANGUAGE — MANDATORY SUBSTITUTIONS

BANNED:                                 REQUIRED REPLACEMENT:
"The contamination discount             "Documented contamination may be a factor
 is MANDATORY..."                        that supports an assessment review under
                                         applicable Michigan law."

"Assessors avoid doing this             "Assessment practices can vary by
 proactively."                           jurisdiction, and contamination adjustments
                                         may require additional supporting evidence."

"Assessor catching up on               "The reassessment pattern may be consistent
 suppressed value."                      with a property previously assessed below
                                         current market conditions. Additional
                                         assessor records would be needed to
                                         determine the cause."

"This will win at the Tax Tribunal."   "Property owners in similar situations have
                                         pursued assessment reviews — consult a
                                         licensed Michigan property tax professional
                                         to evaluate applicability to your situation."

"The area is clean."                   "No [program] sites identified within [radius]
                                         in reviewed public records as of [date].
                                         This does not constitute a Phase I ESA."

"No contamination found."              Same as above — never say "found" or "clean."

"You have grounds to appeal."          "This pattern may provide grounds to discuss
                                         an assessment review with a qualified property
                                         tax professional or attorney."

"Strong Buy / Extreme Value"           "High-Upside Candidate — Conditional Review
                                         Required."

---

## SECTION NAMING — LOCKED

"What This Means" is BANNED as a section title.

Use ONLY one of these four approved alternatives:
  NviroGear Assessment
  Operational Assessment
  Decision Support Analysis
  Intelligence Summary

These titles correctly communicate that the content is NviroGear's analysis —
not an official conclusion from a licensed professional or government agency.

---

## BRANDED FOOTER — EVERY PAGE

Every page of every report must carry this footer (or a condensed version):

  NviroGear LLC  •  Public Record Intelligence Platform
  Public records organized into evidence-linked decision support.
  [Version]  •  [Date]  •  Evidence Confidence: [level]  •  Report ID: [NVG-LOCATION-YYYYMMDD]

This footer is not optional. It establishes consistent product identity
regardless of subject matter — PFAS, lift stations, municipal compliance,
parcel intelligence, or infrastructure.

---

## THE 12-SECTION MASTER TEMPLATE

Every NviroGear Property Intelligence Report uses these sections in this order.
Section names are LOCKED. Do not rename, reorder, or omit without Governor approval.

---

### S1 — EXECUTIVE SUMMARY
One-page overview only. Contains:
- Property or area identity (address, APN, county, jurisdiction)
- Top environmental findings (confirmed only — no interpretation)
- Current status (LIVE OPPORTUNITY / WATCHLIST / NOT CLEARED / POST-AUCTION CASE STUDY)
- Confidence score (★ to ★★★★★) and Evidence Confidence level
- One-sentence NviroGear positioning statement
- What this report does NOT do (appraisal / legal / Phase I)

RULE: Executive Summary is BLUE only — facts and status.
      No Amber content. No analysis. No conclusions.
      A reader must be able to hand S1 to anyone and have it be defensible.

---

### S2 — ENVIRONMENTAL PROFILE
Source: EGLE MPART, EPA ECHO, EPA NPL, FEMA NFHL. All BLUE or labeled NOT PULLED.

Contains:
- All confirmed contamination sites within screening radius (default 1 mile)
- Site name, regulatory program, contaminant type, status, distance
- PFAS AOI status (active / closed / not applicable)
- Flood zone (FEMA zone, panel number, effective date)
- Wetlands (NWI layer if applicable)
- Confidence badge per item

BANNED: "The area is clean." / "No contamination."
REQUIRED: "No [program] sites identified within [radius] in reviewed public records as of [date].
           This does not constitute a Phase I Environmental Site Assessment."

Evidence Confidence meter required at section header.
Sources Consulted block required at end of section.

---

### S3 — WATER SUPPLY PROFILE
Source: County health dept, city utilities, MPART well data, MLS.

Contains:
- Public water: AVAILABLE / NEARBY / UNAVAILABLE / UNKNOWN — source cited
- Private well: CONFIRMED / LIKELY / UNKNOWN — source cited
- PFAS well test results (if available from MPART)
- Bottled water / filter program status (if applicable)
- Water main extension plans (if documented)
- Evidence Confidence meter at section header

REQUIRED DISCLAIMER (verbatim when private well present):
"Private well water quality must be verified by independent laboratory testing
prior to any property decision. PFAS, nitrates, coliform, and other parameters
should be included in the test panel. Contact the county health department
or a certified laboratory for current testing requirements."

Sources Consulted block required at end of section.

---

### S4 — TAX & ASSESSMENT HISTORY
Source: County BS&A, county equalization, Zillow/Redfin (PUBLIC REFERENCE labeled).

Contains:
- Current SEV (State Equalized Value) — source and date
- Current Taxable Value — source and date
- 3-year SEV history table (year / SEV / % change)
- 3-year tax bill history (year / taxes billed / % change)
- Last sale date and price — label PUBLIC REFERENCE if from AVM
- Uncapping flag if sale detected
- Delinquency status (if available from BS&A)
- Evidence Confidence meter at section header

BANNED: "Assessor catching up." / "Contamination discount applied."
REQUIRED: "The [X]% SEV increase may be consistent with [possible explanation A],
           [possible explanation B], or other factors including renovations, sales,
           equalization adjustments, or local market appreciation. Additional
           assessor records would be needed to determine the cause."

REQUIRED when contamination confirmed but parcel pull not done:
"Based on preliminary review, some properties in [area] may not yet reflect any
market effects associated with known [environmental concern]. Additional
parcel-by-parcel assessment review is recommended."

Sources Consulted block required at end of section.

---

### S5 — MARKET ACTIVITY
Source: MLS, Zillow, Redfin, county GIS sales data. ALL labeled PUBLIC REFERENCE.

Contains:
- Last known sale (date, price, source)
- AVM estimates — labeled PUBLIC REFERENCE
- Comparable sales — labeled PUBLIC REFERENCE
- Days on market (if available)
- Evidence Confidence meter at section header

REQUIRED AVM DISCLAIMER (verbatim):
"AVM estimates are provided as public reference data only. They are not
relied upon as final valuation. AVM accuracy varies materially by property
type, data freshness, and local market conditions. A licensed Michigan
appraisal is required for financing, legal, or investment decisions."

Sources Consulted block required at end of section.

---

### S6 — ENVIRONMENTAL SITE MAP
Every report must include or reference a map with:
- Subject parcel or area boundary
- 1-mile radius ring
- All confirmed EGLE/EPA sites labeled with name, distance, status badge
- PFAS AOI boundary (if applicable)
- Flood zone overlay (if applicable)
- Legend with badge definitions
- Interactive HTML version produced whenever possible

If no interactive map is produced: include a written site relationship table.

---

### S7 — RISK FACTORS
Contains confirmed risk items only. Each item must have:
- Risk ID (RISK-001 format)
- Category (Environmental / Tax / Title / Physical / Access / Market)
- Description (plain English — specific to this property or area)
- Severity: HIGH / MODERATE / LOW
- Evidence source (color-tagged BLUE or GREEN)
- Status: OPEN / ADVISORY / RESOLVED
- Evidence Confidence meter at section header

BANNED: Probability percentages without documented basis.
BANNED: Dollar impact estimates without sourced comparables.

Sources Consulted block required at end of section.

---

### S8 — RECOMMENDED DUE DILIGENCE
RED section — action items only. Every item must include:
- Specific action (imperative — what to do)
- Who to contact (office name, phone, URL)
- Cost estimate (if known)
- Why it matters (one sentence)

Audience-specific subsections when applicable:
- For buyers / For municipalities / For lenders / For current owners

RULE: This section is the product. The checklist is what the reader does Monday morning.
      Generic checklists are not acceptable. Every item must be specific to this report.

---

### S9 — SOURCES CONSULTED
Full ledger. One entry per data claim. Required fields per entry:
- Source name
- Source type: OFFICIAL (BLUE) / PUBLIC REFERENCE (BLUE) / NVIROGEAR FINDING (GREEN) /
              NVIROGEAR ANALYSIS (AMBER) / NOT PULLED
- What it provided
- Date accessed or "not pulled — recommended"
- Limitation (what this source does NOT cover)

Last Verified: [date]
Data Currency Note: "All data reflects conditions as of the date noted above.
Conditions may have changed. Verify with original sources before any decision."

---

### S10 — NVIROGEAR ANALYSIS  [AMBER SECTION]
Title must be one of: NviroGear Assessment / Operational Assessment /
                      Decision Support Analysis / Intelligence Summary

MANDATORY HEADER (verbatim, every time):
"The following section contains NviroGear's interpretation of the data compiled
in this report. These are observations and hypotheses — not certified findings.
They identify questions to investigate with licensed professionals."

Contains:
- Observed patterns (phrased as possibilities, not conclusions)
- Comparative intelligence (other similar cases in NviroGear system)
- Questions identified for further investigation
- Hypothesis statements (labeled as such)

BANNED IN THIS SECTION: Legal conclusions / appraisal determinations /
                         definitive causal statements / any BANNED phrase.

---

### S11 — REPORT LIMITATIONS
Every report must explicitly state what it does NOT cover.

Standard limitations (always include):
- This report is not a Phase I Environmental Site Assessment (ASTM E1527-21)
- This report is not a licensed appraisal
- This report is not legal advice
- This report does not constitute a title search
- AVM data is public reference — not relied upon as final valuation
- Assessment observations are not certified by a licensed assessor
- PFAS proximity does not confirm parcel-level contamination without well testing
- Data reflects conditions as of [date] — conditions may have changed

---

### S12 — LAST VERIFIED DATE + EXPIRATION NOTICE
Every report must include:

"Report Date: [date]
Data Current As Of: [date]
Recommended Re-verification: 90 days from report date
Report ID: NVG-[LOCATION]-[YYYYMMDD]

This report expires 90 days from the date above. Environmental conditions,
regulatory status, tax assessments, and market data change. NviroGear
recommends re-verification before any decision made more than 90 days
after report date."

---

## AUDIENCE VARIANTS — SAME TEMPLATE, DIFFERENT LENS

The 12-section template is fixed. The DEPTH and EMPHASIS per section varies by audience:

BUYER REPORT:       S4/S5/S8 deepest. S10 focused on acquisition risk questions.
MUNICIPALITY REPORT: S2/S3/S7 deepest. S8 focused on regulatory compliance steps.
LENDER REPORT:      S4/S5/S7 deepest. S8 focused on title, appraisal, Phase I requirements.
HOMEOWNER REPORT:   S3/S4/S8 deepest. Plain English throughout. S10 focused on options.
INVESTOR REPORT:    S5/S7/S10 deepest. Deal math in S10, not in verified sections.

---

## BANNED PHRASES — PERMANENT LIST

"The area is clean." / "No contamination found." / "This is a good deal."
"You should buy this." / "Assessor catching up on suppressed value."
"Contamination discount finally hitting the roll." / "You have grounds to appeal."
"This wins at the Tax Tribunal." / "Courts ruled you are entitled."
"The property is clear." / "Strong Buy." / "Extreme Value." / "High Value."
"What This Means" (as a section title)
"The contamination discount is MANDATORY"
"Assessors avoid doing this proactively"
[Any phrase implying certainty without a VERIFIED BLUE source badge]

---

## MISS DIG INTEGRATION — STANDARD FRAMING

When the MISS DIG / contamination overlay concept is discussed in any report:

REQUIRED FRAMING:
"This capability is designed as decision support that complements — not replaces —
required safety processes including 811 notifications and applicable regulatory
requirements. NviroGear overlays publicly available environmental data with
publicly available excavation data to support planning and awareness."

NEVER frame it as: replacing MISS DIG / guaranteeing safety / a regulatory compliance tool.

---

## PRODUCT POSITIONING — LOCKED

NviroGear is a Property Intelligence Platform.

It brings together:
  Environmental records | Tax history | Assessment history
  Market activity | Infrastructure context | Public records
  Decision-support reporting

It is NOT: an appraisal service / legal service / environmental consulting firm / engineering firm.

It IS: a decision-support tool that helps users identify questions to investigate
before engaging licensed professionals.

GOVERNING PHRASE (required in every report footer):
"NviroGear LLC  •  Public Record Intelligence Platform
Public records organized into evidence-linked decision support.
[Version]  •  [Date]  •  Evidence Confidence: [level]  •  Report ID: [NVG-LOCATION-YYYYMMDD]"

---

## REGARDING NAMED INDIVIDUALS IN REPORTS

If a named individual (mayor, council member, official) is referenced:
- Use their name and title ONLY if confirmed by a dated public record source
- Badge it: [PUBLIC RECORD — source name, date]
- If identity is uncertain or multiple individuals may fit — omit or state
  "identity not confirmed in reviewed records"
- Never assume a conflict between two possible identities without evidence

---

## ENFORCEMENT — MR. RESULTS GATE

A report does NOT pass gate if:
- Any section lacks the Evidence Confidence meter
- Facts and analysis are blended in the same section
- Certainty language used without VERIFIED BLUE source badge
- Legal conclusions stated rather than flagged for professional review
- Confidence score missing from any parcel
- Data provenance block missing from any section
- Classification label present without Recommended Due Diligence checklist
- Section names deviate from S1–S12 standard
- "What This Means" used as a section title
- Any named individual stated as fact without public record confirmation
- Any banned phrase present
- Footer missing from any page
- Color system not applied

---

*Mr. Results (Overseer) — Nvirogear LLC*
*Report Format Standard v2.1 — LOCKED June 27, 2026*
*Source: Two rounds of external professional review*
*Applies to: Cadillac, Muskegon, Spring Lake, Flint, and all future NviroGear reports*
