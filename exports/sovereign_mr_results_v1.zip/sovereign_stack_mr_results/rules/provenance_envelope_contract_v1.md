# PROVENANCE ENVELOPE CONTRACT v1.0
**Status:** LOCKED 2026-09-05 | GOVERNING — applies to every bot, every lane, every emission
**Authority:** Joe Smith, Nvirogear LLC | Issued by: Mr. Results (Overseer)
**Implements:** ALICE_LAND_DATA_MASTER Structure Doctrine v1.1 — relationship/blend layer

---

## LANE SEPARATION LAW (GOVERNING)

1. Each bot works its own lane INDEPENDENTLY first. No merged answers before the blend.
2. Every bot preserves exactly what it pulled, from which URL, under which run ID, with its own hashes and its own interpretation.
3. The blend happens LATER, at the registry/relationship layer — **by reference, never by erasing separate bot histories.**
4. The registry never overwrites bot provenance.
5. Disagreement between lanes is EVIDENCE, not noise. Different acreage, ownership, or polygon candidates from different bots are preserved and surfaced as conflicts — never silently reconciled.

## THE LANES

```
JET            → GIS pulls, source URLs, polygon candidates, geometry hashes, geometry conflicts
HISTORIAN      → deeds/plats/historical records, historian_record_keys, parcel match candidates
ENVIRONMENTAL  → PFAS/wells/contamination/permits/samples, environmental_record_keys, spatial relationships
BUILDER        → canonical parcel identity, corpus/run stamps — never overwrites bot provenance
                  ↓ later
BLEND / RELATIONSHIP GRAPH
  canonical_key ↔ Jet geometry ↔ Historian records ↔ environmental evidence
               ↔ permits ↔ samples ↔ tax ↔ infrastructure
```

## THE PROVENANCE ENVELOPE (MANDATORY — EVERY BOT OUTPUT)

Every record every bot emits into the blend MUST carry this envelope:

```json
{
  "agent_id": "jet",
  "agent_run_id": "jet_20260905_...",
  "record_family": "geometry",
  "source_url": "...",
  "source_record_id": "...",
  "retrieved_at": "ISO-8601",
  "source_sha256": "...",
  "canonical_key_candidate": "MI_<County>_<normalized_parcel_id>",
  "match_method": "parcel_id | spatial | address | manual",
  "confidence": 1.0
}
```

### Field rules
- `agent_id` — one of: jet | historian | environmental | builder | browser | site_tracker
- `agent_run_id` — bot's own run identifier, unique per execution
- `record_family` — geometry | historian | environmental | permit | sample | tax | infrastructure | registry
- `source_url` — the exact URL the record was pulled from, never an aggregator
- `source_record_id` — the source system's own ID for the record
- `retrieved_at` — when THAT BOT pulled it
- `source_sha256` — hash of the source artifact AS RECEIVED by that bot
- `canonical_key_candidate` — registry format `MI_<County>_<normalized_parcel_id>` (pipe form `MI|County|id` is normalized to underscores at the registry boundary; both accepted at intake)
- `match_method` — `parcel_id` (direct key match) | `spatial` (inference from geometry/coordinates) | `address` | `manual`. Spatial inference MUST be labeled spatial — never presented as a direct key match.
- `confidence` — 0.0–1.0, the bot's own assessment

## THE SIX PROVENANCE QUESTIONS (MUST BE ANSWERABLE FOR EVERY BLENDED FACT)

For any fact shown in ALICE, the system must be able to answer:
1. Which bot found this?
2. What URL did it come from?
3. When was it pulled?
4. What did that bot originally say?
5. What hash did that source artifact have?
6. Was this a direct key match or a spatial inference?

A fact that cannot answer all six is NOT eligible for the blend.

## BLEND MECHANICS (RELATIONSHIP LAYER)

- Blending = writing edges into the relationship graph: `parcel_key ↔ <bot evidence>`
- Each edge carries the full provenance envelope of the emitting bot.
- Multiple bots may write multiple edges to the same canonical key — all preserved.
- Contradictions (same field, different values, different lanes) → ConflictRecord with BOTH envelopes attached.
- Nothing is deleted. Nothing is overwritten. Corrections are new records that supersede by reference, with the supersession recorded.

## MR. RESULTS HARD-STOP VALIDATOR (extends Bot Output Enforcement Contract v3)

Any bot output is REJECTED if:
1. The envelope is missing any required field.
2. `canonical_key_candidate` is empty AND `match_method` is not "spatial".
3. `match_method` = "parcel_id" but the key does not normalize to registry format.
4. `confidence` is outside 0.0–1.0 or absent.
5. `source_sha256` is absent or empty.
6. The output claims to "resolve" or "clean" a conflict recorded by another lane.

Rejection = the output did not happen. Retry once under strict mode; second failure = failed_real.

## REGISTRY-SIDE PROVENANCE (BUILDER LANE)

The canonical registry already answers the six questions per record:
- `run_id` → agent_run_id | `source_refs[].intake_ref` + `source_sha256` at the intake ledger → source_url/hash
- `member_record_seqs` → exactly which source records formed the identity
- `collisions.jsonl` → every multi-record collapse, logged
- `geometry_conflict_ledger.jsonl` → every geometry conflict with ALL candidates preserved
Builder emissions into the blend (registry stamps) use the same envelope with `agent_id: "builder"`, `record_family: "registry"`.

## ROLLOUT ORDER

1. Jet — geometry lane (envelope on all polygon candidates + conflict ledger verification)
2. Historian — historical/deed lane (envelope on all parcel match candidates)
3. Environmental lane — envelope on environmental/permit/sample records
4. Browser/site_tracker — envelope on all findings

Each lane builds its OWN validation spec, matcher, and proof — only the envelope is shared.

---

*PROVENANCE ENVELOPE CONTRACT v1.0 | LOCKED 2026-09-05 | Authority: Joe Smith, Nvirogear LLC*
*Issued by Mr. Results (Overseer) — Powered by Nvirogear LLC*
