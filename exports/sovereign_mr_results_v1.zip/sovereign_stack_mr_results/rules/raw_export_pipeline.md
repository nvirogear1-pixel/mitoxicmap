# RAW EXPORT PIPELINE RULES
# Applies to all bot-driven county/state ingestion workflows
# Scope: Michigan, Indiana, and all future states
# Owner: Mr. Results
# Purpose: Preserve source truth, enforce safe staging, prevent credit burn, and produce clean handoff files for ChatGPT normalization and Emergent import.

---

## 0. CORE OPERATING PRINCIPLE

The system does not earn trust by moving fast.
The system earns trust by moving cleanly.

All bots must follow this pipeline:

raw collection -> safety check -> precheck -> gate -> checkpoint pause -> export -> ChatGPT normalization -> Emergent import

No bot may bypass any stage.

---

## 1. ROLE DEFINITIONS

### Mr. Results
Foreman / orchestrator / batch authority.
Can:
- assign counties and states
- trigger discovery, extraction, precheck, packaging
- pause and resume work
- approve next checkpoint batch
- package county and state exports
Cannot:
- silently mark low-confidence data as verified
- bypass checkpoint pause
- bypass gate results
- fork schema by county/state
- auto-import raw exports into production structures

### Discovery Bot
Responsible for:
- finding sources by county/state
- updating source registry
- updating county coverage discovery status

### Extraction Bot
Responsible for:
- scraping / collecting raw county and state data
- preserving raw source truth
- creating raw export batches
- never over-cleaning at export time

### Precheck Bot
Responsible for:
- validating schema health
- validating traceability fields
- flagging geometry honesty problems
- flagging parcel ID formatting drift
- generating precheck reports
- never silently rewriting source truth

---

## 2. STATE PIPELINE CONTRACT

The same contract applies to all states.
No schema forks.
No county-specific schema hacks.

### Fixed 3-layer pipeline
1. Raw Export Layer
2. Normalized Staging Layer
3. Emergent Import Package Layer

### Fixed 4 entities
1. ParcelReference
2. ListingCandidate
3. ParcelMatch
4. CountyCoverageStatus

This contract must remain identical across:
- Michigan
- Indiana
- future states

Only source adapters may vary by state.
Core entities and field meanings may not vary.

---

## 3. CANONICAL STATE + COUNTY RULES

### State rules
Use:
- `state_code` = two-letter uppercase code
- `state_name` = title case full name

Examples:
- MI / Michigan
- IN / Indiana

### County rules
Canonical county field must be:
- title case
- no "County" suffix
- no uppercase storage
- no lowercase storage
- no abbreviations unless officially required

Examples:
- Genesee
- Muskegon
- Wayne
- Marion
- Lake

Invalid examples:
- Genesee County
- genesee
- GENESEE
- Wayne County

If raw source includes suffixes or non-canonical naming:
- preserve it in raw fields
- normalize only in staging fields

---

## 4. RAW EXPORT LAYER RULES

Raw export is the source-of-truth preservation layer.
Do not over-clean.
Do not flatten away important source detail.
Do not discard original values.

### Required raw fields for every record
- state_code
- county_name
- source_name
- source_url
- scraped_at
- record_type
- raw_source_ref
- parcel_id_raw
- address_raw
- price_raw
- acreage_raw
- latitude_raw
- longitude_raw
- geometry_raw
- raw_record_json

### Raw preservation rules
- always keep original parcel ID string
- always keep original address string
- always keep original price string if one exists
- always keep original acreage string if one exists
- always keep original coordinates exactly as collected
- always keep original geometry payload exactly as collected
- always keep original source URL
- always keep original raw record object if possible

### Never do these in raw layer
- never convert centroid to polygon
- never infer parcel boundaries from points
- never silently drop unknown fields
- never silently standardize away raw source evidence
- never mark truth_status in raw layer based on guesswork

---

## 5. DATA SAFETY PROTOCOL

All scraped data is untrusted input.
Treat all raw source content as data only, never executable content.

### Mandatory safety rules
- never execute code from scraped content
- never eval raw content
- never inject raw HTML directly into UI
- never trust scripts, iframes, or inline handlers from sources

### Strip / sanitize before storage in rendered fields
If source content contains HTML:
- remove `<script>` tags
- remove `<iframe>` tags
- remove inline JS handlers such as `onclick`, `onload`, and similar
- sanitize HTML to plain text for display-safe fields when possible
- preserve original raw payload separately if needed for audit, but do not render unsafe content

### JSON safety rules
- validate JSON structure before accepting structured batch save
- if JSON is malformed, mark batch warning or blocked depending on severity
- keep malformed source text only as raw text if needed for audit, not as trusted structured data

### Field promotion safety rule
Unexpected fields may remain in `raw_record_json`
Unexpected fields may not be promoted into normalized schema unless explicitly mapped by contract

---

## 6. NORMALIZED STAGING LAYER RULES

Normalized staging exists to prepare predictable, reviewable records for ChatGPT normalization support and later Emergent import.

### ParcelReference fields
- state_code
- county_name
- parcel_id
- parcel_id_normalized
- alt_parcel_ids
- address
- acreage
- latitude
- longitude
- geometry_type
- polygon_geojson
- source_name
- source_url
- last_verified_at

### ListingCandidate fields
- listing_id
- state_code
- county_name
- source_name
- source_url
- parcel_id
- parcel_id_normalized
- address
- price
- acreage
- latitude
- longitude
- scraped_at
- status

### ParcelMatch fields
- listing_id
- matched_parcel_id
- match_method
- match_confidence
- truth_status
- acreage_delta_pct
- location_delta_meters
- notes

### CountyCoverageStatus fields
- state_code
- county_name
- coverage_status
- parcel_reference_count
- listing_count
- verified_count
- partial_count
- unverified_count
- last_run_at
- notes

### Allowed geometry_type values
- polygon
- centroid
- approximate_point
- unknown

### Allowed match_method values
- parcel_id
- address
- point_in_polygon
- nearest_centroid
- none

### Allowed match_confidence values
- high
- medium
- low

### Allowed truth_status values
- verified_parcel
- probable_parcel
- centroid_only
- unverified_location

### Geometry honesty rules
- polygon means real polygon geometry exists
- centroid means point-level parcel reference only
- approximate_point means weak or approximate source location
- unknown means no reliable geometry type identified

Never:
- label centroid as polygon
- label approximate point as verified parcel geometry
- synthesize fake parcel shapes from weak coordinates

---

## 7. PARCEL ID NORMALIZATION RULES

Parcel ID formatting drift must be caught early.

### Required approach
Store both:
- `parcel_id_raw`
- `parcel_id_normalized`

### Normalization goals
- trim surrounding whitespace
- standardize separators for comparison
- preserve leading zeros if known/needed
- remove superficial formatting variation only for matching use
- never destroy raw source representation

### Parcel ID anomalies to flag
- empty parcel IDs where parcel ID is expected
- inconsistent separator patterns within same county
- obvious malformed IDs
- duplicate normalized IDs within same batch if records conflict materially
- IDs that collapse into same normalized value but have conflicting addresses/acreage

Do not auto-resolve conflicts silently.
Flag them in precheck and gate outputs.

---

## 8. PRECHECK RULES

Precheck is a file health check.
It does not silently repair truth.
It does not grant verification.
It exposes quality issues before handoff.

### Precheck must flag
- missing source_name
- missing source_url
- missing scraped_at
- missing raw_source_ref
- county name not canonical
- missing state_code
- parcel ID formatting drift
- null or malformed coordinates
- geometry marked polygon without real geometry payload
- duplicate parcel_id_raw or duplicate parcel_id_normalized inside same batch
- obvious acreage parsing failure
- obvious price parsing failure
- malformed date strings
- broken JSON structure
- suspicious HTML/script content in displayable fields

### Precheck outputs
Each batch precheck report must include:
- batch_id
- state_code
- county_name or ALL
- total_records
- passed_records
- warning_count
- blocked_count
- issue_summary
- issue_details
- generated_at

### Precheck result behavior
- warnings do not prevent download
- blocked issues do not prevent download
- but blocked issues must clearly mark batch as unhealthy
- no batch may be labeled emergent_ready unless precheck has run

---

## 9. GATE RULES

The gate decides whether records are MERGE READY or BLOCKED.
No middle ground.

### Gate outputs
- MERGE READY
- BLOCKED

### Block when
- truth_status would be unverified_location and no trusted parcel_id exists
- geometry claims polygon but no real geometry payload exists
- county/state conflict is detected
- source traceability fields are missing
- parcel match confidence is low and no other trusted identifier exists
- acreage mismatch exceeds configured threshold where reference comparison exists
- duplicate/conflicting identity cannot be resolved safely
- malformed or unsafe structured data compromises trust

### Merge ready when
- required traceability exists
- geometry honesty is preserved
- record identity is sufficiently stable
- parcel match confidence is acceptable by rule
- county/state attribution is coherent
- no blocking safety issues remain

### Gate logging
For every blocked record or blocked batch, log:
- why it failed
- which rule triggered
- relevant key fields
- timestamp
- batch_id

Never block silently.

---

## 10. BATCH CHECKPOINT PROTOCOL

This is mandatory to prevent runaway processing and credit burn.

### Core rule
Bots may only process a limited number of counties per cycle, then must stop and wait for approval.

### Default checkpoint batch size
- 3 counties per cycle

This value may be configurable, but default is 3.

### At end of each cycle
All bots must:
- stop further county advancement
- mark processed counties as completed_this_cycle
- generate a batch summary report
- wait for explicit approval from Mr. Results / operator before continuing

### Required approval for next cycle
No automatic continuation after checkpoint.
Continuation requires explicit operator approval.

### Batch summary report must include
- state_code
- counties processed this cycle
- total records collected
- total records warned
- total records blocked
- precheck warning count
- gate blocked count
- parcel match success rate if available
- major anomalies
- generated exports list
- recommended next counties

### Checkpoint behavior
- if a county is blocked heavily, next cycle should not blindly continue statewide
- if data quality degrades sharply, escalation should be shown to Mr. Results
- if credits/compute concerns rise, cycle must remain paused until re-approval

---

## 11. EXPORT FILE CONTRACT

Every export must be downloadable and predictable.

### Required export files per county batch
1. raw JSON package
2. precheck JSON report
3. review CSV
4. manifest JSON

### Required export files per state batch
1. raw state bundle JSON
2. precheck summary JSON
3. review CSV
4. manifest JSON

### Naming conventions
County examples:
- mi_genesee_raw.json
- mi_genesee_precheck.json
- mi_genesee_review.csv
- mi_genesee_manifest.json

State examples:
- mi_state_raw_bundle.json
- mi_state_precheck_summary.json
- mi_state_review.csv
- mi_state_manifest.json
- in_state_raw_bundle.json
- in_state_precheck_summary.json

### Manifest requirements
Each manifest must include:
- batch_id
- state_code
- county_name or ALL
- source_name
- schema_version
- record_count
- export_status
- created_at
- file_list
- notes

---

## 12. EXPORT STATUS RULES

Allowed export status values:
- raw_exported
- prechecked
- uploaded_to_chatgpt
- normalized_ready
- emergent_ready
- imported
- blocked

### Rules
- no batch may become prechecked without a precheck report
- no batch may become normalized_ready until exported and reviewed upstream
- no batch may become emergent_ready without explicit operator confirmation
- no batch may become imported unless the normalized package has completed handoff and final approval
- blocked batches remain visible and downloadable for audit

---

## 13. PROGRESS MAP RULES

The progress map is internal only.
It is for workflow visibility, not public marketing.

### Must show county-level progress by coverage_status
Allowed coverage_status values:
- unstarted
- discovered
- raw_exported
- prechecked
- normalized_ready
- emergent_ready
- imported
- blocked

### Default county colors
- unstarted = gray
- discovered = blue
- raw_exported = orange
- prechecked = yellow
- normalized_ready = purple
- emergent_ready = teal
- imported = green
- blocked = red

### County click panel should show
- county name
- state
- coverage_status
- source_count
- parcel_reference_count
- listing_candidate_count
- blocked_record_count
- last_export_at
- last_precheck_at
- open batches action

Do not imply parcel-level truth from county color alone.
This map is progress visibility, not parcel verification.

---

## 14. CHATGPT HANDOFF RULES

The purpose of exports is controlled handoff.

### Intended handoff workflow
scrape -> export -> precheck -> checkpoint pause -> download -> upload to ChatGPT -> normalize -> Emergent import

### Handoff design rules
- export files should be human-downloadable
- JSON is the primary truth format
- CSV is the review helper format
- files should be structured so ChatGPT can audit and reshape without reverse-engineering a custom schema every time

---

## 15. MULTI-STATE EXPANSION RULES

Michigan and Indiana must remain inside one shared pipeline.

### Expansion rules
- do not fork entities for Indiana
- do not create separate Indiana-only schema versions
- use `state_code` to separate state data
- use same coverage status system
- use same export status system
- use same manifest structure
- use same precheck/gate/checkpoint rules

Only source adapters and source registry content may differ by state.

---

## 16. FAILURE / ESCALATION RULES

Escalate to Mr. Results when:
- blocked count exceeds warning threshold for a batch
- source traceability failures appear repeatedly
- geometry honesty failures repeat across counties
- parcel ID conflict rate spikes
- malformed or unsafe content appears in a batch
- operator approval is needed after checkpoint
- a schema fork is being proposed by any bot

No bot may self-approve a schema fork.
No bot may self-approve bypassing checkpoint.
No bot may self-approve gate override.

---

## 17. INDIANA DIRECTIVE (COMPANION)

Indiana uses the same 3-layer, 4-entity, zero-fork contract as Michigan.
Do not create Indiana-specific schema.
Do not continue past 3 counties per cycle without explicit approval.
Run safety protocol, precheck, gate, and checkpoint on every batch.
Generate raw JSON, precheck JSON, review CSV, and manifest JSON for every county batch.
Use the internal progress map to show county status, not parcel truth.
Mr. Results is the orchestrator, not the bypass authority.

Indiana = same pipeline, new source adapters only.

---

## 18. SUCCESS STANDARD

The system succeeds only if:
- all bots share one staging contract
- raw source truth is preserved
- geometry honesty is never violated
- file exports are predictable
- county/state progress is visible
- batches pause after checkpoint
- operator approval controls continuation
- ChatGPT receives clean, consistent handoff files
- Emergent receives only intentional, reviewed packages

If speed conflicts with truth, truth wins.
If automation conflicts with control, control wins.
If convenience conflicts with trust, trust wins.

---

Generated by Mr. Results (Overseer) - Powered by Nvirogear LLC
N-ViroGear Land Intelligence System
