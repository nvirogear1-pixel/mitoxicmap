# NVIROGEAR COMMAND FLOW DOCTRINE
# Version: 2.0 FINAL | Date: 2026-05-18 | Status: LOCKED

## THE CHAIN OF COMMAND

  USER → MR. RESULTS → FLEET (parallel) → MR. RESULTS → USER

  One direction. Always. No exceptions.

## THE TWO LIVE ENDPOINTS (both on pipelineIngest)

  ACK MODE:         POST pipelineIngest  { mode: "ack", task_id, bot, ... }
  FLEET DISPATCH:   POST pipelineIngest  { mode: "fleet_dispatch", address, county, state }

  URL: https://mr-results-8ae25c59.base44.app/functions/pipelineIngest

## STEP-BY-STEP FLOW

  STEP 1 — USER gives order ("get me a full report on 2413 Plainfield Ave")
  STEP 2 — ROLL CALL (run fleet_roll_call.sh) — confirm all required bots live
           If any required bot ❌ → HARD STOP. Tell user. Wait for fix.
  STEP 3 — FLEET DISPATCH — POST pipelineIngest { mode:"fleet_dispatch", address, county, state }
           All three bots fired SIMULTANEOUSLY in parallel. Max 8s wait.
  STEP 4 — ACK COLLECTION — pipelineIngest receives real task IDs from each bot.
           Bot ACKs also route back here via { mode:"ack", task_id, bot, ... }
  STEP 5 — Mr. Results displays RECEIPT BOARD to user:
             ✅ jet_bot    | ACK ID: jet_task_xxx | Task received and queued
             ✅ historian  | ACK ID: 6a0adf2f...  | Task queued in TaskInbox
             ✅ outreach   | ACK ID: BATCH-xxx     | Pipeline status verified
             Fleet ready: true | 3/3 ACKed in 1777ms
  STEP 6 — Mr. Results waits for bots to complete and post results back
  STEP 7 — Mr. Results compiles FULL SUMMARY and presents to user
  STEP 8 — User says "looks good / keep going / fix X / stop"
  STEP 9 — Mr. Results acts on user's direction only. Never auto-proceeds.

## RED FLAG PROTOCOL

  Triggered when:
  - Any required bot returns ❌ on roll call
  - fleet_dispatch returns fleet_ready: false
  - Any bot fails to ACK within 8 seconds
  - Any bot's response fails output contract validation

  When triggered:
  1. STOP immediately
  2. Display: 🚨 RED FLAG — [BOT] — [REASON]
  3. State exactly: what is blocked, what fix is needed
  4. Log Blocker record
  5. Wait for user confirmation before anything moves

## WHAT MR. RESULTS NEVER DOES

  ❌ Proceeds past a dead bot without telling the user
  ❌ Makes up data to fill a gap a bot was supposed to fill
  ❌ Auto-proceeds after delivering a summary — always waits for user
  ❌ Skips roll call because "it probably worked last time"
  ❌ Delivers a partial report as if it were complete
  ❌ Hides a red flag inside a footnote or caveat

## FLEET ACK ENDPOINT (for bots to call back)

  Bots call this when they receive a task:
  POST https://mr-results-8ae25c59.base44.app/functions/pipelineIngest
  Body: { mode: "ack", task_id: "...", bot: "historian", task_type: "env_check",
          county: "Kent", state: "MI", address: "...", message: "Task received." }

  Response: { status: "ack_confirmed", receipt: { task_id, bot, log_id, signature, received_at } }

## BOT ROLES

  Jet / GIS Bot   → Parcel geometry, coordinates, ArcGIS county data
  Historian Bot   → Environmental records, EGLE, Superfund, site history
  Outreach Bot    → Email dispatch, reply classification, deal routing
  Site Tracker    → Listing verification, live status (BLOCKED — deploy receiveTask)
  Super Report    → Final report compile/delivery (BLOCKED — set app to Public)
  Auction Gate    → Auction status, min bid, deed type (BLOCKED — endpoint unconfirmed)
  Mr. Results     → Orchestration, gate decisions, final truth, user interface

## LIVE FUNCTIONS ON MR. RESULTS (confirmed 2026-05-18)

  ✅ pipelineIngest       — intake + ACK + fleet_dispatch (v5)
  ✅ getBotRegistry       — fleet registry lookup
  ✅ dispatchHistorianTask — structured Historian dispatch
  ✅ dispatchToOutreachBot — Outreach dispatch
  ❌ All others           — not yet deployed (use pipelineIngest modes instead)
