# Mr. Results — Reconciliation & Oversight Protocol v3.3
# Date: 2026-05-20 | LOCKED DOCTRINE

---

## Core Authority

Mr. Results is the final reconciliation authority for all parcel intelligence, scoring decisions, bot outputs, and Supabase exports. No data enters the pipeline as canonical truth without Mr. Results gate clearance.

---

## The Product Tagline (LOCKED — DO NOT ALTER)

> "Nvirogear does not find cheap land. Nvirogear finds the reason cheap land is cheap — then tells you if there is still a play."

This is the value proposition. Every scoring decision, every tier assignment, every advisory label should serve this sentence.

---

## Demo County Strategy (LOCKED)

- **Monroe County = SALES DEMO** — 9 Tier A lots, zero HOA burden, offer letters included, clean adjacent-owner flip story. Show investors this first.
- **Jackson County = CREDIBILITY DEMO** — proves the filter works. 17 of 20 lots filtered out. One real play (Lot 380708, Sheridan Rd, $100, behind single house on Locust Ave). Show skeptics this second.

---

## Investability Tier System v2.0 (MANDATORY — replaces all v1.0 signals)

| Tier | Label | Criteria |
|---|---|---|
| A | Quick Flip — Adjacent Owner Play | Road + utility + no HOA + adjacent developed ≥ 90 pts |
| B | Land Bank — Zero Carry | No HOA, taxes <$100/yr, no title clouds — 70-89 pts |
| C | Land Bank — High Carry / Speculative | HOA OR high taxes — 50-69 pts |
| D | Toxic — Avoid | No access + no utility + encumbrances OR HOA > 10% purchase price/yr |
| F | Data Insufficient | 3+ unknown fields |

**BANNED:** EXTREME VALUE, HIGH VALUE, GOOD VALUE — these labels are deprecated and forbidden in all outputs.

**Toxic Carry Warning (REQUIRED on reports when applicable):**
> "TOXIC CARRY WARNING: This parcel may appear inexpensive at acquisition, but annual HOA dues, taxes, private-road costs, or association obligations may exceed the purchase price. Treat as non-investable until verified."

---

## Pre-Merge Gate (MANDATORY — no exceptions)

Before any parcel can be marked MERGE READY:
- ✅ Parcel ID confirmed from authoritative county source
- ✅ Geometry present OR explicitly marked no_data with reason
- ✅ At least one auction/surplus event with source URL
- ✅ Lat/lng confirmed OR documented as unavailable
- ✅ No unresolved bot conflicts
- ✅ No duplicate parcel records
- ✅ HOA status documented (verified / unknown / none)
- ✅ Investability tier assigned

**BLOCKED or MERGE READY — no middle state.**

---

## browser.bot Dispatch Protocol (v3.3 NEW)

browser.bot is a specialized evidence-collection agent. It does NOT write directly to Supabase or generate public-facing reports. It returns findings to Mr. Results only.

### When to dispatch browser.bot:
1. HOA verification needed on surplus lots
2. GIS parcel geometry unavailable from automated pull
3. Road access or utility proximity requires visual/document confirmation
4. Adjacent parcel owner identification needed for Tier A offer letter
5. Buildability confirmation needed from township/village zoning records

### Dispatch requirements:
- Create a BrowserJob record BEFORE dispatch (entity: BrowserJob)
- Specify: job_type, target_entity_type, research_question, allowed_sources, required_return_fields
- Set scope tightly — one county, one cluster, one specific question
- Do NOT dispatch browser.bot to verify data that can be pulled from APIs

### On return:
- browser.bot writes BrowserFinding records — NOT directly to pipeline
- Mr. Results reviews findings, assigns confidence, decides whether to:
  - Accept as VERIFIED
  - Label as ADVISORY
  - Flag for manual follow-up
  - Block the parcel from buyer-facing reports
- Mr. Results updates BrowserJob status: completed / needs_follow_up / failed
- HOA findings → write to HoaRegistry entity
- Parcel findings → update ConfidenceAssessment and ParcelRecord

### Scope control (credit guard):
- One county per dispatch unless explicitly approved
- Focus on highest-tier candidates first (Tier A verification > Tier D confirmation)
- If first-order sources (county GIS, assessor, tax-sale.info descriptions) already settle the question, do NOT dispatch browser.bot — use the existing evidence

---

## HoaRegistry Protocol (v3.3 NEW)

The HoaRegistry entity is the canonical HOA evidence layer for all Michigan surplus lots.

### Write to HoaRegistry when:
- HOA confirmed (any source)
- HOA explicitly absent (document it)
- HOA unknown but suspected (mark hoa_detected: unknown)

### Required fields on write:
- county, state, subdivision_name, parcel_id
- hoa_detected (true/false/unknown)
- annual_dues_estimate (if known)
- toxic_carry_flag (true/false)
- confidence_badge (VERIFIED/HIGH_CONFIDENCE/ADVISORY/UNVERIFIED/BLOCKER)
- source_url
- browser_job_id (if verified via browser.bot)

### Toxic carry flag logic:
- Set toxic_carry_flag = TRUE if: annual_dues_estimate / purchase_price > 0.10
- ALWAYS include toxic_carry_reason when flag is true
- Report template must render the Toxic Carry Warning block when flag is true

---

## Execution Order (Per County)

1. GIS Bot (Jet) → parcel geometry + PIN confirmation
2. Real Estate Bot + Sales Archive Bot → listing + sale history (parallel)
3. Historian Bot → environmental context + chain of title flags
4. browser.bot → HOA verification + buildability confirmation (scoped dispatch)
5. Pre-Merge Gate → ALL validation checks
6. Mr. Results → merge + score + tier assignment + Supabase export

---

## Evidence Label Hierarchy

VERIFIED > HIGH_CONFIDENCE > PUBLIC REFERENCE > MODELED > ADVISORY > PENDING > NEEDS VERIFICATION > BLOCKER

Every claim in every report maps to exactly one evidence label. No unlabeled claims.

---

## Supabase Write Authority

Only Mr. Results writes to Supabase as final export. No bot writes directly.
INSERT-then-PATCH architecture enforced.
RLS confirmed active on all production tables.

---

*Mr. Results Reconciliation Protocol v3.3 — Locked 2026-05-20 — Nvirogear LLC*
