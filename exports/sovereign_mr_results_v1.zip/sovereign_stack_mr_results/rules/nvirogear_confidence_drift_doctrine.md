# Nvirogear Confidence Drift Doctrine v1.0 — LOCKED
**Issued by:** Mr. Results (Overseer), per Joseph Smith directive
**Date:** 2026-07-08
**Status:** GOVERNING — applies to every Nvirogear system that produces a claim, alert, or report:
MISS DIG, ALICE, VaultSmith, The Corridor/Story narratives, ControlMap, Base44 report builders, and any future system.

## THE CORE RULE

> **Never upgrade uncertainty into a confident alert.**

An AI system's job is not to sound confident. It is to be honest about what it actually knows,
and to make the gap between "known" and "assumed" visible rather than papering over it.

## THREE-WAY CLASSIFICATION (MANDATORY PATTERN)

Any system that screens records against a set of criteria (contamination proximity, tax
anomaly, ownership match, etc.) must classify every result into exactly one of three buckets —
never two, never a single "flagged/clean" binary:

1. **VERIFIED_ALERT / VERIFIED** — passed a hard validation gate. Every required proof field
   is present and traceable to a real source.
2. **NEEDS_REVIEW** — a possible match exists, but at least one required proof field is
   missing, uncertain, or failed a sanity check. This is NOT the same as clean, and it is NOT
   the same as confirmed — it is its own category that requires human review.
3. **CLEAN / NO_MATCH** — no match found within the defined scope. This must be an honest
   negative result, not a default fallback when the system doesn't know what else to say.

## THE HARD VALIDATION GATE

Before any record can be classified as VERIFIED, it must pass a hard gate that checks every
required proof field explicitly. Missing or unverifiable ANY one of them automatically
demotes the record to NEEDS_REVIEW — regardless of how likely a match "feels."

Standard proof-field categories (adapt per system, but keep the shape):
1. **Source proof** — raw record ID, source feed/database, retrieval timestamp.
2. **Geocode/location proof** — coordinates, geocoder used (or explicitly "none — as
   provided by source"), confidence, and a basic sanity check (e.g. county/city bounding box)
   so obvious mismatches (wrong city, wrong state) are caught automatically.
3. **Reference/comparison source proof** — official source name, database, regulatory or
   registry ID, source URL, last-verified date.
4. **Calculation proof** — the actual formula used (distance, ratio, percentage), the
   threshold applied, and the computed result — never asserted without the math shown.
5. **Contact/identity proof** — any name, phone, or email must be traceable to a real source
   payload. If not available, the field is explicitly marked unavailable — never invented.

## LANGUAGE RULES

- Never say "X detected" or "X confirmed" for a proximity/pattern match. Use:
  **"A source-backed [record type] was found within [scope]."**
- Any missing value renders as: **"Unknown — source not verified."** — never blank, never guessed.
- Every hash presented as a "VaultSmith anchor" or evidence hash must be a real cryptographic
  hash computed from the actual evidence bundle content — never a fabricated string formatted
  to look like a hash.

## APPLIES TO

This doctrine is universal across the Nvirogear stack:
- **MISS DIG** — ticket-to-contamination cross-referencing (implemented 2026-07-08 in
  `missDigCrossRef.ts` — see VERIFIED_ALERT/NEEDS_REVIEW/CLEAN_NO_MATCH pattern there for
  reference implementation).
- **ALICE** — parcel truth engine, contamination records, well logs.
- **VaultSmith** — provenance anchoring; a hash is only as trustworthy as the gate that
  produced the bundle it hashes.
- **The Corridor / Story narratives** — every claim still needs its Evidence Panel status
  (CONFIRMED / PARTIALLY CONFIRMED / NOT VERIFIED / CONTRADICTED), which is this same
  three-way pattern applied to narrative claims instead of automated alerts.
- **ControlMap** — the same "never execute on low confidence" logic (Blue/Yellow/Red states,
  pause-and-remap on low OCR confidence) is this doctrine applied to UI automation.
- **Any future Base44-built report or PDF generator** — must render a NEEDS_REVIEW section
  distinct from a VERIFIED section. A generator may never silently fold uncertain matches
  into the confident bucket just to make the report look cleaner.

## FAILURE MODE THIS PREVENTS

On 2026-07-08 the MISS DIG Daily Alert automation was found running a leftover demo script
with 100% hardcoded ticket coordinates, a fabricated site name, invented excavator contacts,
and fake-looking (non-cryptographic) hash strings — while a real, disciplined implementation
already existed elsewhere and simply wasn't the one wired to the automation. This doctrine
exists so that gap — a confident-looking output built on an unverified foundation — cannot
happen again, on any system, without a hard gate catching it first.

---
*Mr. Results (Overseer) — Nvirogear LLC — Confidence Drift Doctrine v1.0 — 2026-07-08*
