# CLUSTER CLASSIFICATION PROTOCOL
**Issued by:** Mr. Results (Overseer)
**Date:** 2026-04-05 (v2 — enforcement constraint added)
**Status:** PERMANENT — applies to all multi-site environmental comparison passes

---

## PURPOSE

This rule file governs how Mr. Results evaluates whether two environmentally flagged parcels should be treated as a linked site or independent records.

It exists to prevent cluster drift, false linking, and unsupported multi-parcel contamination claims.

---

## SCOPE

Applies whenever:
- Two or more parcels are geographically proximate
- Environmental histories overlap or may overlap
- Historian returns suggest possible industrial or contamination linkage
- Mr. Results is asked to compare related sites after Phase 2

---

## REQUIRED INPUTS (GATE — DO NOT SKIP)

Mr. Results must NOT run cluster comparison until BOTH parcel historian returns are present.

Minimum required inputs per site:
- `site_key`
- `parcel_id`
- `egle_site_id`
- Contamination profile (contaminants confirmed)
- Operating/use timeline
- Regulatory history
- Historian notes
- Proximity assessment

**If any of the above are missing for either site:**
- Do NOT classify linkage
- Return `"comparison_blocked_insufficient_inputs"`
- Create OperationalTask to retrieve missing data before re-running

---

## CLASSIFICATION RULES (EVIDENCE-GATED)

---

### 1. `same_documented_site`

**Strongest classification. Rarely earned at Phase 2.**

Allow ONLY if at least ONE of the following is true:
- Same EGLE site ID on both parcels
- Same EPA / Superfund / CERCLIS site identifier
- Official regulatory document explicitly states both parcels are part of the same site
- Official map, report, or enforcement record ties both parcels to the same documented environmental case

**Required:**
- `confidence = high`
- `evidence_type` must include `regulatory`

**Do NOT use based on proximity alone.**

---

### 2. `possible_shared_plume_unconfirmed`

**Caution state. Not a merge state.**

Allow ONLY if ALL THREE are true:
- Parcels are geographically proximate (same corridor, under 500m)
- Contaminants are identical or substantially overlapping
- Operational or contamination timelines overlap meaningfully

AND:
- No direct regulatory document proving same-site status exists
- Historian evidence supports plausible linkage but not confirmation

**Required:**
- `confidence = medium` or `low`
- `requires_followup = true`

**Do NOT promote either parcel to confirmed multi-parcel status from this classification alone.**

---

### 3. `adjacent_industrial_corridor_only`

**The DEFAULT SAFE STATE. Use when in doubt.**

Use when:
- Parcels are near each other
- Both may have industrial histories
- Contamination linkage is not proven
- Records suggest separate but nearby industrial activity

**Required:**
- `confidence = medium` (or `low` if evidence is very weak)
- `requires_followup = false` unless a specific signal warrants future review

**Prefer this classification unless evidence clearly supports something stronger.**

---

### 4. `no_evidence_of_connection`

Use when:
- Historian returns show no meaningful overlap
- Contaminants differ materially
- Timelines do not align
- Regulatory records appear fully separate
- Proximity alone is not sufficient to imply linkage

**Required:**
- `confidence = medium` or `high`
- Explicit negative findings documented in historian return

---

## COMPARISON SEQUENCE (MANDATORY — run in this exact order)

### Step 1 — Regulatory Identity
- Same EGLE site ID?
- Same EPA / CERCLIS identifier?
- Same enforcement or response case?
- Same official site map?

→ YES on any: classify `same_documented_site`
→ NO on all: continue to Step 2

---

### Step 2 — Contaminant Overlap
- Identical contaminants?
- Overlapping contaminant family (e.g., both have chlorinated VOCs)?
- Similar media affected (soil / groundwater / vapor)?

Record: `contaminant_relationship = identical | overlapping | distinct`

---

### Step 3 — Timeline Overlap
- Same operational era?
- Same contamination discovery period?
- Staggered but plausibly connected?
- Completely separate time windows?

Record: `timeline_relationship = overlapping | adjacent | separate`

---

### Step 4 — Proximity Review
- Adjacent parcels?
- Same corridor block?
- Separated by intervening parcels or roads?
- Likely hydraulic / industrial adjacency?

Record: `proximity_relationship = adjacent | nearby | weak`

---

### Step 5 — Final Classification
Use the strongest classification **allowed by evidence**.

If evidence is mixed or incomplete → default to `adjacent_industrial_corridor_only`.
Never escalate to `same_documented_site` without documentary support.

---

## ENFORCEMENT CONSTRAINT (HARD RULE — ADDED 2026-04-05)

> **Cluster classification cannot alter parcel-level `environmental_site_type` unless BOTH of the following are true:**
> 1. `confidence = high`
> 2. `evidence_type` includes `regulatory`

**What this prevents:**
- A `possible_shared_plume_unconfirmed` return (confidence: medium) silently upgrading a parcel's `environmental_site_type` from `unknown_scope` to `multi_parcel_environmental_site`
- A historian inference — even a strong one — rewriting hard parcel truth without documentary backing
- Soft linkage signals cascading into export payloads with overstated contamination scope

**What this allows:**
- `same_documented_site` (confidence: high, evidence_type: regulatory) → upgrades both parcels to `multi_parcel_environmental_site` with shared `environmental_scope` block
- Everything else → cluster relationship is recorded in `cluster_analysis` block only. Parcel-level `environmental_site_type` is unchanged.

**Violation = gate failure. Do not merge parcel truth on soft evidence.**

---

## OUTPUT CONTRACT (REQUIRED FORMAT)

```json
{
  "cluster_comparison": {
    "cluster_id": "keating_industrial_corridor",
    "site_a": "",
    "site_b": "",
    "classification": "",
    "confidence": "low | medium | high",
    "evidence_type": ["regulatory", "historical", "proximity"],
    "contaminant_relationship": "identical | overlapping | distinct",
    "timeline_relationship": "overlapping | adjacent | separate",
    "proximity_relationship": "adjacent | nearby | weak",
    "requires_followup": true,
    "promotion_rule_met": "",
    "parcel_type_update_authorized": true,
    "notes": []
  }
}
```

### Field notes:
- `promotion_rule_met` — exact rule ID from this document, e.g. `same_documented_site_rule_1a`
- `parcel_type_update_authorized` — `true` ONLY if `confidence = high` AND `evidence_type` includes `regulatory`. Otherwise always `false`.

---

## PROMOTION RULES (ONE-WAY, EVIDENCE-GATED)

| From | To | Allowed? | Requirement |
|---|---|---|---|
| `adjacent_industrial_corridor_only` | `possible_shared_plume_unconfirmed` | ✅ | All three Step 2-4 conditions met |
| `adjacent_industrial_corridor_only` | `same_documented_site` | ❌ | Must go through `possible_shared_plume_unconfirmed` first unless direct regulatory proof |
| `possible_shared_plume_unconfirmed` | `same_documented_site` | ✅ | Regulatory document found linking both parcels |
| `possible_shared_plume_unconfirmed` | `adjacent_industrial_corridor_only` | ✅ | Phase 2 disproves contaminant or timeline overlap |
| Any | `no_evidence_of_connection` | ✅ | Explicit negative findings in Phase 2 only |

No skipping steps. No downgrading without evidence.

---

## SAFETY RULES

- Proximity alone never proves same-site status
- Shared industrial corridor does not equal shared plume
- Overlapping contaminants do not equal shared regulatory case
- Absence of proof must default to the safer classification
- Do not merge parcel histories unless documentary evidence supports it
- `parcel_type_update_authorized: false` means cluster notes only — no parcel record changes

---

## KEATING CORRIDOR — CURRENT STATE

Sites under evaluation:
- `egle-61000899-1060-e-keating` | parcel `61-24-215-012-0007-00` | unknown_scope | Phase 2 dispatched
- `egle-61000001-1041-e-keating` | parcel `24-133-100-0021-00` | unknown_scope | Phase 2 dispatched

**Starting classification:** `adjacent_industrial_corridor_only`
**Parcel type update authorized:** `false` — pending Phase 2 returns

Upgrade path:
- Phase 2 confirms overlapping contaminants + overlapping timelines, no regulatory linkage → `possible_shared_plume_unconfirmed` (parcel records unchanged)
- Phase 2 finds shared EGLE case or linked ROD → `same_documented_site` (parcel records may be updated)
- Phase 2 shows divergent contaminants or timelines → stays `adjacent_industrial_corridor_only`

---

## DEFAULT SYSTEM BEHAVIOR

If uncertain:
- Classify `adjacent_industrial_corridor_only`
- Preserve separate parcel records
- Flag uncertainty in notes
- Require follow-up only when evidence suggests real linkage potential

**Bad linkage = system failure**
**Cautious separation = system success**

---

Generated by Mr. Results (Overseer) - Powered by Nvirogear LLC
N-ViroGear Land Intelligence System
