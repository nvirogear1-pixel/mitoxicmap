# Nvirogear Enterprise Report Standard — v2.0
# Locked: May 19, 2026
# Authority: Mr. Results (Overseer) — Nvirogear LLC
# Status: PERMANENT PRODUCTION STANDARD — applies to ALL enterprise reports going forward

---

## OVERVIEW

This document defines the mandatory schema, data pull sequence, scoring methodology,
financial modeling rules, and section structure for all Nvirogear Pre-Diligence Risk
Screen reports at the enterprise/production level.

Reference implementation: 2413 Plainfield Ave NE, Grand Rapids MI — Pre-Diligence v2.0
File: 2413_plainfield_v2_production.html · Built: May 19, 2026

---

## PART 1 — MANDATORY DATA PULLS (Execute Before Any Report Is Written)

All 6 layers must be attempted. If a layer returns no data or is gated behind auth,
document exactly what is required to complete it — never silently skip.

### Layer 1 — County GIS (VERIFIED)
- Source: County GIS FeatureServer (ArcGIS REST)
- Kent County: gis.kentcountymi.gov/agisprod/rest/services/ParcelsWithCondos/FeatureServer/0
- Other counties: use county-specific ArcGIS REST endpoint (see SourceRegistry)
- Required fields: polygon coordinates, centroid lat/lng, acreage, SEV/taxable value, owner name, mailing address, OBJECTID, parcel number, property class, school district
- Badge: `VERIFIED — Official County GIS`
- If blocked: label `GIS SEARCH REQUIRED` with exact county GIS URL

### Layer 2 — Register of Deeds (CRITICAL)
- Source: County Register of Deeds portal
- Kent County: deedsselfservice.kentcountymi.gov/web/ — free to search, $1/page download, 616-632-7640
- Required: mortgage status, deed type, last conveyance date, liens/judgments, foreclosure filings, land contract status
- If free and clear: label `FREE AND CLEAR — Register of Deeds [date confirmed]`
- If mortgage found: show lender, origination date, amount (if public)
- If not pulled: label `SEARCH REQUIRED` with exact steps — NEVER leave blank

### Layer 3 — County Treasurer / Tax Status
- Source: County BS&A or Treasurer portal
- Kent County: bsaonline.com uid=115 (City of GR) or 616-632-7700
- Required: 2025 tax status (paid/delinquent/pending), tax bill amount, due dates, special assessments
- Tax Drop Rule: if SEV drops >30% year-over-year → hard flag in Risk Register + ACS cap ≤65
- If not pulled: label `SEARCH REQUIRED` with exact URL and phone

### Layer 4 — Municipal Building Permits
- Source: City permit portal (Accela or equivalent)
- Grand Rapids: aca-prod.accela.com/GRANDRAPIDS — free with account, or call 311
- Required: permit type, date, status, contractor (if public), final inspection date
- Priority permits: roof, HVAC, electrical, plumbing, structural, demolition
- If no permits found: document explicitly — `No permits surfaced in public search`
- Implication rule: if no permits post-purchase → assume deferred maintenance → apply Mechanical Refresh as renovation baseline
- If not pulled: label `ACCELA SEARCH REQUIRED` with portal URL

### Layer 5 — EGLE RIDE + EPA ECHO (Environmental Proximity)
- FEMA NFHL (flood zone): hazards.fema.gov/arcgis/rest/services/public/NFHL/MapServer/28 (zone) + MapServer/3 (panel)
- EPA ECHO (facilities): echodata.epa.gov/echo/echo_rest_services.get_facilities — p_radius=1 AND p_radius=5 (sanity check)
- EGLE MPART: michigan.gov/pfasresponse (state-specific; adapt for other states)
- Required output: site name, distance from centroid, status, contaminant type
- If zero found: state explicitly — `No Part 201 or NPL sites within 1 mile`
- Badge: `VERIFIED — EGLE/EPA`

### Layer 6 — FEMA Flood Map Service Center
- Source: FEMA NFHL live API (see Layer 5 above)
- Required: FLD_ZONE, ZONE_SUBTY, SFHA_TF, DFIRM_ID, panel number (FIRM_PAN), effective date (EFF_DATE)
- Zone X: state `Zone X (Area of Minimal Flood Hazard) — no flood insurance required. Optional policy ~$450–$600/yr`
- Zone A/AE: state requirement + estimated annual premium range
- Badge: `VERIFIED — FEMA NFHL LIVE API`

---

## PART 2 — SCORING METHODOLOGY (Fully Exposed — No Hidden Numbers)

### Rule: Never publish a score without publishing the inputs.
Every score section must include a breakdown table showing component, max points, awarded points, and rationale.

### Opportunity Signal Score (OSS) — 0 to 100

| Component | Max Pts | Notes |
|---|---|---|
| Off-market duration × market velocity multiplier | 25 | Longer off-market in fast-moving zip = higher pts |
| AVM-to-comp spread depth | 25 | Comp avg vs. AVM mid: every 5% gap ≈ 5 pts |
| Lot premium (size/adjacency vs. zip median) | 15 | ADU-eligible or oversize lot = bonus |
| Zoning flexibility | 15 | ADU by right, commercial overlay, TOD = bonus |
| Tax stability | 10 | No delinquency, no >30% SEV drop |
| Condition visibility | 10 | Recent mechanical permits = pts; no permits = 3 pts max |
| Deductions — open blockers | — | −2 pts per unresolved blocker |

### Actionability Confidence Score (ACS) — 0 to 100

| Component | Max Pts | Notes |
|---|---|---|
| Owner confirmation | 20 | GIS-confirmed owner = 20 pts |
| Title clarity / lien status | 20 | Pulled and clear = 20; not pulled = 0 |
| Physical condition visibility | 20 | Inspection complete = 20; no permits and no inspection = 3 pts max |
| Environmental clearance | 15 | FEMA + EPA/EGLE all confirmed = 15; any open = partial |
| Flood zone confirmation | 15 | FEMA NFHL live confirmed = 15; estimated = 5 |
| Availability confirmation | 10 | Active listing or confirmed owner contact = 10; unknown = 0 |

**HARD CAP RULES (mandatory):**
- If availability unconfirmed: ACS max = 60
- If title not pulled: ACS max = 70
- If condition unknown (no inspection, no permits): ACS max = 75
- Multiple caps: apply the LOWEST applicable cap
- Cap must be disclosed explicitly in the report with reason stated

---

## PART 3 — FINANCIAL MODELING (Show Your Work — Always)

### Offer Range Formula

```
FLOOR = MAX(AVM_low × 0.85, SEV × 2.5, tax_value × 4.0)
CEILING (pre-haircut) = MIN(AVM_high × 0.95, comp_avg × 0.90)

CONDITION HAIRCUT:
  - Recent mechanical permits (post-3yr): 0% haircut
  - No permits found: −10% to −15% applied to ceiling
  - Known structural/environmental issue: −15% to −25%

FINAL OFFER RANGE = FLOOR → (CEILING − haircut)
```

All inputs must be shown explicitly with their source badges.

### Renovation Estimate Tiers

| Tier | Scope | Range | Default Trigger |
|---|---|---|---|
| Light Cosmetic | Paint, flooring, fixtures, landscaping | $18K–$28K | Post-2020 mechanical permits confirmed |
| Mechanical Refresh | HVAC, plumbing, electrical (panel upgrade) | $35K–$55K | No mechanical permits found (DEFAULT if no permits) |
| Full Gut | Knob-and-tube, galvanized pipe, asbestos suspected | $65K–$95K | Pre-1960 build + no permits + condition red flag |

**Rule:** If no permits found post-purchase, always apply Mechanical Refresh as minimum baseline. Document this assumption explicitly.

### Gross Spread Formula

```
SPREAD_LOW  = (comp_avg × 0.92) − (ceiling_offer + reno_high)
SPREAD_HIGH = (comp_avg × 0.95) − (floor_offer + reno_low)
```

Both calculations must appear in a "Model Math" box — never in prose only.
Label: `SCENARIO ESTIMATE ONLY — not a guarantee of market outcomes`

---

## PART 4 — INVESTMENT SCENARIOS (3 Required)

Every production enterprise report must include all three scenarios unless a scenario
is definitively inapplicable (document why).

### Scenario A — Fix & Flip
- Buy price range + specific renovation tier + target resale
- Must cite at least 1 specific sold comp (address, price, sqft, date)
- Show gross spread calc
- Include exit timeline estimate

### Scenario B — Buy & Hold (Rental)
- Must cite at least 2 rental comps (address, rent/mo, source)
- Show: assumed rent, purchase price, 20% down, PITI estimate, GRM, gross yield, cap rate (with expense ratio stated), cash-on-cash
- Interest rate assumption must be stated explicitly
- Label all projections `MODELED`

### Scenario C — ADU / Development
- Required if: MCN, TN, or MON zone AND lot ≥ 0.20 acres
- Must confirm ADU permitted in the zone (by right or with DR)
- Show: max ADU size, setbacks, green space %, parking rule, height limit, deed restriction requirement
- Show: ADU construction cost estimate, ADU rental income estimate, combined gross income, post-ADU value estimate
- Label all ADU projections `MODELED — SCENARIO ESTIMATE`
- Source: City-specific ADU ordinance document (never generic)

---

## PART 5 — TITLE & LIEN SNAPSHOT BOX (Required in Every Report)

A dedicated "Title & Lien Snapshot" sidebar or card must appear in every report with:

| Field | Options |
|---|---|
| Mortgage Status | FREE AND CLEAR (confirmed) / Active mortgage — [Lender] / SEARCH REQUIRED |
| Deed Type | Warranty / Quitclaim / Land Contract / SEARCH REQUIRED |
| Last Conveyance | [Date · $Amount · Source] |
| Judgments / Liens | None found / [Description] / SEARCH REQUIRED |
| HOA | None identified / [Name] / ADVISORY — confirm |
| Land Contract | Not found / SEARCH REQUIRED |

Plus exact steps to pull (portal URL, phone, cost).

---

## PART 6 — RISK REGISTER (Expanded Format)

Every risk register entry must include ALL of:

| Field | Required |
|---|---|
| Risk ID | RISK-001 format |
| Category | Physical / Title / Environmental / Availability / Tax / ADU / Financial |
| Description | Plain-English, specific to this property |
| Severity | HIGH / MODERATE / LOW |
| Probability % | Your estimated likelihood this risk materializes |
| Financial Impact Range | Dollar range (e.g., $8K–$18K) |
| Mitigation | Specific action + cost/effort |
| Recommended Professional | Name of professional type + local contact if available |
| Status | Open / Advisory / RESOLVED ✅ |

**Resolved items** stay in the table with strikethrough — never deleted.

---

## PART 7 — 90-DAY ACTION CHECKLIST (Required)

Every report must include a numbered checklist with for each item:
- Action (imperative)
- Source / portal / who to call
- Cost estimate
- Timeline estimate

Minimum 8 items. Include at least:
1. Title search
2. Interior inspection
3. Tax status confirmation
4. CCR request (water quality, if city water)
5. Full permit history pull
6. Owner contact / skip-trace
7. EGLE RIDE confirmation
8. ADU pre-app meeting (if Scenario C applies)

---

## PART 8 — SECTION STRUCTURE (12 Required Sections)

| # | Section | Key Content |
|---|---|---|
| S1 | Executive Decision Summary | Scores, gate status, data pull table, signal summary |
| S2 | Property Identity | Parcel record + site/structure data (GIS-sourced) |
| S3 | Scores + Math | Full OSS + ACS breakdown tables |
| S4 | Title & Lien Snapshot | Deed, mortgage, lien status + pull steps |
| S5 | Environmental Intelligence | FEMA, EPA, EGLE flags — all with source badges |
| S6 | Financial Model | Offer range formula, reno tiers, gross spread math box |
| S7 | Investment Scenarios | A (Flip), B (Hold), C (ADU) — all three |
| S8 | Risk Register | Expanded format — all fields |
| S9 | GIS Evidence Map | Official polygon, 1-mile radius ring, labeled env pins |
| S10 | Gate Status + 90-Day Checklist | Gate items with ✅/⏳/🚫 status + action checklist |
| S11 | Source Confidence Ledger | One entry per claim — source, badge, limitation |
| S12 | Legal Disclaimers | All 8 required disclaimers |

---

## PART 9 — GIS MAP REQUIREMENTS

Every report map must:
- Render the **official county GIS polygon** (not a centroid pin) — pulled from county FeatureServer
- Include a **1-mile radius ring** for environmental reference
- **Label all EGLE/EPA sites** found within the radius (or explicitly state zero found)
- Include **popup for every pin** with: site name, distance, status badge
- Use **dark CARTO basemap** (`dark_all`) with Leaflet + CDN
- Call `fitBounds` on the polygon so zoom is auto-set
- Include `map.fitBounds(poly.getBounds().pad(X))` — never hardcode zoom level
- Render offline after first CDN load

---

## PART 10 — SOURCE LEDGER (Required — One Entry Per Claim)

Every source ledger entry must include:
- `SRC-XXX` ID
- Claim text (what data point this source supports)
- Badge: VERIFIED / PUBLIC REFERENCE / MODELED / ADVISORY / SEARCH REQUIRED
- Source name + URL
- Query date
- Limitation text (what the source does NOT cover)

**Minimum source ledger entries for a production report:**
- SRC-001: County GIS (polygon, owner, SEV)
- SRC-002: FEMA NFHL (zone + panel)
- SRC-003: EPA ECHO (facility proximity)
- SRC-004: EGLE MPART (state environmental)
- SRC-005: ADU Ordinance (city-specific document, dated)
- SRC-006: Last MLS sale (public reference)
- SRC-007: AVM data (public reference, labeled)
- SRC-008: Comparable sales (public reference)
- SRC-009: Rental comps (public reference)
- SRC-010: Offer range formula inputs (modeled)
- SRC-011: Renovation ranges (modeled)
- SRC-012: Gross spread calc (modeled)
- SRC-013: Register of Deeds status (search required or confirmed)
- SRC-014: Building permits status (search required or confirmed)

---

## PART 11 — REQUIRED DISCLAIMERS (8 Mandatory)

1. NOT A PROFESSIONAL SERVICE OPINION
2. AUTOMATED DATA AGGREGATION DISCLOSURE — state exact number of sources
3. VALUATION DISCLAIMER — AVMs are public reference, not appraisals
4. ENVIRONMENTAL DISCLAIMER — absence of record ≠ clean
5. FLOOD DISCLAIMER — FEMA zone confirmed but formal FZD required for lending/insurance
6. ADU ORDINANCE DISCLAIMER — verify with City Planning before committing
7. FINANCIAL MODEL DISCLAIMER — scenario estimates, not guarantees
8. DATA CURRENCY — report date + 90-day expiration notice

---

## PART 12 — VISUAL / UX STANDARDS

### Color Badges (Exact Hex)

| Badge | CSS Class | Color | Hex |
|---|---|---|---|
| VERIFIED | `.bv` | Cyan | `#00d4ff` |
| PUBLIC REFERENCE | `.bp` | Blue | `#60a5fa` |
| MODELED | `.bm` | Amber | `#f59e0b` |
| ADVISORY | `.ba` | Purple | `#c084fc` |
| PENDING / SEARCH REQUIRED | `.bpend` | Yellow | `#facc15` |
| CRITICAL / BLOCKER | `.bc` | Red | `#ef4444` |
| RESOLVED / GREEN | `.bg` | Green | `#34d399` |

### Required CSS Variables
All reports must use these root variables — never hardcode colors:
`--bg, --panel, --card, --border, --white, --muted, --dim, --cyan, --blue, --amber, --purple, --yellow, --red, --green, --orange`

### Print CSS
- All VERIFIED badges must be color-preserved in print (`-webkit-print-color-adjust:exact`)
- Sidebar and topbar hidden in print
- Section breaks with `page-break-after:always` on major sections

### Responsive
- Sidebar: hidden on mobile (<768px)
- Grid layouts: single column on mobile, 2-col on tablet+
- Map: minimum height 420px

### Gate Status Colors
- CLEARED: green
- AVAILABILITY PENDING: yellow
- NOT CLEARED: red
- BLOCKED: red + border

---

## PART 13 — FOOTER (Required on Every Report)

```
Generated by Nvirogear Property Intelligence System | nvirogear.com | intel@nvirogear.com
[Report Type] · [Version] · [Date] · [N] Sources Cited · [N] Sections
```

---

## PART 14 — WHAT MAKES A REPORT "PRODUCTION READY"

A report is PRODUCTION READY when:

- [ ] All 6 data layers attempted (gated layers documented with exact steps)
- [ ] OSS and ACS scores both present with full breakdown tables
- [ ] Cap rule applied and disclosed if any cap trigger is active
- [ ] Offer range formula shown with all inputs labeled
- [ ] Renovation tier selected and documented with rationale
- [ ] Gross spread calculated and shown as model math box
- [ ] All 3 investment scenarios present (or documented non-applicable)
- [ ] Title & Lien Snapshot box present
- [ ] Risk register has all 8 required fields per row
- [ ] 90-Day Action Checklist has ≥8 items with cost + timeline
- [ ] GIS map uses official polygon (not centroid estimate)
- [ ] Source ledger has ≥14 entries, one per claim
- [ ] All 8 disclaimers present
- [ ] Footer present
- [ ] All badges use correct CSS class (never inline color only)
- [ ] Print CSS present and tested

---

## ENFORCEMENT

This standard is enforced by Mr. Results (Overseer) before any report is uploaded or shared.

Any report that does not meet Part 14 checklist is NOT production ready and must be revised.

**There is no "close enough" for a production report. It either passes the checklist or it goes back.**

---

*Mr. Results (Overseer) — Nvirogear LLC*
*Enterprise Report Standard v2.0 — LOCKED May 19, 2026*
*Reference implementation: 2413 Plainfield Ave NE, Grand Rapids MI*
