# MICHIGAN PARCEL ACQUISITION PLAYBOOK v1
# Authority: Joe Smith, Nvirogear LLC
# Date: 2026-07-10
# Status: GOVERNING — produced from Day 1 acquisition success

---

## WHAT WORKED — PRESERVE THIS EXACTLY

### Confirmed Pattern (Ottawa, Muskegon, Wayne)

```
Endpoint type:  ArcGIS FeatureServer REST API
Query pattern:  /query?where=1%3D1
                 &outFields=*
                 &resultOffset={offset}
                 &resultRecordCount={PAGE_SIZE}
                 &returnGeometry=true
                 &geometryPrecision=6
                 &outSR=4326
                 &f=json
Page size:      1,000 records
Delay:          0.15–0.20 sec between pages (polite)
Retry:          max 5 consecutive errors → stop clean
Geometry:       outSR=4326 forces WGS84 (standard)
Hash:           SHA-256 per page + master hash of all page hashes
Output:         JSONL (one record per line)
Checkpoint:     written at intervals — resume_from_offset field
```

### Per-Run Required Outputs

Every county acquisition must produce:

1. `{county}_candidate_bundle.jsonl` — raw records, one per line
2. `{county}_manifest.json` — full provenance record (see schema below)
3. `{county}_checkpoint.json` — resume point if interrupted
4. BotRunLog entity record
5. CountyRegistry update (status → acquisition_locked ONLY after validation)

### Manifest Schema (mandatory fields)

```json
{
  "county": "",
  "state": "MI",
  "source_name": "",
  "source_url": "",
  "service_layer_id": "",
  "item_id_arcgis": "",
  "spatial_reference": "4326",
  "fetch_start": "",
  "fetch_end": "",
  "total_records": 0,
  "geometry_count": 0,
  "geometry_types": {},
  "error_count": 0,
  "duplicate_id_count": 0,
  "missing_batch_notes": "",
  "crs": "WGS84 EPSG:4326",
  "page_hashes": [],
  "source_sha256": "",
  "output_sha256": "",
  "resume_checkpoint_path": "",
  "licensing_note": "",
  "terms_checked": true,
  "warnings": [],
  "blocker_status": "",
  "candidate_status": "",
  "validated": false,
  "validation_report": {}
}
```

### Acquisition Lock Criteria (ALL must be true)

1. Requested IDs reconcile with returned IDs
2. Duplicate IDs reported (not hidden)
3. Missing batches resolved or documented
4. Geometry present at expected rate (>95% of records)
5. Sampled records fall inside county boundary
6. Source SHA-256 and output SHA-256 both recorded
7. Manifests verified
8. Source legally and technically appropriate (no bypassed controls)
9. Resume checkpoint written

**Never mark acquisition_locked merely because a large file was written.**

---

## RAW ACQUISITION FILES — IMMUTABLE

These files must never be overwritten, normalized, deduplicated, or "cleaned" in place:

| File | Records | SHA-256 (master) |
|------|---------|-----------------|
| ottawa_candidate_bundle.jsonl | 118,075 | 7f2a1ca91ff0b70019e0c2ee3034631643eb3a994a0a2bd8e24ba5f3eb88f69b |
| muskegon_candidate_bundle.jsonl | 83,773 | 4a2552779a5d4f19a051d84785b9bfae8923aa7ca8c30122f595d1a83ca4df03 |
| wayne_candidate_bundle.jsonl | 768,119 | 531c68384e5bb68a45bc7333657e5c0d4475c1b4143601dc98ad182f9869d511 |

Any dedup, normalization, or enrichment produces a NEW derived file. Raw files stay frozen.

---

## DISCOVERY PROCEDURE (every county, every time)

1. Open official county GIS or ArcGIS portal
2. Identify application or dataset item ID
3. Retrieve item metadata and application configuration
4. Locate public FeatureServer, MapServer, download, GeoJSON, or open-data endpoints
5. Test:
   - Layer metadata (`?f=json`)
   - `returnCountOnly=true`
   - `returnIdsOnly=true`
   - One-record query (`resultRecordCount=1`)
   - Geometry type
   - Attribute completeness (parcel ID, owner, address, acreage minimum)
   - Pagination or ObjectID batching
   - Maximum record count per page
   - Supported output formats
6. Confirm layer represents countywide parcels (not township or city subset)
7. Check whether separate tables hold assessment attributes
8. Record: service owner, URL, item ID, layer ID, spatial reference, update date, terms, access restrictions

---

## ACQUISITION RULES

- Use ObjectID batching or advertised pagination — never skip pages
- Respect service rate limits — back off on 429/503 errors
- Resume from checkpoints — never restart completed batches
- Never bypass: login systems, payment systems, rate limits, CAPTCHAs, tokens, access controls
- Do not promote a source until: record counts, geographic extent, sample parcels, and attribute fields pass validation

---

## BLOCKED COUNTY — REQUIRED DOCUMENTATION

When a county cannot be acquired:

```json
{
  "failure_code": "DNS_FAIL | HTTP_404 | HTTP_403 | TIMEOUT | LAYER_NOT_FOUND | PAID_DATA | NO_PUBLIC_SOURCE",
  "attempted_urls": [],
  "last_attempt_at": "",
  "alternate_sources_checked": [],
  "revisit_strategy": "",
  "blocker_notes": ""
}
```

---

## DAY 1 RESULTS — BASELINE

| County | Records | Geometry | Errors | SHA-256 |
|--------|---------|----------|--------|---------|
| Ottawa | 118,075 | 118,075 polygon | 0 | 7f2a1ca9... |
| Muskegon | 83,773 | 83,766 polygon / 7 none | 0 | 4a255277... |
| Wayne | 768,119 | 768,091 polygon / 28 none | 0 | 531c6838... |
| **Total** | **969,967** | **969,932 polygon** | **0** | — |

Pull time: Ottawa ~90s, Muskegon ~5min, Wayne ~11min
Combined file size: 918MB

---

## THE NEW STANDARD

*"We identified the authoritative public source, validated the complete county dataset, preserved its provenance, acquired it without bypassing controls, reconciled the records, hashed the result, and made the entire operation repeatable."*

Not: "we found a map."
Not: "we wrote a large file."

The standard is: provenance-backed, validated, locked, reproducible.

---

*Nvirogear LLC — Michigan Parcel Acquisition Playbook v1*
*Mr. Results (Overseer) — 2026-07-10*
