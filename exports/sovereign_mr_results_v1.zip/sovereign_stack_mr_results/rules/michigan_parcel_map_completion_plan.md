# MICHIGAN PARCEL MAP COMPLETION PLAN
# Issued by: Mr. Results (Overseer)
# Date: 2026-05-17
# Status: ACTIVE — Priority Mission

---

## OBJECTIVE

Complete a full parcel map of Michigan — all 83 counties, every parcel, polygon geometry where available, centroid fallback where not.

---

## CURRENT STATE

| County | Status | Records |
|--------|--------|---------|
| Muskegon | BLOCKED (GIS pass needed) | ~22 in pipeline |
| Genesee | GATE PASSED | 5 in public_projection |
| Mason | DISCOVERY | 15 in Supabase |
| Newaygo | IN SUPABASE | 37,055 |
| Lake | IN SUPABASE | 26,188 |
| All others (78) | NOT STARTED | 0 |

---

## DATA SOURCE HIERARCHY (Michigan-Specific)

### Tier 1 — Statewide (covers all 83 counties)
1. **Michigan DTMB Statewide Parcel Layer**
   - URL: https://www.michigan.gov/dtmb/services/maps/mgf-data-hub/boundaries-and-mgf/tax-parcels
   - ArcGIS REST services at gisp.mcgi.state.mi.us
   - Updated statewide — but counties maintain their own; not always current
   - **THIS IS THE PRIMARY TARGET — hit this first for every county**

2. **Michigan GIS Open Data Portal**
   - URL: https://gis-michigan.opendata.arcgis.com
   - Datasets tagged 'ownership', 'parcels', 'tax parcels'
   - DNR LOTS Parcels layer: land ownership statewide
   - Free, public, downloadable

3. **LIAA (Land Information Access Association)**
   - Covers most northern/rural Michigan counties
   - URL pattern: maps.liaa.org/[county]parcels/
   - Confirmed for Mason, others likely

4. **BS&A Online**
   - URL pattern: bsaonline.com/?uid=[county_uid]
   - Covers ~70 of 83 counties
   - Public assessing search without login (most counties)

5. **Michigan State Land Bank (ePropertyPlus)**
   - URL: https://public-mlb.epropertyplus.com/landmgmtpub/app/base/propertySearch
   - Statewide tax-reverted / land bank inventory

### Tier 2 — County-Specific GIS Viewers
Per usparcelmaps.com (updated March 2026), every Michigan county has a parcel viewer link.
Most are ArcGIS WebApp Viewers — meaning there is a FeatureServer/MapServer behind every one.

Pattern for extracting REST endpoint from viewer URL:
- ArcGIS WebApp: `?id=[GUID]` → query `https://[org].arcgis.com/sharing/rest/content/items/[GUID]?f=json` → get `url` field → that's the service URL
- FetchGIS: `app.fetchgis.com/?currentMap=[county]` → internal API
- Colligo: `colligogis.com/desktop/` → county-specific REST behind it

### Tier 3 — Fallback Sources
- Recent sales listings (Zillow, Redfin, Realtor.com) — parcel ID + address minimum, no polygon
- Tax-sale.info auction catalogs — parcel IDs for tax-delinquent properties only
- LandWatch / LandHub — rural/vacant land listings
- Craigslist Michigan — owner-listed properties (address + price only)

---

## ALL 83 MICHIGAN COUNTIES — PARCEL SOURCE MAP

### Priority Tier A — High Population / High Value (start here)
| County | Est. Parcels | Known GIS Source |
|--------|-------------|-----------------|
| Wayne | ~600K | waynecounty.com + Bid4Assets |
| Oakland | ~550K | oakgov.com/gis ArcGIS |
| Macomb | ~370K | macombgov.org GIS |
| Kent | ~280K | accesskent.com GIS |
| Washtenaw | ~175K | washtenaw.org GIS |
| Ingham | ~160K | ingham.org GIS |
| Ottawa | ~155K | miottawa.org GIS |
| Genesee | ~155K | DONE — 5 live |
| Kalamazoo | ~140K | kalamazoocounty.gov GIS |
| Saginaw | ~120K | saginawcounty.com GIS |

### Priority Tier B — Mid-Size / Active Markets
Allegan, Barry, Bay, Berrien, Branch, Calhoun, Cass, Clinton, Eaton, Gratiot, Hillsdale, Huron, Ionia, Isabella, Jackson, Lapeer, Lenawee, Livingston, Midland, Monroe, Montcalm, Muskegon (BLOCKED), Newaygo (IN), Oceana, St. Clair, St. Joseph, Sanilac, Shiawassee, Tuscola, Van Buren

### Priority Tier C — Northern / Rural / Recreational (land investor targets)
Alcona, Alger, Alpena, Antrim, Arenac, Baraga, Benzie, Charlevoix, Cheboygan, Chippewa, Clare, Crawford, Delta, Dickinson, Emmet, Gladwin, Gogebic, Grand Traverse, Houghton, Iron, Iosco, Keweenaw, Lake (IN), Leelanau, Luce, Mackinac, Manistee, Marquette, Mason (IN), Mecosta, Menominee, Missaukee, Montmorency, Ogemaw, Ontonagon, Osceola, Oscoda, Otsego, Presque Isle, Roscommon, Schoolcraft, Wexford

---

## EXECUTION STRATEGY

### Phase 1 — Statewide Layer Grab (Days 1-3)
Target: Michigan DTMB + GIS Open Data Portal
Method: Query ArcGIS FeatureServer REST APIs by county FIPS or bounding box
Output: Bulk GeoJSON per county → pipeline ingest

Steps:
1. Find the statewide parcel FeatureServer URL at gisp.mcgi.state.mi.us
2. Query with `where=COUNTY_CODE='[FIPS]'&outFields=*&returnGeometry=true&f=geojson`
3. Paginate with `resultOffset` until `exceededTransferLimit=false`
4. Write each county batch to RawExportRecord
5. Run pipelineIngest for each county
6. Log to BotRunLog

### Phase 2 — County GIS Viewers (Days 3-10)
For each county NOT covered by statewide layer:
1. Get the viewer URL from usparcelmaps.com list
2. Extract the ArcGIS GUID from the URL
3. Query the items endpoint to get the FeatureServer URL
4. Pull parcels via REST API
5. Same ingest pipeline

### Phase 3 — BS&A Fill (Days 10-14)
For counties where GIS geometry is missing:
1. Hit BS&A for owner name, address, SEV, acreage, last sale
2. Geocode addresses via Census Bureau Geocoder
3. Ingest as centroid records labeled `geometry_type: centroid`

### Phase 4 — LIAA Fill (Northern Counties)
For northern/rural counties not on BS&A:
1. Use LIAA parcel search APIs (maps.liaa.org)
2. Same pull-and-ingest pattern
3. Cross-reference with DTMB statewide layer

---

## GIS BOT / JET — STANDING ORDERS

For the parcel map mission, Jet operates in BULK INTAKE MODE (not single-parcel report mode):

1. **Primary task:** Extract parcel polygons from county ArcGIS REST services
2. **Fallback 1:** If no polygon → pull centroid from address geocoder
3. **Fallback 2:** If no county GIS → pull from BS&A (owner, address, acreage)
4. **Fallback 3:** If all else fails → pull from recent listing data (Zillow/Redfin/LandWatch) for address + coordinates — label as `source_confidence: low`, `geometry_type: centroid_estimated`
5. **Label everything:** Every record must have `geometry_type`, `source_name`, `source_confidence`
6. **Never block on perfection:** A centroid record is better than no record. We can upgrade geometry later.

---

## DATA STANDARDS (Bulk Intake)

Minimum fields per record:
- parcel_id (county-issued PIN)
- county
- state = "MI"
- address OR situs_address
- centroid_lat + centroid_lng (or null with geometry_type=no_geometry)
- geometry_type: polygon | centroid | centroid_estimated | no_geometry
- source_name
- source_url
- source_confidence: high | medium | low
- acreage (if available)
- owner_name (if public)

NOT required for bulk intake (can be added later):
- Environmental flags (Historian pass)
- Market data (Sales Bot pass)
- Auction status (Site Tracker pass)
- Full 21-section report

---

## SUPABASE WRITE CONTRACT

- All records go through pipelineIngest → public_projection (upsert on parcel_id)
- INSERT-then-PATCH only. No delete+insert.
- Mr. Results is the only authorized Supabase writer.
- Batch size: 500 records max per push
- Log every batch to BotRunLog and ConnectorRunLog

---

## SUCCESS METRICS

| Milestone | Target |
|-----------|--------|
| 10 counties seeded | Week 1 |
| 30 counties seeded | Week 2 |
| 60 counties seeded | Week 3 |
| All 83 counties seeded | Week 4 |
| Polygon geometry > 50% | Month 2 |
| Full environmental overlay | Month 3 |

---

*Mr. Results (Overseer) — Nvirogear LLC — Michigan Parcel Map Completion Plan*
