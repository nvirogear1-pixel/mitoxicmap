# NVIROGEAR FOUR-LANE DOCTRINE v1.0 — LOCKED
**Issued by:** Joseph Smith (Nvirogear LLC), captured by Mr. Results (Overseer)
**Date:** 2026-07-08
**Status:** GOVERNING — applies to all corridor/community-facing work (Heights-Ravenna, Egelcraft, Laketon, Clover Estates, Violet Ave, and any future site)

---

## PURPOSE

Keep the mission legal, credible, and useful to residents by never mixing four distinct lanes. Mixing lanes is what turns a credible public-records project into something dismissible as activism, a health study, or a legal threat.

---

## LANE 1 — PUBLIC EDUCATION

**Purpose:** tell residents what public records already say. Nothing more.

**Only use:**
- EGLE / EPA / MDHHS / ATSDR records
- County parcel/tax records
- Public statute text
- FOIA-returned documents
- Resident-consented information

**Never:** confidential field data, or any statement that PFAS caused anyone's illness. ATSDR is the anchor — its language is associations, and risk depends on dose, route, duration, individual factors, and access to safer water/healthcare.

**Standing public line (use verbatim where a summary line is needed):**
> "Public records document PFAS contamination, private-well concerns, and federal health associations. Nvirogear does not claim causation. Nvirogear documents records and resident concerns so agencies, researchers, and communities can decide whether formal review is warranted."

---

## LANE 2 — RESIDENT REGISTRY

**Purpose:** collect voluntary, private, self-reported concerns.

**Name it:** "Voluntary Community Concern Registry" — NEVER "health study," "exposure study," or "cancer cluster."

**Form fields:**
- Name (optional)
- Contact (optional)
- Exact address (optional)
- General area / cross street
- Years lived there
- Water source: private well / public water / bottled / unknown
- Whether well was tested
- Whether they received results
- Health concern category
- Whether Nvirogear may contact them
- Whether they consent to share de-identified data

**Registry statement (verbatim):**
> "This registry is not medical care, not a diagnosis, not emergency assistance, and not a formal epidemiological study. It collects voluntary resident-reported concerns to determine whether public-health review, water testing, records requests, or academic partnership should be requested."

**Do NOT collect medical records.** Categories and consent only — medical records are a privacy liability at this stage.

**Consent gate (must appear BEFORE the form, all must be checked to proceed):**
- I understand this is voluntary.
- I understand this is not medical care.
- I understand Nvirogear does not determine causation.
- I understand public reports will be aggregated/de-identified unless I give written permission.
- I understand emergencies should go to 911/medical care.

---

## LANE 3 — OFFICIAL RECORDS PRESSURE

**Purpose:** force written answers via certified/FOIA requests.

**Track A — Assessor / Equalization.** Ask:
> "Has the assessing unit ever applied, considered, denied, or referred to EGLE any environmental-contamination loss under MCL 211.34d(1)(h)(iv) for parcels in this corridor?"

**Track B — EGLE / township / county water-main file.** Ask:
> "What data justified the emergency water-main project, which homes were connected, which homes were considered but not connected, and which private wells remain?"

**Certified assessor letter core text (verbatim, use every time):**
> "Please provide written confirmation whether any environmental-contamination taxable-value loss under MCL 211.34d(1)(h)(iv) has been applied, considered, denied, recorded, or referred to EGLE for any parcel in the Heights-Ravenna / Violet Ave / Brooks Road / Laketon / Egelcraft corridor. If none, please state that no responsive record exists."

---

## LANE 4 — PARTNER / FUNDING PACKAGE

**Purpose:** make the mission viable for Trace Labs, MCC, funders, and agencies.

**Package name:** "Community Water Verification + Lab Technician Training Pilot" — NOT lawsuit, NOT blame, NOT "prove disease."

**Pitch structure:** Nvirogear provides the digital documentation layer — resident consent, coded sample IDs, water-source history, QR sample kits, chain-of-custody, field blanks, duplicates, resident-first notification, redacted public reporting. Trace Labs advises on sample handling/lab workflow. MCC supports student learning, GIS, public education, workforce development. Certified PFAS analysis performed by an approved lab where required.

---

## EXECUTION ORDER

**Step 1 — Clean the public-facing homepage/site.** Lead line:
> "This site summarizes public records and collects voluntary resident concerns. It does not claim that contamination caused any individual illness. It does not replace medical care, legal advice, EGLE, MDHHS, EPA, or certified laboratory testing."
Buttons: Check public records / Submit a private concern / Ask if your well was tested / Sign up for updates / View source documents.

**Step 2 — Consent gate before the registry form** (see Lane 2 consent gate above).

**Step 3 — One-page handout.** Title: "What Public Records Say About PFAS Near Brooks Road / Laketon Avenue / Egelcraft." Lead with records, not health. Include: EGLE active investigation, Egelcraft historical drinking-water PFAS detections, expanded well testing, contact Peter Van Heest, MDHHS toxicology hotline, registry QR code, no-causation disclaimer.

**Step 4 — Certified assessor letter** using the Lane 3 core text.

**Step 5 — Publish only "Registry Snapshot" aggregates.** No names, no addresses, no diagnoses attached to homes. Format example:
```
38 voluntary submissions
22 private-well households
14 unsure whether well was tested
9 report not receiving results
12 kidney/urinary concerns
6 thyroid concerns
5 developmental concerns
0 causation claims made by Nvirogear
Request: formal public-health review warranted
```

---

## THE WORDING RULE (use this substitution table everywhere, always)

| Don't say | Say |
|---|---|
| PFAS caused these illnesses | Residents report health concerns in an area with documented PFAS records |
| This proves exposure | This warrants verification of water source, sampling history, and exposure pathway |
| The state poisoned people | Public records require reconciliation with water-response and assessment records |
| They intentionally hid it | No adequate public record has been identified showing residents were fully informed |
| This is a health study | This is a voluntary community concern registry |
| Everyone is overtaxed | Reviewed records show no identified environmental-loss adjustment |
| 211.34d was illegally ignored | No identified use of MCL 211.34d(1)(h)(iv) has been found in reviewed records |

---

## THE ONE PARAGRAPH THAT GOES EVERYWHERE (verbatim, standing boilerplate)

> "Nvirogear does not claim that PFAS or any contamination caused any specific person's illness. Nvirogear documents public environmental records, water-response records, property-assessment records, and voluntary resident-reported concerns. The purpose is to determine whether formal well testing, public-health review, assessment review, or agency action is warranted."

---

*Nvirogear LLC — Four-Lane Doctrine v1.0 — Locked 2026-07-08*
