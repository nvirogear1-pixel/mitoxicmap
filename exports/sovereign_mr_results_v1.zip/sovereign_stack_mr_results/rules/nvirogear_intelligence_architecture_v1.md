# Nvirogear Land Intelligence Architecture v1.0
## GOVERNING DOCTRINE — ALL BUILDS
## Date: 2026-05-25 | Authority: Joe Joe (Owner) | Enforced by: Mr. Results

---

## WHAT THIS SYSTEM IS

This is a **parcel intelligence engine**.

- A land MRI
- A 3D earth slice viewer
- An environmental risk viewer
- A utility context viewer
- A property feasibility engine
- A truth-linked underground map
- An evidence visualization platform

**The land itself is the product. The parcel is the interface. Everything else supports that experience.**

---

## WHAT THIS SYSTEM IS NOT

- NOT a SCADA dashboard
- NOT a utility tracing-only workflow
- NOT a city operations desktop
- NOT a floating sidebar app full of text bars
- NOT a field utility locate app
- NOT a GIS panel app
- NOT a report viewer

**The intelligence report is NOT the final experience.**
**The report is the evidence ingestion engine that feeds the 3D parcel intelligence renderer.**

FieldTrace is a SEPARATE tool that CREATES verified truth data.
This system CONSUMES that truth. FieldTrace records appear as attached evidence — verified traces, operator proof, inspection history. They are inputs, not the product.

---

## CORE SYSTEM ARCHITECTURE (CANONICAL)

```
REPORT ENGINE
      ↓
SOURCE PARSER
      ↓
CONFIDENCE ENGINE
      ↓
SPATIAL NORMALIZER
      ↓
PARCEL INTELLIGENCE ENGINE
      ↓
3D LAND SLICE RENDERER  ← THIS IS THE PRODUCT
```

The renderer is the product.
The reports only feed the renderer.

---

## PRIMARY UX GOAL — THE LAND BECOMES A 3D OBJECT

When a user selects a parcel:

**THE LAND SHOULD BECOME A 3D OBJECT.**

Not a list. Not floating bars. Not panels everywhere.

The actual ground should:
- Elevate / pop out from the map
- Slice open
- Reveal underground conditions
- Reveal utility proximity
- Reveal environmental intelligence
- Reveal terrain composition
- Reveal infrastructure relationships

The parcel should feel tangible. Like:
- A physical land block
- A core sample
- An earth slice
- A geologic scan

**The underground layers should visually exist INSIDE the land mass.**

---

## TURN SOURCES INTO VISUAL SYSTEMS — MANDATORY TRANSLATION

Every scraped source must become a spatial layer, terrain modifier, subsurface clue, visual confidence object, or parcel intelligence signal.

| Source | NOT This | BECOMES This |
|---|---|---|
| CIP PDF | A document | Glowing reconstruction corridors, active underground work zones, confidence-weighted infrastructure overlays |
| Wellogic well logs | A table | Sand bands, clay bands, groundwater depth, bore-column interpolation, subsurface composition |
| PFAS data | A bullet point | Underground plume visualization, contamination influence zones, environmental warning haze, groundwater risk geometry |
| FEMA flood zones | Flat polygons on a map | Terrain flood-fill simulation, animated watershed overlays, drainage-flow visualizations |
| ROW + easements | GIS lines | Semi-transparent underground corridors, infrastructure likelihood zones, utility pathway hints |
| Land bank demolitions | Markers | Ghost infrastructure zones, abandoned laterals, capped service risk markers, redevelopment opportunity overlays |
| Drain Commission data | Layer list | Terrain-flow intelligence, likely stormwater corridors, underground hydrology patterns |

**The land slice is the report.**

---

## LAYER VOCABULARY (ordered surface to deep)

1. Topsoil
2. Clay
3. Sand
4. Bedrock
5. Water table
6. Sewer mains
7. Water lines
8. Gas lines
9. Electrical / Fiber
10. Drain tile
11. Septic feasibility zone
12. Flood risk zones
13. Wetlands
14. PFAS proximity buffers
15. Contamination plume zones
16. Nearby utility corridors
17. Easements
18. Modeled unknown zones

---

## THE MOST IMPORTANT RULE — NEVER FAKE CERTAINTY

Every layer MUST carry:
- Source lineage
- Confidence type
- Verification status
- Provenance
- Date
- Evidence type

### Confidence Visual Language (MANDATORY)

| Status | Visual Behavior |
|---|---|
| VERIFIED | Solid, glowing, stable — full opacity, blue/cyan glow |
| OFFICIAL | Clean, crisp — municipal-grade rendering, subdued |
| MODELED | Translucent, dashed, slightly noisy — clearly estimated |
| DEMO | Orange tint, pulsing — intentionally marked prototype |
| UNVERIFIED | Unstable flicker, warning tint, visually uncertain, noisy wireframe |

**This is not optional decoration. Confidence must be rendered, not just labeled.**
**NEVER visually imply certainty where certainty does not exist.**

---

## WHAT THE USER SHOULD FEEL

When a parcel is selected:
- The land physically rises from the map
- The parcel extrudes upward
- The earth slices downward
- Underground context becomes visible
- Infrastructure appears embedded INSIDE the land
- Contamination appears volumetric
- Groundwater becomes depth-aware
- Terrain layers become physically readable

The experience should feel like:
- Cutting open the earth
- Viewing a geologic core sample
- MRI scan of land
- Digital excavation window
- Environmental x-ray

NOT: a dashboard, a utility app, a municipal software panel.

---

## UNDERGROUND DATA RENDERING RULES

DO NOT render underground layers as:
- Floating bars
- Stacked cards
- Giant side menus

The underground data should exist **INSIDE THE LAND MASS**.

Small contextual pop-outs are okay:
- Tap utility
- Small info bubble appears
- Shows source + confidence + depth + notes

**But the LAND is the centerpiece. Always.**

---

## VISUAL DIRECTION

### Move AWAY from:
- Stacked floating bars
- Giant accordion panels
- Text-heavy UI
- Fake "cyberpunk" clutter
- Noisy shader overload
- Giant enterprise dashboard bloat
- Unnecessary analytics panels
- Overbuilt volumetric simulation
- Fake AI predictions
- Endless menus

### Move TOWARD:
- Cinematic but usable
- Minimal HUD overlays
- Tactile land visualization
- True depth slicing
- Layered transparency
- Smooth camera motion
- Physically understandable terrain

**The user should feel: "I am inspecting the actual earth beneath this property."**

---

## EXPERIENCE REFERENCES

- Apple Maps (smooth, minimal, spatial)
- GIS (authoritative, layered, evidence-linked)
- MRI scan (slices, layers, diagnostic)
- Iron Man HUD (purposeful overlays — nothing decorative)
- Geologic cutaway (depth, material, cross-section)
- Game-engine land visualization (performant, tactile)

---

## TECHNICAL DIRECTION

### Prioritize:
- Parcel extrusion from map
- Terrain slicing
- Performant WebGL (60fps mobile target)
- Depth rendering
- Lightweight volumetric illusion
- Mobile-first rendering
- Local-first architecture
- Reusable geometry systems
- Evidence-linked metadata on every object
- Progressive loading (show what we know, load the rest)
- Confidence-aware rendering (visual = data quality)
- Mobile GPU optimization

### Avoid:
- Heavy post-processing that kills mobile performance
- Unused analytics panels
- Fake volumetric predictions
- Text dumps instead of visual intelligence
- Giant enterprise GIS clutter

---

## INTERACTION FLOW (CANONICAL)

```
User sees map (Page 1: flat, pins, parcels)
         ↓
User taps parcel
         ↓
Land elevates / pops out — 3D transition begins
         ↓
Page 3: Full-screen earth block (the parcel)
  - Rotating geologic cross-section
  - Layers inside the actual land mass
  - Confidence-coded rendering per layer
  - Tap any layer → Ground Truth Card slides up
  - Ground Truth Card = source + confidence + date + next step
         ↓
User can: rotate, slice, tap layers, expand sheet
         ↓
Everything stays grounded in evidence — DEMO/MODELED/VERIFIED always visible
```

---

## FIELDTRACE RELATIONSHIP (LOCKED)

FieldTrace = separate field workflow tool that CREATES verified truth
This system = CONSUMES FieldTrace output as attached parcel evidence

FieldTrace data appears as:
- Verified underground traces (confidence: VERIFIED)
- Operator evidence / proof photos
- Inspection history
- Infrastructure confirmation records
- Municipal updates

When FieldTrace data exists for a parcel → layers upgrade from MODELED → VERIFIED automatically.

---

## MULTI-LENS ARCHITECTURE (from master directive v2.3)

ONE MPIO (Master Parcel Intelligence Object) → FIVE lenses + ONE spatial lens:
1. Investigative — forensic truth + contradiction engine
2. Investor — deal math + ROI
3. Homeowner — plain-English reality
4. Sportsman — habitat / hunting / water
5. Commercial/Enterprise — env exposure + liability
6. **Spatial — the 3D earth slice** ← sixth output, fed by same MPIO

---

## THE FINAL VISION

This system becomes:
- The Apple Maps of underground intelligence
- A land MRI
- Parcel x-ray visualization
- Environmental truth engine
- Infrastructure context viewer
- Feasibility intelligence system
- Evidence-linked earth renderer

**The reports are the fuel. The land slice is the product.**

---

## GOVERNING SUMMARY

```
Parcel → MPIO → Truth Engine → Spatial Slice (3D) + 5 Report Lenses
                              ↑
                    Evidence-linked, confidence-coded
                    NEVER faking certainty
                    ALWAYS showing what we know vs what we estimated
                    EVERY source becomes a visual layer — not a text panel
```

*Nvirogear LLC | Architecture v1.0 | 2026-05-25 | Mr. Results (Overseer)*
