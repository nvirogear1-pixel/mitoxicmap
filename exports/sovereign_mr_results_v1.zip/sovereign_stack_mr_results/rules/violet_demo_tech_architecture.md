# VIOLET DEMO — TECH ARCHITECTURE SPEC
# Date: May 18, 2026 | Mr. Results | INTERNAL

## THE ONE PROOF
One parcel. One report. Every claim clickable to map evidence and source proof.
Parcel: 3101 Violet Ave, Muskegon Heights MI 49444
PIN: 61-10-840-000-0027-00
Centroid: 43.1998 N / -86.2383 W

## TECH STACK — PHASE 1

### Map
- Leaflet.js (CDN, no build required)
- GeoJSON layers (parcel polygon, environmental pins)
- Click-to-feature events → source ledger panel
- 1-mile + 3-mile radius rings (L.circle)
- Layer toggle controls (L.control.layers)
- NO MapLibre yet — upgrade Phase 3+

### Data
- Base44 entities (GisLayer, ParcelLayerMatch, ReportFlag, SourceLedgerEntry, ParcelRecord)
- Supabase read for parcel_geometry table (fallback)
- All seeded data confirmed live

### Auth (Phase 1 — demo only)
- Role simulation in demo (Admin / Client toggle)
- Supabase Auth: Phase 4
- For demo: admin sees internal fields, client does not

### Report Output
- HTML (primary — already working)
- PDF: @media print stylesheet (already implemented)
- JSON export: structured parcel risk record
- CSV: source ledger table

### Agent Layer
- HIDDEN — never visible in demo UI
- All outputs pre-compiled into entity records
- Demo reads from entities only — no live agent dispatch in demo flow

## 9 REQUIRED SCREENS

1. LOGIN — email/password form, role selector (demo mode)
2. DASHBOARD — recent parcels, unresolved blockers count, gate status summary
3. PARCEL SEARCH — address search box, results list
4. PARCEL DETAIL — all fields, tabs, geometry status, gate badge
5. GIS EVIDENCE MAP — Leaflet full-screen, layer toggles, click-to-source
6. REPORT VIEWER — 17-section report, claim buttons, source ledger inline
7. SOURCE LEDGER — full table, filterable, expandable rows
8. REVIEW / GATE CENTER — blockers list, confirm/resolve/escalate actions
9. EXPORT BUNDLE — HTML, PDF, CSV, JSON, GeoJSON links

## CLAIM → MAP → SOURCE LEDGER BEHAVIOR

Every environmental/tax/ownership claim must have 3 buttons:
- [View on Map] → Leaflet zooms to relevant feature, highlights layer
- [View Source] → source ledger panel slides in with full SL record
- [Why Flagged?] → plain-language explanation of flag rule
- [What Needs Verified?] → next action with resolution path

This is the CORE differentiator. No other platform does this.

## VISIBILITY ENFORCEMENT IN DEMO

Admin role sees:
- All 9 screens
- Internal notes fields
- Agent run timestamps (not agent names)
- Hydrogen layer row (labeled INTERNAL ONLY)
- Provenance fields (not labeled "Bitcoin" — labeled "Record Integrity")

Client role sees:
- Screens 1–9 with INTERNAL_ONLY fields hidden
- No hydrogen layer
- No provenance fields
- No agent names anywhere

## MAP LAYER LOAD ORDER (Phase 1)

1. Parcel boundary polygon (GeoJSON from county source)
2. Thomas Solvent pin (EPA CERCLIS confirmed coords)
3. Airport PFAS pin (FAA KMKG confirmed coords)
4. 1-mile ring from subject centroid
5. 3-mile ring from subject centroid
6. Bedrock geology label (overlay reference)
7. [INTERNAL ONLY] Activity heatmap — admin only

## DEMO FLOW (5 minutes)

0:00 — Login (admin role)
0:30 — Dashboard — see 1 parcel, 3 blockers flagged
1:00 — Search "3101 Violet" — parcel card appears
1:15 — Open Parcel Detail — boundary visible, gate = NOT CLEARED
1:30 — Click "Open Report" → Report Viewer loads
2:00 — Section 07: Superfund flag — click [View on Map]
2:15 — Map zooms to Thomas Solvent pin (1.2mi NE)
2:30 — [View Source] → SL-VIOLET-01 expands (EPA CERCLIS, federal_primary, VERIFIED)
2:45 — Back to report — Section 06: Tax Anomaly — [Why Flagged?]
3:00 — Decision tree appears — -69.5% SEV, quarantine active
3:15 — Review/Gate Center — 3 blockers, 2 investigation required
3:30 — Click [Resolve: Treasurer Confirmed] on water source — gate recalculates
3:45 — Export Bundle → HTML downloads
4:00 — [Switch to Client Role] — hydrogen layer gone, internal fields hidden
4:30 — Demo complete

## WHAT SUCCESS LOOKS LIKE

The demo proves: every claim is traceable to a map pin, a source record, a confidence badge, and a next action. That is the entire value proposition in one 5-minute workflow.

## DO NOT BUILD YET

- Statewide batch UI
- FutureMIS screens
- B2B pricing UI
- Organization management
- 2FA / SSO
- MapLibre upgrade
- Full 83-county selector

Build ONE parcel. Prove the chain. Then scale.
