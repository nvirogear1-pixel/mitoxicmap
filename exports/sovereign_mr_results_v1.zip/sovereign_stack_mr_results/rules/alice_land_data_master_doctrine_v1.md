# ALICE_LAND_DATA_MASTER — Structure Doctrine v1.1
**Status:** LOCKED 2026-09-05 (v1.1 restructure, supersedes v1.0 same-day layout) · Pending Jet structural reaction pass
**Authority:** Joe Smith, Nvirogear LLC · Locked by: Mr. Results (Overseer)
**Supersedes:** v1.0 (backup: alice_land_data_master_doctrine_v1.md.backup.20260905-1345)
**Change driver:** Two-corpus reality (v1.2 eight-county RAW vs Sept 3 UP canonical set) + four layers of truth

---

## THE SEPARATION LAW (GOVERNING — DOES NOT CHANGE)

1. One source record lives ONCE in intake. It is never duplicated into individual parcels.
2. Parcel drawers stay tiny. Drawers contain REFERENCES, not data.
3. Spatial relationships live in indexes, not in parcel folders.
4. The UI loads deep layers only when a user clicks into the parcel.
5. **If Jet's Base44 entities need something different, we adjust the ADAPTERS — never this structure.**

## IDENTITY LAW (NEW IN v1.1 — GOVERNING)

- Canonical identity = **county + normalized parcel_id**. Never merge on coordinates alone.
- Alt IDs and source IDs are PRESERVED on the canonical record.
- Geometry confirms or enriches identity; it never creates identity without an explicit exception workflow.
- Point-only records are labeled point_only — they are NEVER mislabeled as verified boundary geometry.

## FOUR LAYERS OF TRUTH (NEW IN v1.1 — GOVERNING)

1. **RAW-preserved intake** — immutable county JSONL exactly as received, hashed as received. Never modified.
2. **Normalized county records** — IDs normalized, source provenance attached, metadata present, NO silent dedupe. Every record survives this layer.
3. **Canonical registry** — ONE canonical parcel identity per county + normalized parcel_id, trust chain attached, collision log for every merge (no silent collapses).
4. **Geometry attachment layer** — polygons joined in from GIS outputs; centroid QA, point-on-surface, and spatial-cell fields generated when geometry arrives. Point-only records stay honest until polygons land.

## DIRECTORY STRUCTURE (LOCKED v1.1)

```
ALICE_LAND_DATA_MASTER/
│
├── 00_INTAKE/
│   ├── V1_2_EIGHT_COUNTY_RAW/      # 2.6GB — the 8 RAW county JSONL, immutable, hashed as received
│   └── UP_CANONICAL_SEPT03/        # 102,228-record UP-heavy set (Iron/Marquette/Ottawa) — SEPARATE corpus
│
├── 01_REGISTRY/
│   ├── v1_2/
│   │   ├── normalized/             # layer 2 — every record, no dedupe
│   │   ├── canonical/              # layer 3 — one identity per county+parcel_id
│   │   └── collisions.jsonl        # every multi-record collapse, logged
│   └── up_land/
│       └── canonical/              # Sept 3 UP corpus, own family
│
├── 02_GEOMETRY/
│   ├── v1_2/                       # layer 4 — polygon attachment + centroid QA + spiral cells
│   └── up_land/
│
├── 03_DRAWERS/                     # tiny drawers, references only
│
├── 04_SPATIAL_INDEX/
│   ├── parcel_cells/               # per-cell parcel membership (0.01° grid, spiral expansion)
│   └── parcel_cells_index.jsonl
│
├── 05_RELATIONSHIPS/
│   └── parcel_to_source.jsonl      # parcel → intake source edges (more edge types attach later)
│
└── 90_MANIFESTS/                   # per-family manifests — see manifest contract below
```

Domain families (environmental, sampling, health, permits, historian, tax, infrastructure) attach AFTER the registry exists, through relationships — they never alter the registry.

## MANIFEST CONTRACT (NEW IN v1.1 — GOVERNING)

Every family manifest in 90_MANIFESTS must state exactly:
- what the corpus IS (provenance, acquisition date, source files with SHA-256)
- records seen
- records that survived canonicalization
- point-only count
- polygon count
- which source files fed which counties
- builder version and run IDs

Purpose: no corpus can masquerade as another (the UP Sept 3 set can never contaminate the v1.2 count).

## SECOND-PASS GEOMETRY WORKFLOW (when Jet's polygons land)

```
canonical parcel → attach polygon → validate centroid → point-on-surface if needed
→ assign spatial cell → emit drawer refs → update relationship graph
```

The registry build never blocks on Historian, environmental, health, or permit data — they attach afterward through the registry.

## UI LOADING FLOW (LOCKED)

- Open ALICE → Cesium needs ONLY geometry layer + spatial index.
- Click parcel → drawer.json loads.
- Click a domain → ALICE follows the matching relationship edge. Deep layers load on demand.

## MANDATORY BUILD REQUIREMENTS (unchanged)

1. Centroid QA + representative point. Never ship an outside-centroid.
2. Spiral/spatial-cell key on every parcel with coordinates.
3. Relationship graph — domains attach via edges, never by copying.
4. Source ledger + cryptographic hashes — every fact answers "where did this come from?"

## SPIRAL CELL SPEC

0.01° grid: col = floor((lng+91)/0.01), row = floor((lat+43)/0.01), key = MI_{col:05d}_{row:05d}. Outward expansion = Chebyshev rings from origin cell. See 99-era spiral_cell_spec (carried forward).

---

*ALICE_LAND_DATA_MASTER Structure Doctrine v1.1 | LOCKED 2026-09-05 | Authority: Joe Smith, Nvirogear LLC | Locked by Mr. Results (Overseer)*
