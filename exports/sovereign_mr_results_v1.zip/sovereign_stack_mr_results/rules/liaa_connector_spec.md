# LIAA Parcel Connector Specification
**Issued by:** Mr. Results (Overseer)
**Date:** 2026-04-26
**Status:** ACTIVE — governs all LIAA access behavior
**County First Target:** Mason County, MI
**Source:** https://maps.liaa.org/masonparcels/

---

## CORE LAW

> This connector is a respectful researcher. Not a scraper.

- We only fetch detail pages for PIDs already found through public search results.
- We never guess, enumerate, or brute-force parcel IDs.
- We stop immediately on any warning signal — no retries without review.
- All records go to staging only. Nothing auto-publishes.

---

## ENDPOINT PATTERN (CONFIRMED — DO NOT EXPAND)

```
Search entry:    GET  /masonparcels/propertysearch.asp
Search POST:     POST /masonparcels/propertysearch.asp?PDBsearch=do
Search results:  GET  /masonparcels/propertysearch.asp?PDBsearch=setdo
Detail page:     GET  /masonparcels/cc/dbviewer/dbvpropSheet.asp?pid={PID}&loc=1&from=main&indexfield=%5Bvalues%5D.parcel_no&caption=Parcel+Number&type=string&cid=5&cc=0
```

Session requires cookie from initial GET before POST will work.

---

## SAFE PID SOURCES (ALLOWED)

1. PIDs returned from LIAA public search result pages
2. PIDs from search results by owner name, address, or partial parcel number
3. PIDs connected to auction-listed parcels
4. PIDs manually selected for validation
5. PIDs from approved public county bulk download/export (if sourced later)

## FORBIDDEN PID SOURCES

- Sequential PID range guessing (`001-001-001-00` → `001-001-002-00` etc.)
- Hidden endpoint probing
- Login or paywall bypass
- CAPTCHA bypass
- Parallel or threaded fetching
- Any PID not sourced from an allowed public path

---

## RATE LIMIT POLICY

| Mode | Max Records | Delay | Cooldown |
|------|-------------|-------|----------|
| validate_sample | 10 | 15–30s randomized | N/A (one-time) |
| anchor_lookup | per PID | 20–30s | 12h between runs |
| pilot_batch | 25 | 20–45s randomized | 12h |
| controlled_batch | 50 | 30–60s randomized | 24h |
| county_daily_max | 100 | — | 24h |
| global_daily_max | 300 | — | 24h |

**No parallel requests. Ever. One request at a time.**

---

## SUPPORTED CONNECTOR MODES

### 1. validate_sample
- Pull ≤10 PIDs from search results across diverse township prefixes
- Fetch detail pages one-by-one with 15–30s delays
- Produce field consistency report
- Do NOT write to ParcelRecord or any canonical entity
- Output: validation report only

### 2. anchor_lookup
- Fetch detail page for a single known PID
- Used for auction-match enrichment or specific parcel lookups
- Write to staging if record passes field check
- Delay: 20–30s after any prior request in same session

### 3. controlled_batch
- Pull from LIAAParcelQueue (status=queued, priority ordered)
- Fetch one at a time with 30–60s delay
- Respect county daily max and global daily max
- Write to ParcelIntakeStaging
- Stop on any stop condition

### 4. county_cycle_probe
- Rotate through multiple counties
- Max 25 records per county per cycle
- Never hit same county twice in a 12h window
- Cycle pattern: County A → B → C → rest

---

## PRE-RUN SAFETY CHECKS (ALL MODES)

Before any request loop:
1. Check robots.txt for `/masonparcels/` — if disallowed: STOP → mark `blocked_by_terms`
2. Scan visible terms/disclaimer on search page
3. Confirm source is public (no login wall) — re-check every run
4. Check paywall signal — if found: mark `paid_reference_only`, do not use as primary
5. Check `connector_status` — if `paused_for_review`: do not run
6. Check `next_allowed_run_at` — if in future: do not run
7. Check county daily max and global daily max

If any check fails → STOP. Log to SourceEvaluationLog.

---

## STOP CONDITIONS (IMMEDIATE — NO RETRY)

Stop immediately and mark `connector_status = paused_for_review` on:
- HTTP 403 Forbidden
- HTTP 429 Too Many Requests
- CAPTCHA detected in response
- Login wall appears
- Paywall appears
- Terms conflict visible
- 5 consecutive failed requests
- Response layout changes unexpectedly (DOM structure shift)
- Response time spike >10x baseline
- Missing parcel_id rate exceeds 20% in a batch
- Source returns private/restricted info (SSN, phone, etc.)

After stop:
- `next_allowed_run_at = now + 24h`
- Create alert for Mr. Results
- Log stopped_reason to ConnectorRunLog

---

## FIELD EXTRACTION (PUBLIC FIELDS ONLY)

### Required (block if missing)
| Field | LIAA Source | Notes |
|-------|-------------|-------|
| parcel_id | URL param `pid` | Always present |
| county | Known from connector context | Mason |
| state | Known from connector context | MI |
| source_url | Constructed from pid | Always present |

### High-value (extract if present)
| Field | LIAA Label | Confidence Signal |
|-------|------------|-------------------|
| owner_name | "Owner Name" row | Present on all confirmed records |
| property_address | "Property Address" div | Present on all confirmed records |
| mailing_address | "Mailing Address" div | Often same as property |
| assessed_value | "Current Assessment" | Dollar figure |
| taxable_value | "Current Taxable Value" | Dollar figure |
| property_class | "Current Property Class" | 4-digit MI class code |
| pre_percentage | "Current P.R.E." | Homestead exemption % |
| jurisdiction | First text td | Township name |
| legal_description | "Tax Description" div | Long text — truncate to 500 chars |
| sale_date | Sale info section | If visible |
| sale_price | Sale info section | If visible |
| acreage | Legal description parse | Approximate — flag as unverified |

### DO NOT COLLECT
- Phone numbers
- Email addresses
- Personal private notes
- Login-only fields
- Paid BS&A tax histories (never access BS&A for LIAA enrichment)
- Social security numbers
- Any field labeled "restricted" or behind a secondary auth

---

## GEOMETRY RULES

LIAA detail pages do NOT provide polygon geometry.

| Signal | Action |
|--------|--------|
| Polygon/MultiPolygon in response | Accept, validate GeoJSON, compute centroid, set `geometry_status=polygon_verified` |
| Point or centroid only | Label `geometry_status=parcel_reference_only` — do not treat as boundary |
| No geometry | Label `geometry_status=missing` — queue `geometry_enrichment` task |

**No inferred boundaries. No fake polygons. No centroid-as-polygon tricks.**

---

## NORMALIZATION OUTPUT SCHEMA

```json
{
  "parcel_id": "",
  "county": "Mason",
  "state": "MI",
  "owner_name": "",
  "property_address": "",
  "mailing_address": "",
  "acreage": null,
  "assessed_value": null,
  "taxable_value": null,
  "property_class": "",
  "pre_percentage": null,
  "jurisdiction": "",
  "legal_description": "",
  "sale_date": null,
  "sale_price": null,
  "geometry": null,
  "geometry_status": "missing | polygon_verified | parcel_reference_only | unknown",
  "source": "LIAA",
  "source_url": "",
  "confidence": "high | medium | low",
  "connector_batch": "liaa_mason_YYYY_MM_DD",
  "intake_status": "validation | staging | rejected",
  "public_export_allowed": false
}
```

### Confidence Rules
- `high`: parcel_id + owner_name + property_address all present
- `medium`: parcel_id + one of (owner_name OR property_address)
- `low`: parcel_id only

Records with `low` confidence go to manual review, not staging.

---

## DEDUP LOGIC (BEFORE ANY WRITE)

Check in order:
1. county + state + parcel_id (exact match → skip, update freshness only)
2. Normalized parcel_id (strip dashes, leading zeros → check)
3. source_url exact match
4. owner_name + property_address → manual review only, never auto-dedup

On duplicate → log `duplicate_skip` to ConnectorRunLog, do not create new record.

---

## STAGING GATE (BEFORE WRITING TO STAGING)

Record must pass ALL:
- [ ] parcel_id present
- [ ] owner_name present
- [ ] property_address present
- [ ] source_url present
- [ ] confidence >= `medium`
- [ ] duplicate check passed
- [ ] intake_status = `staging` (not `validation`)

`public_export_allowed` remains `false` until Overseer gate review.

---

## COUNTY CYCLING STRATEGY

Day pattern (after initial Mason validation):
```
Day 1: Mason → 25 records
Day 2: Next county → 25 records
Day 3: Mason → +25 records
Day 4: Next county
```

Rules:
- Never hit same county twice within 12 hours
- Increase volume only after 3 clean runs with zero warnings
- Prefer fresh validation samples over bulk volume
- Keep source reputation clean

Volume escalation ladder:
1. 10-record validation ← we are here
2. 25-record pilot (after validation passes)
3. 50-record batch (after 2 clean pilots)
4. 100-record daily max (after approval)
5. 250-record daily max (explicit operator approval only)

---

## LOGGING REQUIREMENTS

### ConnectorRunLog (every run)
```json
{
  "connector_name": "LIAAParcelConnector",
  "county": "Mason",
  "state": "MI",
  "mode": "validate_sample | pilot_batch | controlled_batch",
  "records_requested": 0,
  "records_received": 0,
  "records_accepted": 0,
  "records_rejected": 0,
  "duplicates_skipped": 0,
  "start_time": "",
  "end_time": "",
  "average_delay_seconds": 0,
  "warnings": [],
  "stopped_reason": "",
  "next_allowed_run_at": ""
}
```

### SourceEvaluationLog (per source decision)
Update with access status, robots check result, paywall status, and connector health.

---

## VALIDATION REPORT TEMPLATE

After validate_sample mode completes, output:

```
LIAA MASON COUNTY — VALIDATE_SAMPLE REPORT
==========================================
Records pulled:         10
Records with parcel_id: X/10
Records with owner:     X/10
Records with address:   X/10
Records with assessed:  X/10
Records with taxable:   X/10
Records with class:     X/10
Records with legal:     X/10
Records with geometry:  X/10

Geometry source:        NONE CONFIRMED
Pagination method:      search_result → detail_page (session cookie required)
Connector complexity:   MEDIUM (session management + field parsing)
Stop signals seen:      NONE / [describe]

Safe batch rec:         25 records, 30s delay, 12h cooldown
Primary source status:  primary_plus_geometry_enrichment_required
BS&A status:            paid_reference_only — do not access
tax-sale.info status:   secondary_auction_signal_only
```

---

Generated by Mr. Results (Overseer) — Powered by Nvirogear LLC
N-ViroGear Land Intelligence System
