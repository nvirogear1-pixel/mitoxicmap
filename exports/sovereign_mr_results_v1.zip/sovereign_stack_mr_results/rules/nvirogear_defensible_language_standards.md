# Nvirogear Defensible Language Standards — v1.0
# Authority: Mr. Results (Overseer) — Nvirogear LLC
# Locked: May 24, 2026
# Status: MANDATORY — Every claim in every report must pass this filter

---

## PURPOSE

This document codifies the exact wording standards required for Nvirogear to function
as a commercial-grade intelligence product. The goal is enterprise defensibility:
language that is useful, honest, and legally appropriate — without being so hedged
that it loses operational value.

The trigger for this standard: May 2026 product review identified that several
claim types sounded stronger than the underlying source confidence justified.
Specific examples addressed below.

---

## THE CORE PRINCIPLE

**Describe what the evidence shows. Not what the facts are.**

You are an intelligence aggregator. You are not:
- A licensed inspector
- A certified environmental consultant
- An appraiser
- A surveyor
- A title attorney

You CAN say what public records, GIS data, and official portals show.
You CANNOT certify conditions that require on-site or certified professional confirmation.

---

## SECTION 1 — UTILITIES & INFRASTRUCTURE

### Public Sewer

❌ WRONG: "No public sewer available."
✅ CORRECT: "No public sanitary sewer identified in reviewed zoning references."
✅ ALSO OK: "Public sewer not listed in Spring Lake Township RR district per §406 (2022 update). Confirm current availability with township prior to development."

**Why:** Zoning ordinances can be updated. Sewer extensions can be approved. You pulled
a 2022 document. You cannot certify current field conditions.

### Public Water

❌ WRONG: "No public water — private well required."
✅ CORRECT: "No public water service identified in reviewed RR zoning references. Private well appears to be the primary water supply based on MLS listing data and zoning classification."

### Road Surface

❌ WRONG: "Unimproved road."
✅ CORRECT: "Road surface listed as 'unimproved' per MLS record (#25042666). Physical condition not verified. Verify driveway accessibility prior to purchase."

---

## SECTION 2 — FLOOD & FEMA

### Flood Zone

❌ WRONG: "Flood verified — minimal risk."
❌ WRONG: "No flood risk."
✅ CORRECT: "No FEMA Special Flood Hazard Area (SFHA) identified in reviewed datasets. First Street Research Flood Factor: 1/10 (Minimal). [PUBLIC REFERENCE — First Street Research]"
✅ CORRECT (with FEMA NFHL pull): "Zone X (Area of Minimal Flood Hazard) confirmed — FEMA NFHL Panel [XXXXX], effective [DATE]. [VERIFIED — FEMA NFHL Live API]"

**Why:** "Flood verified" sounds like a professional flood determination. It is not.
Only a licensed surveyor or flood determination company can certify flood zone status
for mortgage/insurance purposes.

---

## SECTION 3 — ENVIRONMENTAL

### Contamination (general)

❌ WRONG: "Environmentally clean."
❌ WRONG: "No contamination found."
❌ WRONG: "Site is clean."
✅ CORRECT: "No Part 201 or NPL contamination sites identified within 1-mile radius in reviewed EGLE and EPA databases. This does not constitute an environmental site assessment."
✅ CORRECT: "No known direct contamination record found in reviewed public databases as of [date]."

**Rule from master directive:** Historian Bot — NEVER say "clean" without EGLE certified confirmation.

### PFAS

❌ WRONG: "PFAS present nearby."
❌ WRONG: "Groundwater plume unlikely to reach parcel."
✅ CORRECT: "PFAS Area of Interest identified at [distance] [direction] per MPART public records. No documented pathway to subject parcel identified in reviewed public records. Parcel-level exposure pathway not established."
✅ CORRECT: "No known documented pathway identified in reviewed public records. Well water independent testing recommended given proximity to PFAS AOI."

**Why:** "Unlikely" implies a probability assessment that requires hydrogeological modeling.
You don't have that. "No documented pathway identified" is factually accurate and operationally equivalent.

### Phase I Triggering Language

Use when any environmental flag is present:
> "Confirmed [source type] within screening radius. Parcel-level exposure pathway not established in reviewed public records. Phase I Environmental Site Assessment recommended prior to acquisition or construction."

---

## SECTION 4 — PROPERTY CONDITION

### Structural / Physical

❌ WRONG: "Property needs minor work."
❌ WRONG: "Metal roof is in good condition."
✅ CORRECT: "MLS listing describes property as requiring 'a little elbow grease.' Physical condition not independently verified. Licensed property inspection required."
✅ CORRECT: "MLS listing notes newer metal roof. Roof condition not independently verified. Include in licensed property inspection scope."

### Age-Related Risks (Pre-1978)

❌ WRONG: "May have lead paint."
✅ CORRECT: "Structure built 1930 — pre-dates 1978 federal lead paint disclosure requirement. Seller disclosure form required in Michigan real estate transactions. Licensed inspector should include lead paint screening in inspection scope."

### Asbestos

❌ WRONG: "May contain asbestos."
✅ CORRECT: "Structure built 1930. Properties of this age may contain asbestos in insulation, floor tile, or pipe wrap. Inspection scope should include asbestos screening by a licensed inspector."

---

## SECTION 5 — TITLE & OWNERSHIP

### Clear Title

❌ WRONG: "Title appears clear."
❌ WRONG: "No liens found."
✅ CORRECT: "No liens or encumbrances identified in reviewed public records as of [date]. Title search required for confirmation. Register of Deeds search recommended prior to purchase."

### Trust Ownership

❌ WRONG: "Owner is Gerald Wirt."
✅ CORRECT: "Owner of record: WIRT GERALD C REVOCABLE LVG TST [VERIFIED — Ottawa County GIS]. Trust ownership — confirm current trustee and successor trustee status with title company at closing."

---

## SECTION 6 — VALUATION & MARKET

### AVM References

❌ WRONG: "Property is worth $211,000."
❌ WRONG: "Market value confirmed at $211,247."
✅ CORRECT: "Redfin Estimate: $211,247. Range: $201,000–$243,000. [PUBLIC REFERENCE — Redfin AVM. Not relied upon as final valuation. AVM accuracy varies materially by property type and data freshness.]"

### Comparable Sales

❌ WRONG: "Comparable sales confirm $212,000 value."
✅ CORRECT: "Comparable sales reviewed: [address, price, date] — average $212,333 for 2BR/1BA Spring Lake area. [PUBLIC REFERENCE — Redfin comparable data.] Confirms general market range. Licensed appraisal required for financing and final valuation."

### Spread / Profit Estimates

❌ WRONG: "This deal has $80,000 in profit."
✅ CORRECT: "Gross spread estimate: $63,000–$83,000 based on acquisition price, modeled renovation cost, and comparable sales average. [MODELED — SCENARIO ESTIMATE ONLY. Not a guarantee of market outcomes. Actual results depend on inspection findings, renovation costs, market conditions, and carrying time.]"

---

## SECTION 7 — TAX & ASSESSMENT

### Post-Uncap Tax Estimates

❌ WRONG: "Taxes will increase to $3,500/yr."
✅ CORRECT: "Under Michigan Proposal A, Taxable Value uncaps to State Equalized Value upon ownership transfer. Modeled estimate: $3,300–$3,500/yr based on current SEV and Ottawa County millage rates. [MODELED — verify with Spring Lake Township Assessor prior to purchase.]"

### Assessment Accuracy

❌ WRONG: "Property is assessed at $91,600."
✅ CORRECT: "State Equalized Value (SEV): $91,600 per Ottawa County GIS as of last assessment cycle. [VERIFIED — Ottawa County GIS FeatureServer, pulled May 24, 2026.] SEV represents assessor's estimate of 50% of market value. Does not constitute a licensed appraisal."

---

## SECTION 8 — ZONING

### Permitted Uses

❌ WRONG: "You can build an ADU here."
❌ WRONG: "Property is zoned residential — single family allowed."
✅ CORRECT: "Zoning: RR — Rural Residential District per Spring Lake Township Zoning Ordinance §406 (updated 2022). Intended for low-density single-family residential uses. Public sanitary sewer identified as generally unavailable in this district per reviewed ordinance. Verify current permitted uses and setback requirements with Spring Lake Township Building & Planning Department prior to any construction or subdivision."

---

## SECTION 9 — THE THREE FORBIDDEN CERTIFICATION PHRASES

These three phrases are permanently banned from all Nvirogear reports:

1. **"The property is clean."** → Replace with: "No known [contamination/lien/issue] identified in reviewed public records as of [date]."

2. **"This is a good deal."** → Replace with: "Score: [X]/100. Spread potential: [modeled range]. Recommend professional verification before commitment."

3. **"You should buy this."** → Replace with: "High-Upside Candidate — Conditional Review Required. Not cleared for acquisition action until [items] are verified."

---

## SECTION 10 — THE CORRECT WORDING FOR STANDARD ADVISORY FLAGS

These exact phrasings should be used consistently across all reports:

| Situation | Required Language |
|---|---|
| Environmental site nearby | "Confirmed [site type] within screening radius. Parcel-level exposure pathway not established in reviewed public records." |
| PFAS proximity | "PFAS Area of Interest proximity advisory only. No documented pathway identified in reviewed public records. Well water testing recommended." |
| Flood zone | "No FEMA SFHA identified in reviewed datasets." or "Zone [X] confirmed — FEMA NFHL Panel [ID]." |
| No public sewer | "No public sanitary sewer identified in reviewed RR zoning references." |
| No public water | "Public water service not identified in reviewed references. Private well appears to be primary supply per MLS and zoning classification." |
| Trust ownership | "Trust ownership confirmed — verify current trustee and successor trustee at closing." |
| Lead paint (pre-1978) | "Pre-1978 structure — federal lead paint disclosure required. Include in licensed inspection scope." |
| Tax estimate | "Modeled estimate — verify with [County/Township] Assessor prior to purchase." |
| Structural condition | "Physical condition not independently verified. Licensed property inspection required." |
| Population/community health | "Population-level community context included for resident safeguard planning. Not a property-level health assessment." |
| Ordinance restriction | "Ordinance or land-use layer indicates possible restriction. Legal interpretation required." |

---

## SECTION 11 — SOURCE CITATION STANDARDS

Every cited source must include:
- Source name
- Source type (Government / MLS / AVM / Modeled / News)
- Confidence badge (VERIFIED / PUBLIC REFERENCE / ADVISORY / MODELED)
- Date accessed or data year
- Source Ledger ID (SL-XXX format)

Format for inline citations:
`[SOURCE NAME — CONFIDENCE BADGE — DATE]`

Example:
`[Ottawa County GIS FeatureServer — VERIFIED — May 24, 2026]`
`[Redfin AVM — PUBLIC REFERENCE — May 2026]`
`[EGLE MPART — PUBLIC REFERENCE — 2025]`
`[Spring Lake Twp ZO §406 — VERIFIED — 2022 update]`

---

## REVISION HISTORY

| Version | Date | Change |
|---|---|---|
| v1.0 | May 24, 2026 | Initial creation — triggered by 749 Wilson Rd product review |

---

*Nvirogear LLC | Mr. Results (Overseer) | Locked May 24, 2026*
*These standards apply to all report types defined in nvirogear_report_type_taxonomy.md*
