# HISTORIAN BOT — MR. RESULTS CONNECTION SPEC
# Version: 1.0 | Date: 2026-05-18
# Status: LIVE — Endpoint verified, deployed

---

## ENDPOINT

```
POST https://super-history-bot-2d658b84.base44.app/functions/receiveTask
```

---

## MINIMUM PAYLOAD

```json
{
  "task_id": "MR-UNIQUE-ID-001",
  "task_type": "phase1.5_appraisal",
  "county": "Mason",
  "state_code": "MI",
  "parcel_id": "APN-as-found",
  "parameters": {
    "centroid_lat": 43.96,
    "centroid_lng": -86.45,
    "acreage": 40.0,
    "address": "612 N James St, Ludington MI 49431",
    "source_name": "LIAA",
    "source_url": "https://..."
  }
}
```

---

## HOW IT WORKS

1. Task lands in Historian's `TaskInbox` → status: `pending`
2. Historian polling automation fires every 5 minutes, picks it up
3. Historian runs full query stack: EGLE, FEMA, NWI, OGMD, USDA soil
4. Results push directly to `mr-results pipelineIngest` with original `parcel_id`
5. `TaskInbox` updates to `completed` with result summary

---

## DEDUP

Same `task_id` sent twice → returns existing record, no double processing.

---

## TASK TYPES (supported by Historian Bot)

| task_type | What It Runs |
|---|---|
| `phase1.5_appraisal` | Full EGLE + FEMA + NWI + OGMD + USDA soil stack |
| `environmental_and_mineral_scan` | EGLE Part 201/213, PFAS AOI, mineral rights, deed review flag |
| `egle_only` | Part 201 / Part 213 / LUST records only |
| `flood_and_wetlands` | FEMA SFHA + NWI wetlands layer |
| `mineral_rights` | Township mineral separation, deed review required flag |
| `township_ordinance` | Local township zoning/ordinance flags |

---

## RETURN PAYLOAD (to pipelineIngest)

Historian sends back to Mr. Results with:
- `parcel_id` (original, unchanged)
- `county`, `state_code`
- `env_flags[]` — list of EGLE/EPA/PFAS flags found
- `env_contamination` — boolean
- `env_flood` — boolean + zone
- `env_notes` — narrative summary
- `hist_phase1` — Phase 1 ESA recommended? true/false + reason
- `hist_phase2` — Phase 2 required? true/false + reason
- `mineral_rights_status` — severed / intact / unknown
- `deed_review_required` — boolean
- `source_urls[]` — all public sources consulted
- `confidence` — HIGH / MEDIUM / LOW
- `task_id` — original task_id echoed back
- `completed_at` — ISO timestamp

---

## MR. RESULTS DISPATCH FUNCTION

Use `dispatchHistorianTask` function (already deployed):

```
POST https://mr-results-8ae25c59.base44.app/functions/dispatchHistorianTask
```

Payload follows the minimum payload schema above.

---

## RULES

- NEVER hard-code the Historian URL — resolve from `getBotRegistry` first
- ALWAYS pass `task_id` as `"MR-" + parcel_id + "-" + timestamp`
- ALWAYS wait for `completed` status before merging env data into ParcelRecord
- If Historian returns `env_contamination: true` → escalate to HIGH risk immediately
- If Historian returns `hist_phase1: true` → Phase I ESA goes MANDATORY in Pre-Bid Gate
- If Historian returns no hits → label as "No known direct record found in reviewed sources" — NEVER "clean"

---

## REGISTRY KEY

`historian` — resolve via getBotRegistry before every dispatch

---

*Filed under: .agents/rules/historian_bot_connection.md*
*Mr. Results (Overseer) — Nvirogear LLC — 2026-05-18*
