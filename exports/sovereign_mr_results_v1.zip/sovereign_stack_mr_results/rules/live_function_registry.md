# LIVE FUNCTION REGISTRY
# Authority: Mr. Results (Overseer) | Last verified: 2026-05-19 | Status: LOCKED

## WORKING PATTERN (mandatory for ALL functions)
```
import { createClientFromRequest } from "npm:@base44/sdk";
Deno.serve(async (req) => { ... });
```
Never use: `export default async function handler`, `import base44 from "base44-sdk"`,
`import { base44 } from "@base44/sdk"`, or any CDN SDK URL. Those all 404.

## SUPABASE URL RULE (critical)
The `SUPABASE_URL` env var injected by the platform includes `/rest/v1` suffix.
**NEVER use `Deno.env.get("SUPABASE_URL")` as a base URL for Supabase REST calls.**
Always hardcode the base: `const SUPABASE_BASE = "https://fqldwabxtqkhszauujhg.supabase.co";`
Then build paths as: `${SUPABASE_BASE}/rest/v1/<table>`

---

## CONFIRMED LIVE FUNCTIONS — 17 total (verified 2026-05-19)

| Function               | Status         | Purpose                                           | Key Inputs                                        |
|------------------------|----------------|---------------------------------------------------|---------------------------------------------------|
| pipelineIngest         | ✅ LIVE        | Parcel intake + ACK mode + fleet dispatch         | parcels[] OR mode:"ack"/"fleet_dispatch"          |
| getBotRegistry         | ✅ LIVE        | Fleet registry + endpoint map                     | ping:true / bot:"jet"                             |
| dispatchHistorianTask  | ✅ LIVE        | Send task to Historian Bot                        | task_type, parcel_id, county                      |
| dispatchToOutreachBot  | ✅ LIVE        | Route to Outreach Bot                             | contact_id, parcel_id                             |
| gmailWebhookHandler    | ✅ LIVE v2.0   | Gmail reply pipeline (historyId fixed)            | message.data (pub/sub base64)                     |
| handleReplyIntent      | ✅ LIVE        | Classify reply + route deal stage                 | outreach_log_id, classification                   |
| pushToSupabase         | ✅ LIVE        | Push records to Supabase public_projection        | records[]                                         |
| receiveParcelBatch     | ✅ LIVE        | Batch parcel ingest from Grabber                  | county, parcels[]                                 |
| routeDealToBuyers      | ✅ LIVE        | Route deal to matched buyer contacts              | parcel_id                                         |
| sendIntroEmail         | ✅ LIVE        | Send outreach intro email                         | contact_id, parcel_id                             |
| classifyReply          | ✅ LIVE        | Classify a raw reply body                         | outreach_log_id, reply_body                       |
| reportCompiler         | ✅ LIVE v1.0   | Compile full enterprise report object             | parcel_id (+ optional bot outputs)                |
| generateReportV2       | ✅ LIVE v2.0   | Fleet dispatch report generator (fresh name)      | address OR parcel_id, county, state               |
| overseerValidateV2     | ✅ LIVE v2.0   | Mr. Results gate validator + promotion            | job_id, decision, overseer_notes?, promote_to_public? |
| triggerInvestorBriefV2 | ✅ LIVE v2.0   | Investor brief gate (trust≥60 + geometry)         | parcel_id, county, state, trust_score, gis_lat/lng |
| generateDraftReplyV2   | ✅ LIVE v2.0   | Gmail draft reply builder (NEVER auto-sends)      | outreach_log_id, reply_classification             |
| honeypotAlertCheck     | ✅ LIVE v1.0   | VaultSmith honeypot monitor (silent if clean)     | {} (no body needed)                               |

---

## FUNCTION BEHAVIOR NOTES

### generateReportV2
- Dispatches Jet + Historian + SiteTracker in parallel via Promise.allSettled
- Returns `geometry_confidence: "high"` when Supabase hit found, "limited" otherwise
- jet_registry_miss = Jet is live but getBotRegistry returned null (normal when Supabase empty)
- historian_unavailable = Historian bot 500/timeout (check fleet health)

### overseerValidateV2
- INSERT-then-PATCH architecture — never deletes from public_projection
- Returns gate_issues[] as advisory only (non-blocking) unless decision="approved" + no notes
- Promotion only runs when `promote_to_public: true` is explicitly passed

### triggerInvestorBriefV2
- Hard gate: trust_score < 60 → 422 gate_blocked (correct behavior)
- Hard gate: no gis_lat/gis_lng → 422 gate_blocked (correct behavior)
- Writes to InvestorReadyDeal + AgentLog on pass

### generateDraftReplyV2
- 404 when outreach_log_id not found = CORRECT — expected behavior
- Never auto-sends — returns draft_subject + draft_body for human review
- Stamps OutreachLog with draft_created: true + status: "draft_ready"
- Supports reply_classification: warm | interested | question | not_interested | (default)

### honeypotAlertCheck
- Returns `status: "table_not_deployed"` when vs11_suspect_accounts not in Supabase = CORRECT
- Deploy `vaultsmith_honeypot.sql` to Supabase to activate live monitoring
- Marks records as notified_overseer: true after alerting to prevent duplicate alerts

---

## RETIRED / 404 FUNCTIONS (wrong pattern — do not redeploy under old names)

| Function                  | Replaced By            | Root Cause                                        |
|---------------------------|------------------------|---------------------------------------------------|
| generateReport            | generateReportV2       | export default handler pattern                    |
| generateDraftReply        | generateDraftReplyV2   | CDN SDK URL import                                |
| triggerInvestorBrief      | triggerInvestorBriefV2 | `import { base44 } from "@base44/sdk"`            |
| overseerValidate          | overseerValidateV2     | supabase-js import only                           |
| enterpriseReportCompiler  | reportCompiler         | `import base44 from "base44-sdk"`                 |
| jetResyncBridge           | —                      | relative file import                              |
| dispatchJob               | —                      | supabase-js import only                           |
| runLandScraper            | —                      | `import base44 from '../.base44/sdk.ts'`          |

---

## GMAIL WEBHOOK — ROOT CAUSE + FIX (2026-05-18)

**Problem:** Gmail connector pub/sub sends base64-encoded `{emailAddress, historyId}` — NOT message IDs.
**Fix (v2.0):** Handler decodes base64 → extracts historyId → calls Gmail History API →
  `GET /gmail/v1/users/me/history?startHistoryId=N&historyTypes=messageAdded&labelId=INBOX`
  → gets real message IDs → fetches + classifies each message.
**Tested:** historyId 122750 → resolved message 19e3a8c239bf8141 → correctly skipped.

---

## AUTHENTICATION NOTE

The deploy tool sometimes reports "already up to date" for functions with wrong import patterns.
This is a FALSE POSITIVE. The function is NOT deployed.
**Rule:** A function is only confirmed live after `test_backend_function` returns HTTP 200/400/404-with-logic/422.
HTTP 404 with generic {"error":"not found"} = not deployed.
HTTP 404 with specific business logic error = deployed and working correctly.

---

*Generated by Mr. Results (Overseer) — Nvirogear Property Intelligence System — Powered by Nvirogear LLC*
*Last updated: 2026-05-19 01:05 UTC*
