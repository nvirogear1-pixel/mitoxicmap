# Geometry Enforcement Protocol — LOCKED
**Issued by:** Mr. Results (Overseer)
**Date:** 2026-04-26
**Status:** PERMANENT — applies to every parcel, every pipeline run, every Supabase push

---

## CORE RULE

Centroids do NOT define parcel boundaries.
Polygons do.

If you don't have a polygon, you don't have a parcel boundary. Say so honestly.

---

## ACCEPTED GEOMETRY

| Type           | Accepted As      | Notes                                         |
|----------------|-----------------|-----------------------------------------------|
| Polygon        | ✅ Boundary data | Must have ≥4 coordinate pairs, valid lon/lat  |
| MultiPolygon   | ✅ Boundary data | Same rules per ring                           |

## REJECTED AS BOUNDARY DATA

| Type           | Verdict          | What to do instead                            |
|----------------|-----------------|-----------------------------------------------|
| Point          | ❌ REJECTED      | Store as centroid_only, not polygon           |
| MultiPoint     | ❌ REJECTED      | Same                                          |
| LineString     | ❌ REJECTED      | Not a parcel boundary                         |
| Fake polygon   | ❌ BLOCKED       | Any polygon inferred without GIS source       |
| Bounding box   | ❌ BLOCKED       | Not real parcel geometry                      |
| Missing geom   | ⚠️ Allowed      | geometry_status = no_geometry                 |

---

## GEOJSON COORDINATE ORDER

GeoJSON uses [longitude, latitude] — NOT [latitude, longitude].

Michigan bounding box:
- Longitude: -92 to -80
- Latitude: 40 to 50

Any coordinate outside this range on first pass → REJECTED.

---

## geometry_status VALUES

| Value                | Meaning                                              |
|---------------------|------------------------------------------------------|
| polygon_verified     | Real Polygon/MultiPolygon from trusted GIS source    |
| polygon_unverified   | Real polygon, source not in trusted list             |
| centroid_only        | Only lat/lng available — reference marker ONLY       |
| no_geometry          | Nothing — no polygon, no centroid                   |

Trusted sources for polygon_verified:
- county_gis
- verified_gis_source
- arcgis_grabber
- michigan_dtmb
- mil_gateway
- state_gis

---

## CENTROID RULE

Centroid must be COMPUTED FROM the polygon — not stored independently as the primary location.

When a real polygon exists:
→ centroid_lat and centroid_lng are computed from the polygon ring's bounding box midpoint
→ Stored alongside the polygon for reference
→ Emergent uses polygon for rendering, centroid for search/proximity

When no polygon exists:
→ centroid_lat / centroid_lng may be stored as reference only
→ geometry_status = centroid_only
→ Record is NOT a verified parcel boundary
→ Map must NOT render this as a boundary shape

---

## SUPABASE FIELD CONTRACT

Every parcel_records row pushed to Supabase MUST include:

```
parcel_id          — required, non-null
county             — required
state              — required
geometry_geojson   — GeoJSON Polygon/MultiPolygon OR null (never Point)
geometry_status    — polygon_verified | polygon_unverified | centroid_only | no_geometry
geometry_type      — Polygon | MultiPolygon | centroid_reference | null
centroid_lat       — computed from polygon OR reference lat (never primary)
centroid_lng       — computed from polygon OR reference lng (never primary)
source_name        — required
source_url         — required
```

---

## EMERGENT INGESTION RULES

Emergent (Homestead Estates frontend) must:

1. Accept rows IF geometry_geojson is valid Polygon/MultiPolygon
2. Compute centroid internally from polygon — do NOT rely on centroid_lat/lng as source of truth
3. Set geometry_status = polygon_verified when source is trusted GIS
4. Reject Point as polygon data
5. If geometry_status = centroid_only: import as Parcel Reference only — do NOT render as a boundary
6. Map renders polygon boundaries when geometry_geojson exists
7. Dedupe priority:
   a. parcel_id + county (exact match)
   b. geometry overlap/intersection
   c. computed centroid proximity — fallback only

---

## PIPELINE GATE ADDITION

The Pre-Merge Gate now includes geometry classification check:

- polygon_verified parcels → eligible for export
- polygon_unverified parcels → eligible for export with note
- centroid_only parcels → reference layer only, NOT exported as verified boundaries
- no_geometry parcels → blocked from export until GIS Bot resolves

---

## WHAT WE DON'T DO

- We do not fake polygons.
- We do not use centroid boxes as parcel shapes.
- We do not let Emergent show a centroid as a real boundary.
- We do not call a record "geometry_verified" without a real polygon.

---

## WHY THIS EXISTS

Real buyers and investors use the map to understand what they're buying.
A centroid dot in the center of a county is not a parcel boundary.
A bounding box around a ZIP code is not a parcel boundary.
Only the actual GIS polygon from the county assessor or state GIS is a parcel boundary.

Truth > convenience. Always.

---

Generated by Mr. Results (Overseer) — Powered by Nvirogear LLC
N-ViroGear Land Intelligence System
