# Outreach Bot Handshake — LOCKED
**Issued by: Mr. Results (Overseer)**
**Last updated: 2026-05-09**

---

## Endpoint
```
POST https://outreach-bot-1129e0e7.base44.app/functions/receiveDispatch
```

## Security
- `caller_id: "69ca9ac1baa8ecdb8ae25c59"` required on EVERY call
- All other callers blocked

---

## Dispatch Types

| dispatch_type | What it does |
|---|---|
| `auto_dispatch_intro` | Sends intro email |
| `classify_reply` | Classifies a reply from a contact |
| `trigger_report` | Generates Quick Look report + reply draft |
| `get_log_status` | Returns full log trail for a task |

---

## Required Payload Shape (auto_dispatch_intro)

```json
{
  "caller_id": "69ca9ac1baa8ecdb8ae25c59",
  "task_id": "unique-task-id",
  "dispatch_type": "auto_dispatch_intro",
  "parcel_record": {
    "parcel_id": "...",
    "address": "...",
    "county": "...",
    "state": "MI"
  },
  "outreach_contact": {
    "id": "...",
    "full_name": "...",
    "email": "...",
    "company": "..."
  },
  "sender_profile": {
    "name": "Joe Smith",
    "title": "Founder",
    "brand": "Homestead Estates",
    "email": "joe@homesteadestates.com"
  },
  "send_mode": "email_send"
}
```

**Note:** `parcel_record`, `outreach_contact`, and `sender_profile` must be inline in the payload — not just IDs.

---

## Response Shape (always returned)

```json
{
  "task_id": "...",
  "dispatch_type": "auto_dispatch_intro",
  "status": "complete",
  "gate_status": "waiting",
  "completeness_status": "in_progress",
  "next_action": "wait_for_reply",
  "operator_message": "Intro sent to john@email.com. Gmail ID: abc123. Follow-up in 4 days.",
  "linked_ids": {
    "contact_id": "...",
    "property_id": "...",
    "campaign_id": "..."
  }
}
```

---

## Reply Flow
1. Mr. Results selects contact + parcel → dispatchToOutreachBot
2. Outreach Bot sends → returns status + linked_ids
3. watchReplyEvents polls Gmail → classifyReply
4. Classification returned to Mr. Results:
   - HOT → winner-take-all lock
   - WARM → QuickLook snapshot + trigger_report
   - DEAD → archive contact

---

## Important: send_mode
- `email_send` → Gmail live send (requires Gmail OAuth)
- `email_draft` → draft created in Gmail, manual send fallback

Gmail OAuth is NOT yet authorized on Outreach Bot. Until authorized, mode falls back to `prepared_manual` (copy-paste).

---

## Bot Discovery
Outreach Bot can find Mr. Results at:
```
POST https://mr-results-8ae25c59.base44.app/functions/getBotRegistry
Body: { "bot": "mr_results" }
```
