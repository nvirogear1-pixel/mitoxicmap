# MANDATORY ROLL CALL PROTOCOL
# Version: 2.0 | Date: 2026-05-18
# Status: PERMANENT — NON-NEGOTIABLE

## ══════════════════════════════════════════════
## RULE: ROLL CALL IS MANDATORY. NO EXCEPTIONS.
## ══════════════════════════════════════════════

Mr. Results MUST run the fleet roll call in ALL of the following situations:

  1. Start of every new conversation / session
  2. Before starting ANY property report
  3. Before starting ANY project or multi-county run
  4. Before dispatching to 2 or more bots simultaneously
  5. When user says: "roll call", "fleet check", "are we live", "check the fleet", "status"

## HOW TO RUN IT

  run_skill("fleet_roll_call.sh", arguments="[trigger] [context]")

  Triggers: session_start | pre_report | pre_project | pre_dispatch | manual
  Context:  name of report or project being started

  Examples:
    run_skill("fleet_roll_call.sh", arguments="pre_report \"Muskegon Enterprise Report\"")
    run_skill("fleet_roll_call.sh", arguments="session_start \"new session\"")
    run_skill("fleet_roll_call.sh", arguments="pre_dispatch \"3-county batch run\"")

## WHAT TO DISPLAY TO USER

After the skill runs, show the user this exact format — nothing more, nothing less:

  🛰️ FLEET ROLL CALL — [DATE TIME]
  ✅ Jet / GIS Bot        — LIVE ([ms]ms)
  ✅ Historian Bot         — LIVE ([ms]ms)
  ✅ Outreach Bot          — LIVE ([ms]ms)
  🔒 Super Report Bot     — PRIVATE (set app to Public to fix)
  ❌ Site Tracker          — NOT DEPLOYED (deploy receiveTask to fix)
  ❌ Auction Gate Bot      — UNREACHABLE (confirm endpoint)

  🟢 ALL SYSTEMS GO  /  🟡 PARTIAL READINESS  /  🔴 FLEET DEGRADED

  [Only if degraded or partial]: "Cannot proceed with [task] until [bot] is restored."

## GATE RULES — WHAT IS BLOCKED BY WHICH BOT BEING DEAD

  If Jet is ❌         → BLOCK: Any GIS fetch, geometry sync, county run
  If Historian is ❌   → BLOCK: Any environmental check, Phase 1/2/3 sweep, env report section
  If Outreach is ❌    → BLOCK: Any email dispatch, reply classification, deal routing
  If Site Tracker ❌   → WARN only: Note that actionability gate will be manual
  If Super Report ❌   → WARN only: Reports generated manually by Mr. Results
  If Auction Gate ❌   → WARN only: Auction verification done manually

## RESULT LOGGING

Every roll call result is written to the RollCallLog entity automatically by the skill.
Fields: jet/historian/outreach/super_report/site_tracker/auction_gate — status + HTTP code + response_ms
fleet_ready = true only when DEAD count = 0.

## WHY THIS EXISTS

Mr. Results wakes up fresh each session. Memory stores addresses — not live status.
A bot can go down silently between sessions. This catches it in 10 seconds.
Every report that runs without this check is a report that could fail mid-pipeline
with no explanation. That stops now.

## SKIP CONDITIONS — ONLY THESE TWO

  - User explicitly says "skip roll call" (their risk, their call)
  - Roll call already ran earlier in this same session and all bots were ✅ LIVE
