# NORMALIZATION GUARD — STATE VOCABULARY ENFORCEMENT
**Issued by:** Mr. Results (Overseer)
**Date:** 2026-04-01
**Status:** PERMANENT — applies to every task, every county, every pipeline run

---

## THE CORE SEPARATION (NEVER VIOLATE)

```
gate_status       = structural pass/fail only
completeness_status = data completeness only
task_queue        = what exact work remains
```

These are THREE SEPARATE LAYERS. A value in one does NOT imply a value in another.

---

## CANONICAL STATE VOCABULARY

### OperationalTask.status
- `open`
- `resolved`
- `blocked`
- `archived`

### OperationalTask.execution_status
- `pending`
- `executing_now`
- `waiting_external_capability`
- `approval_pending`
- `resolved`
- `failed_real`
- `seasonal_hold`

### OperationalTask.resolution_type
- `full`      — task is complete, no dependencies remain
- `partial`   — task produced results, but follow-up work remains
- `temporal`  — task resolved for now, must be rechecked at a future date
- `blocked`   — task cannot proceed without external capability
- `none`      — task has not been attempted or produced no output

### PipelineState.gate_status
- `not_run`
- `pending`
- `passed`
- `blocked`

### PipelineState.completeness_status
- `complete`        — gate passed AND all follow-up tasks resolved
- `partial`         — gate passed OR work done, but open dependencies remain
- `structural_only` — gate passed but significant data gaps exist

### PipelineState.current_stage
- `discovered`
- `extracting`
- `raw_exported`
- `prechecking`
- `prechecked`
- `checkpoint_paused`
- `normalized_ready`
- `emergent_ready`
- `imported`
- `blocked`

---

## NORMALIZATION GUARDS (HARD RULES)

### GUARD 1 — Never normalize to full/complete if open follow-ups exist

```
IF any OperationalTask WHERE:
    (parent_task_id = this_task.id AND status = "open")
    OR (county = this_county AND execution_status IN ["pending", "waiting_external_capability"])
THEN:
    resolution_type MUST NOT be "full"
    completeness_status MUST NOT be "complete"
```

### GUARD 2 — gate_status=passed does NOT set completeness_status=complete

```
gate_status = "passed"
→ allowed completeness_status values: "partial" OR "structural_only" OR "complete"
→ completeness_status = "complete" ONLY if ZERO open follow-up tasks exist
```

### GUARD 3 — seasonal_hold tasks do NOT block gate

```
execution_status = "seasonal_hold"
→ does NOT count as an open blocker for gate_status
→ DOES count as an open dependency for completeness_status
```

### GUARD 4 — Never erase a partial by re-running normalization

```
IF resolution_type = "partial" AND open follow-ups exist:
    → do NOT overwrite with "full" or "complete"
    → normalization pass must PRESERVE partial state
```

### GUARD 5 — next_required_action must be computed from live task queue

```
next_required_action is NOT a free-text field
It must reflect the highest-priority open task for that county
It must be recomputed on every PipelineState update
It must NOT be left as stale text from a prior run
```

---

## FORBIDDEN VARIANTS (DO NOT USE)

These are non-canonical and must never appear in any entity:

| Forbidden | Canonical Replacement |
|-----------|----------------------|
| `blocked_requires_browser` | `status=blocked, execution_status=waiting_external_capability` |
| `waiting_browser_capability` | `execution_status=waiting_external_capability` |
| `resolved_temporarily` | `status=resolved, resolution_type=temporal, execution_status=seasonal_hold` |
| `partial_resolved` | `status=resolved, resolution_type=partial` |
| `complete_with_issues` | `status=resolved, resolution_type=partial, completeness_status=partial` |
| `merge_ready` (gate_status) | `gate_status=passed` |
| `merge_ready_with_warnings` | `gate_status=passed, completeness_status=partial` |
| `fully_resolved` | `resolution_type=full, completeness_status=complete` |

---

## STAGEVENTLOG EVENT TYPES (CONSTRAINED)

Only these event type prefixes are allowed in StageEventLog.note:

- `TASK_CREATED`
- `TASK_STARTED`
- `TASK_RESOLVED`
- `TASK_BLOCKED`
- `TASK_FAILED`
- `TASK_RECHECK_SCHEDULED`
- `PIPELINE_UPDATED`
- `DASHBOARD_UPDATED`
- `VERIFICATION_REPAIR`
- `TASK_CHAIN_REPAIRED`
- `GATE_TASK_CORRECTION`
- `NORMALIZATION_PASS`
- `VOCABULARY_LOCKED`

No freeform event type prefixes. No undocumented variants.

---

## DISPATCHER GUARD

The dispatcher automation (runs every 6 hours) must:

1. Skip tasks where `execution_status = "seasonal_hold"` AND `recheck_after > today`
2. Skip tasks where `execution_status = "waiting_external_capability"` AND `required_capability != "mr_results"`
3. Never mark a task `resolved` without real evidence in `result_summary`
4. Never mark a task `resolution_type=full` if `parent_task_id` exists AND the parent has open follow-ups
5. Always log a StageEventLog entry for every state transition

---

## DASHBOARD GUARD

Dashboard labels must be derived from canonical entity fields ONLY:

| Display label | Source field |
|---------------|-------------|
| Gate status | `PipelineState.gate_status` |
| Completeness | `PipelineState.completeness_status` |
| Task resolution | `OperationalTask.resolution_type` |
| Execution state | `OperationalTask.execution_status` |
| Next action | `PipelineState.next_required_action` |

Dashboard must NEVER derive labels from:
- `result_summary` text parsing
- `notes` field string matching
- Stale cached values not refreshed from entity reads

---

Generated by Mr. Results (Overseer) - Powered by Nvirogear LLC
N-ViroGear Land Intelligence System
