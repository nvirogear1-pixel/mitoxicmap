# NVIROGEAR SOURCE AUTHORITY TIERS — PERMANENT DOCTRINE
# Version: 1.0 | Enforced by: Mr. Results (Overseer)
# Established: 2026-05-12
# Trigger: 2691 E 40th St, White Cloud MI — post-report debrief

---

## PURPOSE

Every data claim in a Nvirogear report must be assigned to one of three source authority tiers.
Tier assignment determines the confidence label. No exceptions.

---

## TIER 1 — AUTHORITATIVE BACKBONE SOURCES

These sources form the trusted foundation of every report. Claims sourced here may be labeled **VERIFIED** (if confirmed by 2+ sources) or **PUBLIC RECORD** (single source, official).

| Source | What It Confirms |
|---|---|
| County Treasurer (official portal or direct call) | Tax status, tax liability, delinquency, ownership history |
| County Register of Deeds | Deed history, grantors/grantees, transfer dates, encumbrances |
| Michigan Board of State Canvassers (BSA) | Election-related; NOT real estate — see note below |
| Michigan SEV / BS&A (Equalizer / BS&A Software) | State Equalized Value, assessed value, taxable value, owner name |
| County Equalization / Assessor's Office | Official SEV, parcel class, acreage, improvement value |
| FEMA National Flood Insurance Program (NFIP) | Flood zone designation (SFHA, AE, X, etc.) |
| EGLE (Michigan DEQ) | Environmental site records, Part 201 contamination, remediation status |
| USGS / USDA / National Wetlands Inventory | Wetland designation, hydrologic data, soil classification |
| USFS (U.S. Forest Service) / DNR | Federal land adjacency, national forest boundaries |
| County GIS / ArcGIS parcel portal | APN confirmation, parcel geometry, acreage, legal description |
| Michigan Secretary of State / LARA | Entity ownership, registered agent, corporate status |
| MLS (via licensed realtor) | Active listings, DOM, sold price, list price history |
| Tax sale / auction site (official county or state) | Current cycle availability, minimum bid, terms, buyer premium |

**BSA NOTE:** BS&A Software (not the same as Board of State Canvassers) is the county assessor data platform used by most Michigan counties. "BSA verification" in Nvirogear context means BS&A Software portal data.

---

## TIER 2 — SUPPORTING / CROSS-REFERENCE SOURCES

These sources are useful for triangulation but must NOT be treated as final authority.
Claims from Tier 2 sources are labeled **LIKELY** or **PUBLIC REFERENCE** depending on context.

| Source | Limitation |
|---|---|
| Zillow (Zestimate / listing data) | Algorithm-based, often lagged, not appraisal |
| Redfin (estimate / listing data) | Same as Zillow — reference only |
| Realtor.com (listing data) | Aggregated from MLS; may be stale |
| Homes.com / Trulia | Same category — reference only |
| Google Maps / Satellite imagery | Visual context only; not parcel authority |
| OpenStreetMap / Nominatim | Approximate — not county-confirmed |
| Neighborhoodscout, AreaVibes, Walk Score | Modeled quality metrics — not official |
| Newspaper archives / local news | Historical context only |
| Wikipedia / general reference | Background only |

**REQUIRED LANGUAGE for all Tier 2 AVM claims:**
> "Public market reference only. Not relied upon as final valuation. May be materially inaccurate."

---

## TIER 3 — UNVERIFIED / INFERRED / MODEL-ONLY

These must be labeled **MODELED**, **ADVISORY**, or **NEEDS VERIFICATION**.
Never present these as facts. Never use them to justify a property status upgrade.

| Source | Example Use |
|---|---|
| Mr. Results scoring engine | Opportunity Signal, Actionability Confidence |
| Internal estimates / extrapolations | Price-per-acre modeled range |
| Unverified owner data from aggregators | People-finder tools, Spokeo, etc. |
| Seasonal or historical data applied to present | "Based on prior auction patterns..." |
| Inferred from adjacent parcels | "Likely similar zoning based on neighbors" |
| Unverified environmental flags | Proximity to known sites without direct parcel link |

---

## SOURCE HIERARCHY RULE (CONFLICT RESOLUTION)

When two sources conflict, the higher Tier wins.

1. If Tier 1 conflicts with Tier 2 → use Tier 1, note the discrepancy, label Tier 2 source as PUBLIC REFERENCE
2. If two Tier 1 sources conflict → flag as NEEDS VERIFICATION; do not resolve without additional confirmation
3. If Tier 3 conflicts with any other tier → Tier 3 is always overridden

---

## TAX DROP INVESTIGATION PROTOCOL

The 2691 E 40th St case (Newaygo County, 2025 tax drop of 67.2%) establishes a standing rule:

**Any single-year tax or SEV drop greater than 30% MUST trigger:**
1. Label: **NEEDS VERIFICATION**
2. Mandatory flag in Risk Register (Section 11)
3. Mandatory item in Pre-Bid Gate (Section 16)
4. Mandatory item in "What Must Be Verified Next" (see below)

Possible causes to investigate before treating as real opportunity signal:
- Poverty/Principal Residence Exemption applied
- Capped value reset after transfer
- Assessment correction after appeal
- Uncapping event (sale + reassessment)
- Data entry error in portal
- Partial parcel split or merge

Do NOT treat a large SEV or tax drop as a "deal signal" without confirming the reason with the County Treasurer or BS&A.

---

## "WHAT MUST BE VERIFIED NEXT" — MANDATORY SECTION

Every Nvirogear report must include a prominently formatted, action-ordered list titled:

### ⚠️ WHAT MUST BE VERIFIED BEFORE YOU SPEND MONEY

This section appears in Section 16 (Pre-Bid / Pre-Offer Gate) AND is repeated as a standalone callout box in Section 02 (Executive Decision Summary).

Format:
```
ITEM | WHO TO CALL | WHAT TO ASK | WHY IT MATTERS | STATUS
```

Example:
```
2025 tax drop (67.2%)  |  Newaygo County Treasurer  |  "Was there an exemption, correction, or transfer event that caused this?"  |  Cannot treat as deal signal until explained  |  ⏳ PENDING
```

This section must be populated even if the only items are routine pre-diligence tasks.
An empty "What Must Be Verified" section is NOT acceptable.

---

## INTEGRATION INTO SCORING

The following items, if unresolved, suppress the Actionability Confidence Score:

| Item | Score Cap Effect |
|---|---|
| Tax drop >30% unexplained | Hard cap at 65 |
| AVM sources disagree >20% | Hard cap at 70 |
| Live auction status unconfirmed | Hard cap at 75 |
| Environmental flag unresolved | Hard cap at 65 |
| Title status unclear | Hard cap at 60 |
| Occupancy unknown | Hard cap at 70 |

Multiple unresolved items stack — use the lowest applicable cap.

---

*Established: Post-report debrief on 2691 E 40th St, White Cloud, MI*
*Enforced by: Mr. Results (Overseer) — Nvirogear LLC*
