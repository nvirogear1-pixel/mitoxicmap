# SOURCE REGISTRY DIRECTIVE
**Issued by:** Mr. Results (Overseer)  
**Date:** 2026-03-30  
**Applies to:** Badass Real Estate Grabber, Badass Site Tracker, Super History Bot

---

## What changed

The Michigan Source Registry is now live in the Overseer app (Mr. Results — app ID: `69ca9ac1baa8ecdb8ae25c59`).

Two new tables are active:
- **SourceRegistry** — canonical platform records (16 platforms logged)
- **CountySourceLink** — verified county-to-source pairings (24 links across 13 counties + statewide)

---

## New rules for ALL bots

### BEFORE sweeping any county:
1. READ `CountySourceLink` in Overseer app for that county
2. Use the verified `source_url` — do NOT invent URLs
3. Check `active_now` field — if false, that source is seasonal/off
4. Check `seasonality` — plan accordingly

### NEVER:
- Log source discoveries as freeform notes only
- Treat "auction source" as a single field
- Write to another bot's tables without Overseer approval

### ALWAYS:
- Route new source discoveries to Overseer → SourceRegistry
- Check statewide sources (FGU, State Land Bank, DNR) as fallbacks

---

## Active-now sources (as of 2026-03-30)
| County | Source | Type |
|--------|--------|------|
| Wayne | Wayne County Treasurer | tax_foreclosure |
| Wayne | Detroit Land Bank Authority | land_bank |
| Washtenaw | Auction.com | mortgage_foreclosure |
| Kalamazoo | Auction.com | mortgage_foreclosure |
| Saginaw | Saginaw County Land Bank | land_bank |
| Genesee | Genesee County Land Bank | land_bank |
| Ingham | Ingham County Land Bank | land_bank |
| statewide | Michigan Treasury FGU | treasury |
| statewide | Michigan State Land Bank | land_bank |

## Seasonal/off-season sources
Oakland, Macomb (Zeus), Kent, Ottawa, Bay, Muskegon (tax-sale), Calhoun, Kalamazoo (tax-sale), Michigan DNR

---

## Bot-specific notes

### Badass Real Estate Grabber
- Next county: **Kent**
- Primary source: tax-sale.info (CountySourceLink confirmed)
- Do NOT sweep Oakland or Macomb until their seasonal windows open

### Badass Site Tracker
- Muskegon is in **review** status — 5 Tier 2 links awaiting geocode, 10 review queue items open
- Do NOT advance Muskegon to export until geocode pass completes
- Use FGU as fallback for any county with no direct land bank

### Super History Bot
- Muskegon historian stage: **COMPLETE** — do NOT re-run
- 54 records processed, 3-tier address match applied
- Next historian county: **Kent**
