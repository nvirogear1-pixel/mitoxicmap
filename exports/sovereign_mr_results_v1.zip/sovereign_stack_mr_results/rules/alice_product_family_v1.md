# ALICE Report Product Family — Governing Architecture v1.0
**Status:** GOVERNING — locked September 11, 2026
**Authority:** Joe Smith, Nvirogear LLC · Locked by: Mr. Results (Overseer)
**Supersedes:** none (first product-family lock)
**Companion:** nvirogear_intelligence_architecture_v1.md (MPIO), vaultsmith_unified_pipeline_standard.md (hash chain), nvirogear_report_type_taxonomy.md

---

## THE ONE ENGINE LAW (GOVERNING)

Alice gathers and reasons over the evidence ONCE — parcel, environmental, well, zoning,
contamination, tax-sale, history, flood, wetlands, ownership.

Every paid product is a PRESENTATION of that same frozen evidence package.
No product ever triggers a second research pass. Derivative outputs may not add claims
that are not in the frozen package.

**Chain of generation (LOCKED):**

```
Alice evidence package (frozen, hash-chained)
        → report templates (tiered)
        → interactive story report
        → audio / deliberation podcast
        → storefront delivery
```

## FREEZE RULE (GOVERNING)

The evidence package is FROZEN before any derivative product is generated.
- Freeze = claims locked, evidence labels attached, sources cited, VaultSmith hash chained to ledger.
- The podcast / audio is generated AFTER the freeze so both voices can only deliberate from the
  same verified evidence package. No voice may introduce new facts.
- If a deliberation exposes a gap, it becomes an ACTION ITEM in the package — never an invented answer.

## PRODUCT FAMILY (TIERED — SAME PARCEL, DEEPER DIVE)

| Tier | Product | What it is |
|------|---------|-----------|
| T1 | Property Snapshot | Low-cost entry: identity, key facts, top flags |
| T2 | Overview / Story Report | The visual map + narrated play-the-story walkthrough for a normal buyer |
| T3 | Investor Due-Diligence Report | Numbers, risks, upside, rehab/dev constraints, resale logic, deal-killer flags |
| T4 | Private Well / Environmental Risk Report | Groundwater, nearby contamination, well records, PFAS/nitrate/lead testing recommendations, source evidence |
| T5 | Land / Homestead Report | Access, buildability, acreage, water, zoning, utilities, hunting/ag potential, neighboring uses, comp land context |
| T6 | Buyer–Advisor Deliberation Podcast | Two purposeful voices deliberating the frozen evidence (audio) |
| T7 | Full Bundle | Interactive report + PDF + podcast + source evidence |

Upgrade path: customer buys T1, upgrades to any deeper tier on the SAME evidence package —
no re-research, marginal cost is generation only.

## T6 DELIBERATION RULES (GOVERNING)

Two roles, both purposeful:
1. **Skeptical Buyer** — asks the questions a good purchaser should ask before committing money.
   Deliberately distrustful of anything that looks cheap.
2. **Alice Advisor** — answers ONLY from the frozen evidence package, with evidence labels,
   and says explicitly when something is unknown.

Deliberation must cover: why the price is what it is · what to ask the seller · what to ask the
realtor · what belongs in the inspection contingency · which records are missing · whether the
price compensates for the risk · each side's final conclusion.

**Unknown → ACTION ITEM. Never hallucinate.** (Bot Output Contract v3 and
Mr. Results Investigation Protocol apply to every voice.)

## MODULE LAW (GOVERNING)

The product family is a REUSABLE ALICE MODULE, not one-off manual reports.
- Input contract: a frozen evidence package JSON (schema: `alice_deliberation_podcast` skill).
- Output contract: tier products generated from templates, never hand-assembled.
- Every generated product carries the package ID + hash so any claim traces to the freeze.

---

## SOVEREIGN SHELL LAW (LOCKED 2026-09-11 — GOVERNING)

The product-family module is a SOVEREIGN SHELL: **zero Base44 dependencies** — no platform
SDK, no entity tools, no connector calls, no network requirements. Pure stdlib code.
JSON in → products out. Runs on a laptop, a CI job, or any host unchanged.

If any host ever needs an adapter, the adapter lives OUTSIDE the module — the module never
changes to fit a host (same law as the ALICE_LAND_DATA_MASTER v1.1 adapters rule).

Reference implementation: `.agents/skills/alice_deliberation_podcast/` — verified executable
2026-09-11 (21-turn deliberation, 8 action items, package sha256 chained into output).

---

*ALICE Report Product Family Architecture v1.0 | LOCKED 2026-09-11 | Authority: Joe Smith, Nvirogear LLC | Locked by Mr. Results (Overseer)*
