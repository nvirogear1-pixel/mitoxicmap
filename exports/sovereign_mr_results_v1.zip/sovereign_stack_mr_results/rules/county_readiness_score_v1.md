# County Readiness Score — v1.0
# Issued: 2026-07-10 | Authority: Mr. Results — Nvirogear LLC
# Status: LOCKED

---

## PURPOSE

Parcel count tells you coverage.
Readiness score tells you whether the data is actually useful.

A county at 90% parcel count but 20% readiness is NOT ready for decision support, reporting, or historical playback.
A county at 60% parcel count but 85% readiness IS usable.

The goal is not to ingest all of Michigan.
The goal is to build the first county-by-county environmental intelligence platform where each county reaches a level that is truly ready for decision support, reporting, and historical playback.

---

## THE 8-DIMENSION READINESS SCORE

Each dimension is scored 0–12.5 points. Max total: 100.

| # | Dimension | What it measures | Max pts |
|---|-----------|-----------------|---------|
| 1 | Parcels Acquired | % of estimated county parcels present | 12.5 |
| 2 | Geometry Verified | % of parcels with confirmed polygon (not centroid/point-only) | 12.5 |
| 3 | Ownership Fields Complete | owner_name + mailing_address present and non-null | 12.5 |
| 4 | Environmental Layers Linked | EGLE Part 201, PFAS AOI, UST, Superfund intersected and flagged | 12.5 |
| 5 | Infrastructure Layers Linked | Flood zone, NWI wetlands, drain tiles, utility confirms present | 12.5 |
| 6 | Historical Timeline Available | Sale history, permit history, deed chain, tax records present | 12.5 |
| 7 | Evidence Chain Complete | SHA-256 hash, source URL, source agency, download date on every record | 12.5 |
| 8 | Ready for AI Analysis / Reports | County has passed Pre-Merge Gate, no open Blockers, export_ready flag set | 12.5 |

---

## READINESS TIER LABELS

| Score | Tier | Label |
|-------|------|-------|
| 0–19 | F | EMPTY / INSUFFICIENT |
| 20–39 | D | ACQUISITION STAGE |
| 40–59 | C | PARTIAL — NOT REPORT READY |
| 60–74 | B | USABLE — LIMITED REPORTS ONLY |
| 75–89 | A | REPORT READY |
| 90–100 | A+ | DECISION SUPPORT READY |

---

## SCORING RULES

- Geometry Verified: centroid-only parcels score 0 on dimension 2 regardless of count
- Environmental Layers: at minimum EGLE Part 201 + PFAS AOI must be intersected to earn any points on dim 4
- Evidence Chain: ANY record missing SHA-256 or source URL caps the county at max 75 total (cannot reach A tier)
- Ready for Reports: requires ALL of the following — no open Blockers, no DEDUP HOLD, gate_status not blocked, at least one parcel with export_ready = true

---

## CURRENT COUNTY SCORES (2026-07-10 Baseline)

| County | Parcels | Geometry | Ownership | Env Layers | Infra | History | Evidence | Reports | TOTAL | TIER |
|--------|---------|----------|-----------|-----------|-------|---------|----------|---------|-------|------|
| Muskegon | 9 | 6 | 6 | 8 | 4 | 4 | 8 | 4 | **49** | C |
| Newaygo | 9 | 5 | 7 | 3 | 2 | 3 | 7 | 2 | **38** | D |
| Lake | 9 | 4 | 6 | 2 | 1 | 2 | 6 | 0 | **30** | D (DEDUP HOLD) |
| Ottawa | 1 | 1 | 1 | 1 | 0 | 0 | 5 | 0 | **9** | F |
| Genesee | 1 | 1 | 1 | 2 | 0 | 0 | 5 | 0 | **10** | F |
| All others | 0–2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | **0–4** | F |

---

## HOW SCORES ADVANCE

### Dimension 1 (Parcels): advances with county GIS acquisition
### Dimension 2 (Geometry): advances when polygon_geojson confirmed per parcel via Jet/GIS Bot
### Dimension 3 (Ownership): advances when county assessor fields mapped and validated
### Dimension 4 (Env Layers): advances when EGLE/PFAS/UST/Superfund intersect run per parcel
### Dimension 5 (Infra Layers): advances when FEMA/NWI/drain/utility confirms run per parcel
### Dimension 6 (History): advances when Historian Bot task completed per parcel batch
### Dimension 7 (Evidence Chain): advances when every record has SHA-256 + source URL locked
### Dimension 8 (Reports): advances only after gate check passes — no open Blockers, no holds

---

## INTEGRATION WITH COUNTY REGISTRY

CountyRegistry entity tracks `coverage_status`. Add `readiness_score` field (integer 0–100) and `readiness_tier` (string A+/A/B/C/D/F) to CountyRegistry schema going forward.

The readiness score replaces "parcel count" as the primary metric in the acquisition coordinator dashboard.

---

## ALICE ENVIRONMENTAL ACTIVITY MONITOR CONNECTION

County Readiness Score feeds directly into the ALICE Environmental Activity Monitor.
A county below Tier B (score < 75) cannot be displayed as "Active Coverage" in the monitor.
Alert triggers are only valid for counties at Tier B or above.
Below Tier B, the monitor shows the county as "Monitoring Pending — Data Acquisition In Progress."

---

*Mr. Results (Overseer) — Nvirogear LLC — County Readiness Score v1.0 — 2026-07-10*
*This framework governs all county acquisition priority decisions going forward.*
