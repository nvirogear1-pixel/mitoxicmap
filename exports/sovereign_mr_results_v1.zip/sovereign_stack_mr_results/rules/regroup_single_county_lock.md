# REGROUP MODE — SINGLE COUNTY CONTROL
**Issued by:** Mr. Results (Overseer)
**Date:** 2026-03-30
**Applies to:** ALL bots

---

## LOCK
You are currently locked to one county only: **Muskegon County, MI**

- Do NOT start any new counties
- Do NOT continue open discovery sweeps in other counties
- Do NOT dump bulk data in chat
- Use strict output control — counts, status, errors, next step only
- Return summary-only responses
- If prior Muskegon results already exist, organize and write them properly — do NOT re-scrape

---

## Execution order

1. **Parcel GIS Bot** — verify Muskegon parcel and geometry coverage
2. **Real Estate Bot** — organize known Muskegon sources and active listing/auction records
3. **Sales Archive Bot** — verify sold/history coverage for Muskegon
4. **Historian Bot** — finalize EGLE/environmental/site-history records for Muskegon
5. **Overseer Bot** — merge, score, summarize, mark county status

---

## Required output from each bot
- County
- Stage
- Records written or verified
- Tables/files updated
- Errors
- Next action

---

## Output control rules
- Chat is NOT storage
- Write data to database or assigned storage only
- Never send record-level data through chat
- Return only: counts, status, errors, next step

---

## Unlock condition
All five stages return clean. Overseer confirms merge complete. Then: visual system map → Supabase.
