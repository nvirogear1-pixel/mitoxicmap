# HISTORIAN RECEIVE & EVALUATE PROTOCOL
**Issued by:** Mr. Results (Overseer)
**Date:** 2026-04-02
**Status:** PERMANENT — applies every time historian returns a phase result

---

## 1. INTAKE VALIDATION (HARD GATE)

Verify the return includes:
- task_id
- worker_name = historian
- app_id
- phase_executed
- target_count
- processed_count
- success_count
- status

For each site:
- timeline_summary
- risk_flags
- historical_use_tags
- confidence_summary
- evidence_sources OR source_urls

If any required field is missing:
→ REJECT RETURN
→ Request re-run with missing fields listed explicitly

---

## 2. NORMALIZATION

Convert each site into this standardized structure before attachment:

```
site_key:             <parcel_id | address | alias>
match_type:           parcel_id | address | proximity | name_match
historical_status:    clean | risk_flag | unknown
top_risk_level:       none | low | moderate | high | critical
risk_flags:           []
historical_use_tags:  []
timeline_summary:     [{period, use, notes}]
confidence:           high | moderate | low
evidence_sources:     []
source_urls:          []
missing_information:  []
blocking_issues:      []
```

---

## 3. MATCH CONFIDENCE RULE

If match_type = proximity OR name_match:
→ max confidence = moderate

If no strong evidence:
→ confidence = low
→ historical_status = unknown

Do NOT silently upgrade confidence. Ever.

---

## 4. DUPLICATE / CLUSTER HANDLING

If multiple records represent same physical site:
→ create cluster_id
→ assign canonical_site
→ merge risk_flags (union)
→ top_risk_level = highest detected across all records

Keating cluster (pre-defined):
```
cluster_id:      keating_cluster_1
canonical_site:  1041 E Keating Ave (American Coil Spring)
aliases:         [1060 E Keating Ave, 1041 E Keating Ave]
```

---

## 5. AMBIGUITY CONTROL

If location is unresolved (e.g., E vs W street mismatch):
→ historical_status = unknown
→ confidence = low
→ blocking_issues += "ambiguous_location"

Do NOT classify as risk or clean until resolved.

610 Western Ave is pre-flagged ambiguous — hold at unknown until GIS resolves.

---

## 6. RISK LEVEL STANDARDIZATION

| Level | Criteria |
|-------|----------|
| critical | Superfund / active landfill hazards / confirmed PFAS plume |
| high | Confirmed industrial contamination (solvents, metals, heavy metals) |
| moderate | Industrial history, limited evidence |
| low | Light commercial / weak signal |
| none | Confirmed clean WITH evidence |
| unknown | Insufficient data |

Expected classifications for Muskegon Phase 1:
- Ott/Story/Cordova (500 Agard Rd) → critical
- Thompson Landfill / Peck St Landfill → critical
- Goetze/Federal Mogul / American Coil Spring → high
- Getty St RENK/PFAS → high–critical (evidence-dependent)
- Morris Ave Mich Con Lakey Foundry → high or unknown
- 610 Western Ave → unknown (held)

---

## 7. ATTACHMENT (NO MERGE)

Attach to ParcelRecord only. Do NOT modify core identity fields.

Fields to attach:
```
env_flags
hist_phase1
historical_status
historical_confidence
top_risk_level
hist_match_type
hist_cluster_id      (if applicable)
hist_task_id
hist_last_updated_at
```

Map to ParcelRecord:
- env_flags → env_flags
- hist_phase1 → hist_phase1
- top_risk_level → top_risk_level
- env_contamination → populate only if contamination confirmed
- env_notes → timeline summary + sources

Do NOT alter: parcel_id, address, acreage, gate_status, pipeline_stage, export_ready

---

## 8. BOTRUNLOG ENTRY

Mr. Results writes on historian's behalf (cross-app write restriction):

```
bot_name:          historian
county:            Muskegon
state:             MI
run_type:          historical_scan_phase1
status:            complete | partial | blocked | failed
records_processed: <target_count>
records_inserted:  0
records_updated:   <count of parcels with attachments applied>
notes:             "Phase 1 only; no ParcelRecord core mutation; attachments applied by Mr. Results"
```

---

## 9. LANE GATE DECISION

Gating the historian LANE (not individual parcels):

| Condition | Decision |
|-----------|----------|
| ≥90% sites have valid structured output | ACCEPT LANE |
| Top 5 risk sites weak or ambiguous | PARTIAL ACCEPT — re-task those sites only |
| Structure inconsistent across return | REJECT LANE — full re-run |

---

## 10. NEXT ACTION AFTER ACCEPT

Dispatch sales_worker on same Muskegon parcel set:
```
task_type:    market_analysis
scope:        same 14 Muskegon review-queue items
objective:    price history, listing/auction events, comps within 0.5–1.0 mile
rules:
  - do not infer prices
  - weak comps must be labeled weak
  - coverage gaps must be explicit
```

NOTE: sales_worker has already returned partial on Muskegon (SW-MUSKEGON-20260402-001).
On historian ACCEPT, cross-reference historian env flags against sales_worker market data.
Do not re-dispatch sales_worker unless new parcel IDs are available to link.

---

## REJECTION CONDITIONS (instant reject if any are present)

- "No issues found" with no sources cited
- Risk claims without evidence URLs
- confidence = high on proximity-only matches
- Missing timeline on known heavy sites (Ott/Story, Thompson, Peck St)
- Keating cluster not consolidated
- Vague language: "seems fine", "looks clean", "probably safe", "no issues"

---

## RISK BADGE MAPPING (UI field)

```
none      → CLEAN
low       → WATCH
moderate  → WATCH
high      → RISK
critical  → CRITICAL
```

---

## RULES (non-negotiable)

- No assumptions
- No silent confidence upgrades
- No merging into ParcelRecord core fields
- All intelligence must remain traceable to sources
- If uncertain → label uncertain, do not infer

---

Generated by Mr. Results (Overseer) - Powered by Nvirogear LLC
N-ViroGear Land Intelligence System
