# ALICE Page 3 — Protection Doctrine
# Locked: 2026-05-25 | Authority: Joe (Nvirogear LLC)

## The Two-Screen Architecture (LOCKED)

**Page 2 = "Choose the ground."** — Selection space. Full map. Nothing else.
**Page 3 = "Inspect the earth."** — Inspection space. 3D block is the hero. Nothing else competes.

## Page 3 Prime Directive

The rotating earth block is the differentiator. Not the map. Maps are everywhere.
"Tap parcel → enter underground inspection mode" is the signature interaction. Protect it.

## What STAYS on Page 3 (canvas area — no exceptions)

- The Three.js rotating 3D earth block
- DEMO / MIXED / TRUTH mode pills (top center)
- Back button + parcel ID + coords (top bar)
- "Drag to rotate / Pinch to zoom" hint (fades out)
- That's it.

## What goes in the BOTTOM SHEET ONLY

- Ground Truth Card (populated on layer tap)
- Parcel intel rows (gate, stage, trust score, env flags, sample area)
- Layer chips (Surface / Topsoil / Sand / Clay / Water / Sewer / Gas / Water Table / Bedrock)
- Confidence badges and source metadata
- Environmental notes
- Miss Dig / 811 safety notice
- Any future reports, charts, or additional data

## What is BANNED from Page 3 canvas area

- Charts
- Report links
- Extra buttons beyond the top bar + mode bar
- Giant menus
- Any overlay that obscures the 3D block
- Sidebars or panels floating over the earth view
- Score tables, comp data, deal math

## The UX Hierarchy (LOCKED)

1. Casual users → see the visual first, sheet stays collapsed
2. Power users → expand sheet for details
3. Operators → inspect layer confidence + source metadata
4. Municipalities → eventually inspect full provenance chain

## Why DEMO / MIXED / TRUTH matters (LOCKED)

These pills visually teach:
- estimated ≠ verified
- modeled ≠ truth
- confidence matters
- the underground changes depending on source quality

This is foundational to Nvirogear's credibility. Never remove these.

## The Emotional Shift (Product North Star)

People must stop thinking: "oh cool map app"
And start thinking: "wait… I can inspect underground reality?"

That shift happens on Page 3. Protect the conditions that create it.

---
*Nvirogear LLC — ALICE Underground Truth System*
