# Report Upgrade Manifest v1.0
## Date: May 19, 2026 | Source: Audit v1.0 + Mr. Results
## Applies to: Housing Report (13520 Apple Dr) + Land Report (70-04-08-100-013)

---

## THREE UPGRADE AXES

### 1. STRONGER — Things that increase defensibility and differentiation
### 2. MORE TRUSTWORTHY — Things that increase institutional confidence
### 3. MORE INFORMATIONAL — Things that answer real buyer/investor questions

---

## HOUSING REPORT UPGRADES

### EXEC TAB — ADD "5 Next Steps" Action Card (STRONGER + MORE INFORMATIONAL)
Card sits at TOP of Executive tab, above scorecards.
Title: "5 Things You Must Do Before Any Offer — Ranked by Cost & Risk"
Format: numbered list, each item has: action / who to call / est. cost / why it matters / risk if skipped

1. Pull Ottawa County deed + trust instrument | Ottawa County ROD: deedsselfservice.miottawa.org | $50–$300 | Confirms trustee identity + signing authority. Without this, any purchase contract could be invalid. | RISK IF SKIPPED: Contract may be unenforceable.
2. Order well test (coliform, nitrates, PFAS) | Ottawa County Health Dept: 616-396-5266 | $150–$400 | Rural Crockery Township, agricultural county, PFAS risk. Lenders require well test. | RISK IF SKIPPED: Unknown contamination, lender rejection.
3. Pump and inspect septic system | Licensed septic contractor + Ottawa County Health | $300–$600 | Drainfield age unknown. Failure = $15K–$30K replacement. Lenders require inspection. | RISK IF SKIPPED: $15K–$30K surprise post-close.
4. Run FEMA flood zone + NWI wetlands | msc.fema.gov (free) + FWS NWI Mapper (free) | Free | 24 acres. Wetlands could eliminate 30–50% of usable land. Flood zone affects insurance + financing. | RISK IF SKIPPED: Unbuildable acreage, financing rejection.
5. Confirm millage rate + tax estimate with Crockery Township Assessor | 616-837-9978 | Free | TV uncapping will add $3,200–$5,800/yr. Must know actual millage before underwriting. | RISK IF SKIPPED: Significant underestimate of carrying cost.

### EXEC TAB — DEEPEN TRUST-001 FLAG (MORE TRUSTWORTHY + STRONGER)
Rename to: TRUST-PROBATE-001
Add language:
- "Ruscett Ronald W-Sylvia P Trust" + Grand Haven apartment mailing = estate/trust administration pattern
- If either grantor (Ronald W. or Sylvia P.) has deceased, the property may be subject to probate proceedings or trust modification
- Trust instrument must be pulled from Ottawa County ROD before any purchase contract
- Add: "This is one of the most common deal-killers in rural Michigan real estate. Do not proceed past letter of intent without verified trustee authority."
- Recommend: Consult Michigan estate/trust attorney before any offer

### INVESTOR TAB — ASSEMBLAGE MATH QUANTIFIED (MORE INFORMATIONAL)
Add column to nearby parcels table: "Est. Acquisition Range"
Add summary math box:

ASSEMBLAGE SCENARIO MATH:
Subject (70-04-08-100-006): SEV $216,600 | Est. acq. $350K–$500K
+ PIN 70-04-08-100-013 (Anglebrandt, 3.22ac): SEV $44,200 | Est. acq. $40K–$80K
+ PIN 70-04-08-100-016 (Burgtorf Trust, 2.0ac): SEV $35,000 | Est. acq. $35K–$65K
= Combined SEV: $295,800 | Combined est. acq.: $425K–$645K | Combined acres: 29.24
Market value if assembled: $450K–$700K est. (MODELED — rural Ottawa County acreage premium)

All figures MODELED. Not an appraisal.

### INVESTOR TAB — ADD COMPARABLE SALES SECTION (MORE INFORMATIONAL + TRUSTWORTHY)
Section title: "Ottawa County Rural Residential Comparable Sales"
Source: Ottawa County GIS Sales Dashboard (gis-ottawacountymi.hub.arcgis.com) + public record
Note: "Comparable sales are provided as PUBLIC REFERENCE for market context only. They are not a formal appraisal. All comps require independent verification."

Comp format: Address | Sale Date | Sale Price | Acres | $/Acre | Class | Distance to Subject | Confidence

Target comps (pull from Ottawa County GIS sales dashboard or public record):
- Rural residential sales in Crockery Township / Spring Lake Township area
- Price range $200K–$500K
- Acreage 5–30 acres
- Sale date 2023–2026
- Label as PUBLIC REFERENCE | Not relied upon as final valuation

If Ottawa County GIS sales not available at build time, show:
"Comparable sales pending Ottawa County GIS sales dashboard query. Pull from: gis-ottawacountymi.hub.arcgis.com/apps/sales-dashboard"
And include 2–3 known reference points labeled ADVISORY:
- Ottawa County avg rural residential $/acre 2025: ~$8,000–$15,000/acre (MODELED)
- Hall parcel at 13225 Apple Dr (0.4mi, 2.38ac, SEV $141,100, PRE 100%) as active-owner comp
- Umlor parcel at 13609 Apple Dr (0.6mi, 6.80ac, SEV $103,200, PRE 100%) as active-owner comp

### ENV CONSULTANT DIRECTORY — EXPAND (MORE INFORMATIONAL)
Add these specific listings:
1. Licensed wetland delineators (Ottawa County / West Michigan) — needs verification listing with EGLE referral
2. PFAS testing labs (agricultural Ottawa County) — Ottawa County Health + Michigan DEQ certified labs
3. FEMA elevation certificate providers — licensed surveyors in Ottawa County
4. Septic designers — Ottawa County Health Dept referral list + licensed designers

### DEV TIMING TAB — CONFIDENCE INTERVAL COLUMN (MORE TRUSTWORTHY)
Add "Confidence Interval" column to all 5-year projection tables:
Each row: Confidence | Best Case | Expected | Worst Case
Hard costs (well, septic) → HIGH confidence | quoted range
Soft costs (permits, surveys) → MEDIUM confidence | estimable range
Market variables (appreciation, rental) → LOW confidence | inherently uncertain

Label cost categories explicitly:
- HARD COST (quotable): well drilling, septic installation, driveway/culvert
- SOFT COST (estimable): permits, surveys, legal, closing costs
- MARKET VARIABLE (uncertain): appreciation rate, rental demand, exit cap rate

---

## LAND REPORT UPGRADES

### EXEC TAB — ADD "5 Next Steps" Action Card (identical structure, land-specific)
1. NWI Wetland Delineation | Licensed wetland delineator / F&V | $500–$2,000 | FIRST STEP. Wetlands could eliminate majority of buildable area on 3.22 acres. | RISK IF SKIPPED: Development plan built on wrong foundation.
2. Perc Test (septic feasibility) | Ottawa County Health Dept: 616-396-5266 | $200–$600 + contractor | MUST PASS before any building permit can be issued. Failure = may be unbuildable. | RISK IF SKIPPED: $40K–$80K land investment with no development path.
3. FEMA flood zone + EPA ECHO scan | msc.fema.gov + echo.epa.gov | Free | 3.22 acres rural Section 8. Natural drainage present. Flood zone affects financing. | RISK IF SKIPPED: Financing issues, uninsurable parcel.
4. Ottawa County deed pull + lien search | Ottawa County ROD: deedsselfservice.miottawa.org | $50–$300 | No lien history confirmed. Easements could restrict access or use. | RISK IF SKIPPED: Encumbrance discovered post-close.
5. Crockery Township zoning confirmation letter | 616-837-9978 | Free–$100 | R-4 assumed. Setbacks, ADU rules, minimum lot coverage — all unconfirmed. | RISK IF SKIPPED: Development plan may violate zoning.

### EXEC TAB — ADD OWNER MOTIVATION SIGNAL BOX (STRONGER)
New card: "Owner Motivation Intelligence"
- Owner: ANGLEBRANDT JOHN
- Mailing: 335 S Broton Rd, Muskegon MI (not local — 40+ mi from parcel)
- PRE: 0% (not using as primary residence, no homestead benefit)
- TV/SEV gap: 17.6% ($7,771 / $44,200) — very long-held position, minimal current tax burden
- No active listing: off-market only
- Signal: Non-local owner, long-held, no PRE, no listing = motivated seller profile. Potential for below-market acquisition.
- Label: ADVISORY — seller motivation is unconfirmed. Treat as intelligence signal, not confirmed intent.
- Recommended action: Public records search for owner contact. Direct mail outreach. Consider skip trace.

### DEVELOPER TAB — ADD ZONING DEEP-DIVE (MORE INFORMATIONAL)
Add Crockery Township R-4 reference section:
- What R-4 typically allows in rural Ottawa County
- Minimum lot size (typically 1–2 acres for residential)
- Setback requirements (typical: 35 ft front, 15 ft side, 40 ft rear in rural R-4)
- ADU rules (verify — Ottawa County has been expanding ADU permissions)
- Agricultural overlay (if applicable — Crockery Township has active ag character)
- Road frontage requirement (typically 100–150 ft for rural residential)
Label all as: ADVISORY — Verify with Crockery Township before purchase.

---

## BOTH REPORTS — UNIVERSAL UPGRADES

### HEADER — ADD REPORT TIER BADGE
Add to status bar: Phase 1 Pre-Diligence Intelligence
This frames the product correctly as Phase 1 (what we deliver) vs. Phase 2 (environmental sampling, title opinion, appraisal — what professionals deliver after).

### EXECUTIVE TAB — ADD PRODUCT TIER EXPLANATION
Small explainer box:
"This is a Phase 1 Pre-Diligence Intelligence Report. It answers: Is this worth pursuing? What do I need to verify before I can act? It does not replace a Phase 2 professional review (title search, environmental sampling, appraisal, legal opinion). Phase 2 is what you do after this report tells you it's worth it."

### SOURCE LEDGER — ADD EPA ECHO / FEMA / NWI AS PENDING ENTRIES WITH LINKS
Even though not yet pulled, add source ledger entries for:
- EPA ECHO radius query: echo.epa.gov/echo/facility_search.html | PENDING
- FEMA FIRM panel: msc.fema.gov | PENDING
- FWS NWI wetlands: fws.gov/program/national-wetlands-inventory/wetlands-mapper | PENDING
- Ottawa County Health Dept well/septic records: 616-396-5266 | PENDING
This shows the user exactly where to go and what's outstanding — turns PENDING into an action item, not a gap.

### FOOTER — ADD PHASE 1 / PHASE 2 DISCLAIMER
"This is a Phase 1 Pre-Diligence Intelligence product. Phase 2 due diligence (title search, environmental sampling, appraisal, engineering review, legal opinion) is required before any acquisition, financing, or development decision. This report helps you decide if Phase 2 is worth the investment."

---

## IDEAS FROM AUDIT WORTH ADDING IMMEDIATELY

### Photo Gap Analysis (Visual History tab)
Add a "Photo Gap Analysis" box:
What's missing and why it matters:
- Aerial / drone: Land mass, drainage patterns, vegetation, wetland indicators — MISSING
- Exterior / structure: Age, condition, siding, roof, foundation — MISSING
- Well head / pump: Visible condition indicator — MISSING
- Septic field markers: Location, age indicators — MISSING
- Driveway / road access: Condition, culvert — MISSING
- Interior: HVAC, plumbing, electrical, basement — MISSING (housing report)
Each item: "Not available — [who to contact / how to get it]"

### Confidence Transparency Box (Executive tab)
Add small box showing:
"How confident are we in this report?"
- Parcel identity: HIGH — verified from 2 official sources
- Owner information: HIGH — verified from official county record
- Assessment history: HIGH — 10 years of official data
- Environmental: LOW — scan pending
- Well/septic: LOW — records not pulled
- Development projections: LOW — algorithmic estimate, contractor quotes needed
- Market value range: MEDIUM — modeled, comparable sales needed

---

*Report Upgrade Manifest v1.0 | May 19, 2026 | Mr. Results — Nvirogear LLC*
