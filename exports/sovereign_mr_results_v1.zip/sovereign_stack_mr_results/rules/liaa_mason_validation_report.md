# LIAA Mason County — Validate_Sample Report
**Run Date:** 2026-04-26
**Mode:** validate_sample
**Issued by:** Mr. Results (Overseer)
**Status:** PARTIAL COMPLETE (1/10 records fully fetched — 9 queued for next run)

---

## RECORDS FETCHED

| # | PID | Status |
|---|-----|--------|
| 1 | 001-001-002-00 | ✅ CONFIRMED |
| 2 | 001-004-009-50 | ⏳ QUEUED |
| 3 | 001-005-016-00 | ⏳ QUEUED |
| 4 | 002-001-001-00 | ⏳ QUEUED |
| 5 | 002-029-017-00 | ⏳ QUEUED |
| 6 | 002-700-116-00 | ⏳ QUEUED |
| 7 | 003-016-008-10 | ⏳ QUEUED |
| 8 | 008-300-001-00 | ⏳ QUEUED |
| 9 | 012-001-001-00 | ⏳ QUEUED |
| 10 | 052-007-014-00 | ⏳ QUEUED |

Stop reason: **Sandbox timeout** — NOT a site block. No 403, no CAPTCHA, no terms signal.

---

## CONFIRMED SAMPLE (PID: 001-001-002-00)

| Field | Value | Status |
|-------|-------|--------|
| parcel_id | 001-001-002-00 | ✅ present |
| jurisdiction | Amber Township | ✅ present |
| owner_name | Amber Township | ✅ present (public entity) |
| property_address | 1735 N US 31 SCOTTVILLE MI 49454 | ✅ present |
| mailing_address | 1735 N US 31 SCOTTVILLE MI 49454 | ✅ present |
| taxable_value | $60,517 | ✅ present |
| assessed_value | $103,700 | ✅ present |
| property_class | 401 | ✅ present |
| pre_percentage | 100% | ✅ present |
| legal_description | not parsed in this run | ⏳ next run |
| sale_date | not parsed in this run | ⏳ next run |
| sale_price | not parsed in this run | ⏳ next run |
| geometry | NONE | ❌ not available via LIAA |
| acreage | not visible | ❌ parse from legal desc |

---

## FIELD CONSISTENCY REPORT (1 record)

| Field | Present | Rate |
|-------|---------|------|
| parcel_id | 1/1 | 100% |
| owner_name | 1/1 | 100% |
| property_address | 1/1 | 100% |
| mailing_address | 1/1 | 100% |
| assessed_value | 1/1 | 100% |
| taxable_value | 1/1 | 100% |
| property_class | 1/1 | 100% |
| pre_percentage | 1/1 | 100% |
| jurisdiction | 1/1 | 100% |
| geometry | 0/1 | 0% |
| acreage | 0/1 | 0% (requires legal desc parse) |

---

## GEOMETRY STATUS

**LIAA does NOT provide polygon geometry.**

Confirmed: Detail pages show property data only — no coordinate pair, no GeoJSON, no boundary data.

Action required: All LIAA records will need geometry enrichment from:
- Michigan DTMB Open Data statewide parcel layer
- Mason County GIS (if available)
- Michigan Open Data Portal (mi.gov/open-data)

geometry_status for all LIAA-sourced records: **`missing`** → queue `geometry_enrichment` task

---

## PAGINATION / DISCOVERY METHOD

| Mechanism | Behavior |
|-----------|----------|
| Entry point | GET session cookie from search page |
| Search | POST form → redirect → GET results |
| Results | HTML page with `pid=XXX-XXX-XXX-XX` links |
| Detail | Direct GET with pid param in URL |
| Session | Cookie required — must be refreshed per run |
| Pagination | Standard HTML result list — no API |
| Rate tolerance | Unknown — behave as if sensitive |

**Pattern is deterministic and clean. This is NOT a REST API. Treat as legacy ASP web form.**

---

## PID PREFIX MAP (MASON COUNTY — PARTIAL)

From our search results only:

| Prefix | Township | Record Count Signal |
|--------|----------|---------------------|
| 001 | Amber Township | High density (SMITH: 222 results) |
| 002 | Branch Township | Moderate |
| 003 | Custer Township | Low (TOWNSHIP search: 5 results) |
| 008 | Unknown — needs confirmation | Low |
| 012 | Sheridan Township | Moderate |
| 020 | Unknown — no results from search | Unknown |
| 030 | Unknown — no results from search | Unknown |
| 040 | Unknown — no results from search | Unknown |
| 052 | Scottville area | Moderate |
| 053 | Unknown — no results from search | Unknown |
| 060 | Unknown — no results from search | Unknown |
| 070 | Unknown — no results from search | Unknown |
| 080 | Unknown — no results from search | Unknown |

Note: Missing prefix results likely require different search terms or are low-density rural townships.

---

## CONNECTOR COMPLEXITY RATING

**Rating: MEDIUM**

Reasons:
- Requires cookie-managed session (not stateless)
- POST → redirect → GET pattern (not simple GET)
- HTML parsing required (not JSON API)
- Legacy ASP backend — layout changes possible
- No bulk export endpoint confirmed
- Geometry must come from external source

Risks:
- Session expiry between requests
- Layout shifts on backend upgrades
- No documented rate limits
- IP/session flagging possible on high volume

Mitigations:
- Fresh cookie per run
- 30–60s delays in batch mode
- Strict stop-on-anomaly logic
- Per-run ConnectorRunLog

---

## SOURCE STATUS ASSIGNMENTS

| Source | Status | Notes |
|--------|--------|-------|
| LIAA (maps.liaa.org/masonparcels) | `primary_plus_geometry_enrichment_required` | Public, accessible, field-rich, no geometry |
| BS&A | `paid_reference_only` | Never access — fee required |
| tax-sale.info | `secondary_auction_signal_only` | Use for auction PID discovery only |
| Michigan DTMB Open Data | `geometry_enrichment_primary` | Use for polygon layer after LIAA intake |

---

## SAFE BATCH RECOMMENDATION

Next run (Pilot Batch — when operator approves):

| Setting | Value |
|---------|-------|
| Mode | pilot_batch |
| Records | 25 (9 from existing queue + 16 new from search) |
| Delay | 30–45s randomized |
| Cooldown | 12h after completion |
| New PIDs needed | 16 more from search result pages (owner or partial PID search) |
| Stop trigger | Any of the 11 standard stop conditions |
| Next allowed run | 2026-04-27 02:00 ET or later |

---

## WHAT IS NOT READY YET

- [ ] Pilot batch not started (needs operator approval)
- [ ] 9/10 queue records not yet fetched
- [ ] Legal description parser not built
- [ ] Sale date/price parser not built
- [ ] Geometry enrichment pipeline not connected
- [ ] ParcelIntakeStaging entity not yet created

---

## WHAT IS READY

- [x] Connector spec locked (.agents/rules/liaa_connector_spec.md)
- [x] LIAAParcelQueue entity live — 10 records seeded
- [x] ConnectorRunLog entity live — run #1 logged
- [x] Safe PID discovery strategy documented
- [x] Field schema confirmed from 1 live record
- [x] Geometry gap confirmed — enrichment path identified
- [x] Source status assignments locked

---

Generated by Mr. Results (Overseer) — Powered by Nvirogear LLC
N-ViroGear Land Intelligence System
