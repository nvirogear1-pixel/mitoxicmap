# Nvirogear Test Report Pair — Apple Dr, Ottawa County MI
## Build Spec v1.0 — May 19, 2026

---

## TEST PAIR PURPOSE

Prove three things:
1. Can the system handle messy parcel identity? (Fruitport vs Nunica conflict)
2. Can it generate different report types from the same local area?
3. Can it beat normal real estate tools on depth, sourcing, and usefulness?

---

## PARCEL IDENTITY CONFLICT — ACTIVE FLAG

**Address:** 13520 Apple Dr
**Conflict:** Public sources show TWO conflicting location labels:
- Homes.com: 13520 Apple Dr, **Fruitport, MI 49415** (est. value range, ~1,304 sf)
- Zillow/Realtor: 13520 Apple Dr, **Nunica, MI 49448** (different parcel/acreage profile possible)

**Required handling:**
- Show BOTH records side by side
- Do NOT resolve conflict by picking one — flag it
- Use Ottawa County GIS as the authoritative verification source
- Label parcel identity confidence as PENDING until GIS confirms

**Parcel identity confidence section is MANDATORY for Test Subject 1.**

---

## TEST SUBJECT 1 — HOUSING REPORT

**Address:** 13520 Apple Dr, Fruitport, MI 49415 (pending GIS confirmation)
**Report Type (default):** Homeowner Equity Loan Readiness Report
**Additional views:** Investor Acquisition | Agent Listing Intelligence | Full Enterprise

**Ottawa County verification sources:**
- Ottawa County GIS portal (preferred)
- Ottawa County Equalization / Assessor
- Michigan Treasury PPAP
- BS&A Online (Ottawa County)

**Required modules:**
- Parcel identity confidence + address conflict detection
- Ownership verification
- Parcel geometry confirmation
- 3-year tax history (Ottawa County verified)
- Forward tax projection (3 scenarios)
- Value context / AVM reference review
- Homeowner equity loan readiness score
- Investor acquisition score
- Agent listing intelligence score
- Environmental risk dashboard (Part 201/213, UST/LUST, PFAS, vapor, flood, wetland)
- Public water findings
- Sewer health score
- Electric/grid reliability (Consumers Energy or municipal)
- Trash/basic service burden
- Township/city contact + ordinance readiness
- Building permit/contact checklist
- Nearby parcel context (4 nearest)
- Permit/improvement activity
- Equity gain opportunities
- Commute + everyday living map
- Nearby shops/services/business pins
- Interactive evidence map (all layers)
- Source ledger (minimum 14 entries)
- Confidence badges on every claim
- Data completeness score
- Missing data list

**Export modes:**
1. Executive Scorecard (1–2 pages)
2. Standard Audience Report (8–15 pages)
3. Full Enterprise Report (with appendix)
4. Interactive Dashboard
5. Source Appendix

**Scores required:**
1. Homeowner Equity Loan Readiness Score
2. Investor Acquisition Score
3. Agent Listing Intelligence Score
4. Environmental Clear Signal
5. Tax Stability Score
6. Water Confidence Score
7. Sewer Health Score
8. Electric/Grid Reliability Score
9. Neighborhood Service Access Score
10. Data Completeness Score

---

## TEST SUBJECT 2 — LAND REPORT

**Address:** Apple Dr, Fruitport, MI 49415 (vacant parcel near 13520)
**Parcel candidate:** 700408200039 (Zillow-sourced — MUST be verified via Ottawa County GIS)
**Acreage candidate:** ~2.25 acres
**Note:** If Ottawa County GIS identifies a closer/better vacant parcel near 13520 Apple Dr, use that and document why.
**Report Type (default):** Land Use, Homestead & Development Feasibility Report
**Additional views:** Investor Acquisition | Full Enterprise

**Required modules:**
- Land feasibility snapshot
- Land use readiness score
- Homestead feasibility score
- Developer land feasibility score
- Zoning and allowed-use matrix
- Septic/well/water/sewer feasibility
- Rural utility and off-grid readiness
- Propane/gas/electric/internet availability
- Access/road frontage/easement review
- Driveway/culvert/road commission checklist
- Buildable area and constraint overlay
- Environmental land factors (Part 201/213/PFAS/UST/LUST/vapor)
- Environmental health radius (0.25/0.50/1.00/3.00 mi bands)
- Wetland/floodplain/soil/slope constraints
- Nearby parcel context
- **Supplier support network** (all 19 categories — see land module spec)
- Supplier support score
- Homestead development pathway (9 steps)
- Developer land development pathway (10 steps)
- Land deal-killer flags
- Township/county contact pins
- Ordinance readiness
- Interactive land map (20 land layers + all standard layers)
- Source ledger
- Confidence badges
- Data completeness score
- Missing data list

**Scores required:**
1. Land Use Readiness Score
2. Homestead Feasibility Score
3. Developer Land Feasibility Score
4. Access Score
5. Septic/Well Feasibility Score
6. Environmental Land Constraint Score
7. Rural Utility/Off-Grid Score
8. Supplier Support Score
9. Overall Land Intelligence Score
10. Data Completeness Score

---

## SHARED MAP REQUIREMENTS

Both reports must include toggleable interactive map.

**Global layers (both reports):**
subject parcel | nearby parcels | parcel boundary confidence | environmental pins | Part 201 | Part 213/LUST | UST/AST | PFAS | brownfield | vapor risk | floodplain | wetlands | surface water | soil constraints | slope/topography | public water findings | sewer health | electric/grid | zoning/ordinance | government/township contacts | police/fire/post office | permits/improvements | equity gain opportunities | nearby sales/value | public news | commute destinations | everyday living shops | land access points | road frontage | preliminary buildable area | preliminary septic area | solar exposure | nearby supplier network

**Pin popup required fields:**
title | short explanation | source | date checked | confidence badge | relevance to subject parcel | next action

---

## AI EVALUATION PACKAGE (both reports)

Each report must include an "Evaluator Questions" section:

1. Does this report match or exceed what a bank, investor, housing sponsor, agent, developer, or land buyer would expect from a best-in-industry report?
2. What sections are missing?
3. What sections are too long or unnecessary?
4. What scoring weights should change?
5. Are any claims too strong?
6. Are any important risks underexplained?
7. What would make this more sellable?
8. What would make this more defensible?
9. What would make this more useful as an interactive dashboard?
10. What should be added before this becomes a paid report product?

Each evaluation package also includes:
- Report PDF/export
- Executive scorecard
- Source ledger
- Scoring rubric
- Data completeness summary
- Map layer list
- Known gaps / missing data

---

## BUILD SEQUENCE

### Phase 1 — Ottawa County Data Pull
1. Ottawa County GIS REST endpoint query for 13520 Apple Dr
2. Ottawa County GIS REST for parcel 700408200039
3. Michigan Treasury PPAP for both parcels
4. BS&A Online Ottawa County for tax history
5. EPA ECHO / EGLE radius query (1 mi)
6. FEMA Flood Map for Ottawa County
7. NWI Wetlands query
8. NRCS Web Soil Survey
9. Census geocoder for confirmed centroid
10. Road frontage / Fruitport Township zoning confirmation

### Phase 2 — Score + Analyze
- Tax projection (3 scenarios)
- Parcel identity confidence resolution
- Land use matrix (all 17 uses)
- Homestead/Developer/Land scores
- Equity gain opportunities
- Supplier network pin list
- Neighborhood/commute distances

### Phase 3 — Build HTML reports
- Test 1: Housing report (3 views + map + source ledger)
- Test 2: Land report (3 views + map + source ledger + supplier layer)
- AI Evaluation Package for each

### Phase 4 — Upload both
- Housing report HTML → public URL
- Land report HTML → public URL
- Evaluation packages → uploadable JSONs

---

## PRIMARY GIS SOURCES — OTTAWA COUNTY

Ottawa County GIS Portal: https://www.miottawa.org/gis/
Ottawa County ArcGIS REST: https://gis.miottawa.org/arcgis/rest/services/
Ottawa County Property Search: https://www.miottawa.org/equalization/
Ottawa County BS&A: https://bsaonline.com (Ottawa County instance)
Fruitport Township: https://www.fruitporttownship.com/
Michigan Treasury PPAP: https://www.michigan.gov/ppap

---

*Apple Dr Test Pair Spec v1.0 | May 19, 2026 | Mr. Results — Nvirogear LLC*
