# STATE SNAPSHOT — 2026-10-17 (frozen at export)
# Where the work stands. Update as the sovereign clone progresses.

## ACTIVE MISSION: THE WINTER FREEZE / THE ENTERPRISE
Goal: acquire low-cost, high-reward Northern/West Michigan land; generate
winter cash via firewood/cut-on-shares; compound profits. Financial target:
first $2,500 net profit -> truck, then dump trailer.

## THE OCT 30, 2026 AUCTION (tax-sale.info, sealed bid, 10 AM - 7 PM EDT)
Bid sheet as of 2026-10-17 (locks Oct 29, one submission per lot):
- Pentwater village lot (Oceana surplus 640200, $500 FLAT OTC, NOT an auction
  lot - buy this week): GREEN, PIN owed from treasurer
- Michaywe 6101 + 6139 (Otsego, $150 max each; 6102 BENCHED - cliff trap)
- Miramichi 6-lot cluster (Osceola, $100 each, supply-control play;
  dues + FEMA checks owed)
- Mason 4614 Benson Rd (Mason, $150 max, frontage owed)
- Mason 4620 Ludington infill (re-entered; price off COMPS, never the $65K SEV)
- Copemish 4.17 ac (Manistee, $300 max; grade rides on Jet's measured M-115
  frontage verification)
- W Lakewood 6-lot bundle (Muskegon, $1,000 offer / $1,500 ceiling via Land
  Bank 231-724-6170): LEANING GREEN, timber rights + tree count owed
- Sugar Springs (Gladwin): PASS - VERIFIED $475/lot/yr dues (POA fee schedule),
  10-yr carry $4,750/lot vs failed $1,750 minimums

## STANDING VERIFICATIONS (the phone calls no bot makes)
Oceana treasurer (Pentwater PIN) | Muskegon Land Bank | Manistee Road
Commission (Copemish access) | DNR forester referral | Fruitland Twp septic |
POA dues in writing (Michaywe, Lake Miramichi) | FEMA MSC flood checks |
tax-sale.info registration BEFORE auction day.

## LIVE REPORTS (GitHub Pages, nvirogear1-pixel/mitoxicmap)
reports/winter-freeze-v2.html - the board + deep dives
reports/west-lakewood-money-paths.html - the Lakewood enterprise report
reports/winter-freeze-playbook.pdf - the 10-page playbook
reports/homestead-risk-audit.html - the 12-vector risk audit

## KEY DOCTRINE FOR THIS MISSION
12-vector fail-safe analysis before ANY bid. Sealed-bid discipline: max price
is the bid. SEV is a screen, never a price. Dues are the killer of $100 lots -
written dues statement before every POA-sub bid. Never outbid a government
liquidation. Unknowns are labeled unknowns - never invent facts.
