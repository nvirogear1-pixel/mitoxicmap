# ALICE MISS DIG ALERT SYSTEM — Complete Package
**Nvirogear LLC · Prepared for live demonstration · 2026-10-22**

## WHAT THIS SYSTEM IS (one sentence)

ALICE surfaces publicly available environmental information so that anyone planning ground
disturbance near a documented contamination site can make an informed decision before breaking soil.

It is an **evidence and awareness system** — it never tells contractors what to do, never
prescribes field operations, and never claims contamination is present. That framing is what
makes every alert defensible.

## WHERE THE TICKETS COME FROM (the question everyone asks first)

**Live public ArcGIS FeatureServer** — the same feed that powers the MISS DIG 811 public dashboard:

```
https://services6.arcgis.com/Nc7s1pHE9DK9Wuj9/arcgis/rest/services/esri_ticket_details/FeatureServer/0/query
```

- The system queries this endpoint for tickets filed in the last N hours (500 max per pull)
- The feed provides: ticket number, ticket type, work type, location town, lat/lng, created/expiration dates, excavation method and depth
- The feed does NOT provide excavator names or phones — **those fields are left blank in our system, never fabricated** (early demo scripts that invented contacts were deprecated and quarantined — see section 6)
- `03_ticket_source/live_feed_proof_2026-10-22.json` contains a raw pull from this morning
  (tickets filed as recently as 05:52 UTC today, 2026-10-22)

## HOW THE LOGIC WORKS (pipeline, start to finish)

1. **Pull** live tickets from the FeatureServer (see above)
2. **Cross-reference** each ticket's lat/lng against a curated catalog of 9 contamination
   sites (Kysor Industrial NPL, Cadillac Industrial Park PFAS AOI + 2 expansion zones,
   Thomas Solvent NPL, Egelcraft/Brooks Rd-Laketon Ave AOI, Heights-Ravenna Rd laundromat,
   Muskegon County Airport PFAS AOI, Cloverville Pumphouse) — every catalog entry carries
   its official EPA/EGLE source URL
3. **Measure distance** via documented haversine (3958.8 mi radius), 0.5 mi scan radius
4. **Classify into exactly one of three buckets** (never two, never upgraded):
   - `VERIFIED_ALERT` — passed the hard gate: source id + source database + coordinates +
     distance calc + source URL + county match, all present. Carries a real SHA-256 evidence hash
   - `NEEDS_REVIEW` — possible match, but a required proof field failed/missing
   - `CLEAN_NO_MATCH` — no catalog record within radius
5. **Package** the evidence: interactive map (green=ticket, red=contamination site, yellow=buffer
   ring), PDF packet, archived record with hashes — nothing is ever deleted
6. **Gate** — nothing sends without a human approval. Ever. States: draft → pending_approval → approved → sent → archived

**Claim language, verbatim, always:** "a source-backed contamination record was found within the
scan radius." NEVER "contamination detected."

## WHERE THE CODE AND SPECS LIVE

| File in this package | What it is |
|---|---|
| `01_doctrine/alice_missdig_alert_doctrine.md` | The locked governing spec v1.0 (June 27, 2026): system identity, email structure (locked), recommended-actions wording (locked, 4 lines verbatim), visual map requirements (green/red/yellow + pin + legend + scale + north arrow), PDF section order (11 sections, locked), evidence timeline format, confidence score formula (+20/-10 points), archive structure, approval gate |
| `02_report_logic/missDigCrossRef.ts` | The deployed live function — 371 lines, plain-language governance header, the hard validation gate, haversine, SHA-256 evidence hashing, the 9-site catalog with source URLs |
| `02_report_logic/AliceMissDigAlert_schema.jsonc` | Database schema for every alert record |
| `02_report_logic/AlertDeliveryLog_schema.jsonc` | Approval-gate audit schema: who approved, when, message hash, evidence hash |
| `03_ticket_source/live_feed_proof_2026-10-22.json` | Raw live-feed pull from this morning |
| `04_automation/daily_alert_workflow.jsonc` | The live automation: daily 11:00 UTC scan → 3-bucket classification → report |
| `04_automation/screenshotter_workflow_LEGACY.jsonc` | The earlier dashboard-screenshot approach (12-hr interval) — kept for audit trail |
| `05_evidence_samples/live_run_summary_2026-10-22.json` | This morning's live run: 500 tickets scanned in 839 ms, 0 alerts |

## THE HONEST LIMITS (say these out loud — they are strengths)

- **The catalog is 9 curated sites, not a statewide sweep.** Every entry independently verified with
  EPA/EGLE source URLs. Clean means "not within 0.5 mi of OUR records" — never "the ground is clean."
- **This morning's live run flagged zero tickets.** 500 real tickets scanned in 839 ms; none fell
  near our 9 sites (they were in Ubly, Wyoming, Jackson, Grand Rapids). A clean window is a valid
  result and the system reports it as such — three buckets, every time, not just flagged vs clean.
- **Excavator contact is not in the public feed.** We leave it blank. Early demo scripts that
  invented contacts were deprecated, renamed FAKE, and quarantined in `_deprecated_fake_scripts/` —
  never deleted, per doctrine, so the audit trail shows the correction.
- **Nothing sends without human approval.** No exceptions. The delivery log records who, when,
  message hash, evidence hash.

## DEMO TALK TRACK (30 seconds)

"Every excavator in Michigan files a MISS DIG ticket before digging. Those tickets are public.
ALICE watches the live feed, cross-references each dig site against nine verified contamination
sites — Superfund, PFAS, solvent plumes, each with its EPA source URL — and classifies every
ticket into three buckets: verified alert, needs review, or clean. Verified alerts carry a
SHA-256 hash of the full evidence bundle. Nothing is invented: missing fields stay missing,
contact info stays blank, and nothing sends without a human approval. Truth is more valuable
than optimism — that's the whole product."

## ONE MORE LINE FOR THE ROOM

The deprecated-scripts folder is the demo's quiet mic-drop: when the team caught demo data
being fabricated in July, the fake scripts weren't deleted — they were renamed, quarantined,
and preserved. The audit trail shows the system correcting itself. That's what an evidence
system looks like.

---
*Nvirogear LLC · ALICE MISS DIG Alert Doctrine v1.0 (locked 2026-06-27) · Package assembled 2026-10-22 by Mr. Results (Overseer)*
