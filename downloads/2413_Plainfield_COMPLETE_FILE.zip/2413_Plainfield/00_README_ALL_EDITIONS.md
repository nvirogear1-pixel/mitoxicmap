# 2413 PLAINFIELD AVE NE - COMPLETE FILE (ALL EDITIONS, ONE PLACE)

Parcel: PPN 411-407-280-010 (APN 41-14-07-280-010), Lot 3 Block 2, Riverside Gardens
City of Grand Rapids, Kent County, MI 49505 - INSIDE the city; Plainfield Charter Twp begins miles north.
Owner of record: Morton W. & Vicki Smith (verified via Kent County BS&A)

## THE FOUR EDITIONS (read in this order)

1. 2413-plainfield-investment.html  - THE CONSOLIDATED EDITION (live, current)
   Everything below merged: value stack (SEV model $245K, AVMs $291-305K, zip median $308K,
   comp average $368K), SEV movement (+$10,300 since May), block math, garage-with-lift
   value, repair stack, HELOC paths, FEMA Zone X, PFAS 8.1 mi, fleet dispatches.

2. 2413_property_intelligence_report.pdf  - THE FULL 17-SECTION PDF (from Google Drive)
   Property snapshot, GIS map, ownership chain, tax history 2018-2025, six sold comps,
   zoning MCN-LDR, environmental context, neighborhood (Aberdeen Elementary), condition,
   opportunity signal, investment scenarios (flip $55-85K spread; rental $1,400-1,750/mo),
   risk register, gate status, source ledger, confidence legend, disclaimers.

3. 2413_enterprise_map_FINAL_from_drive.html  - THE FINAL MAP EDITION
   Official Kent County polygon, SEV $112,200 snapshot, FEMA Zone X confirmed, PFAS clearance.

4. 2413_v2_production_from_drive.html  - THE V2 PRODUCTION EDITION (May 24, 2026)
   First full production report: 491-parcel cross-check (no township address confusion),
   State Disposal PFAS 5+ mi, SEV $112,200 baseline.

## KEY FACTS ACROSS ALL EDITIONS
- SEV: $112,200 (May) -> $122,500 (Oct live pull) = +$10,300; taxable capped at $58,523
- Sale chain: $52,000 (1997) -> $71,500 (1998) -> $104,900 (2001) -> $115,000 (2004)
- House: 3BR/1BA ranch, 1,272 sq ft above grade, full basement likely, 0.27 acres
- Year built: 1952 (PDF) vs 1955 est. (v2) - official confirmation still owed
- Garage: 2-car detached, paved driveway (PDF, May 2026); lift newly added (owner, Oct 2026)
- Environment: zero Part 201 within 1 mi; State Disposal PFAS 8.1 mi; FEMA Zone X
- Taxes: $1,600-1,861/yr since 2014, no spikes, no delinquency

## STILL PENDING (by name)
- Kent BS&A year-built + sq ft confirmation
- Owner's mortgage balance (only from the owner) - makes HELOC math exact
- FEMA MSC panel number for the file (zone X already confirmed in FINAL map edition)

SHA-256 manifest: SHA256_MANIFEST.txt
